from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as fh:
    long_description = fh.read()

setup(
    name='codepack',
    version='0.0.3',
    author='TensorStack',
    author_email='hello@tensorstack.com',
    description='T9k Codepack CLI',
    long_description=long_description,
    long_description_content_type='text/markdown',
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],

    packages=find_packages(),

    python_requires='>=3.6',
    install_requires=[
        'click',
        'cryptography',
        'kubernetes>=20.0.0',
        'pyyaml',
    ],
    entry_points={
        'console_scripts': [
            'codepack = codepack:codepack',
        ],
    },
)
