"""Core class of Codepack."""

import os

import click
import yaml

from codepack import graphlib
from codepack.copying import copy
from codepack.creation import apply, create, delete
from codepack.utils import blue, purple, eprint

REQUIRED_CODEPACK_FIELDS = ['apiVersion', 'name', 'description', 'targets']
REQUIRED_TARGET_FIELDS = ['name', 'actions']


class Codepack():
    """A Codepack definition loaded from a Codepack definition file."""
    def __init__(self, codepack_path):
        if os.path.isdir(codepack_path):
            self._path = os.path.abspath(codepack_path)
            def_file_path = os.path.join(self._path, 'codepack.yaml')
        else:  # file path
            def_file_path = os.path.abspath(codepack_path)
            self._path = os.path.dirname(def_file_path)

        try:
            definition = self.parse(def_file_path)
        except FileNotFoundError:
            eprint('invalid Codepack path: {}'.format(codepack_path))

        self.name = definition['name']
        self.description = definition['description']
        self.project = definition.get('project')
        self.default = definition.get('default')
        self.targets = {
            i['name']: Target(i, self)
            for i in definition['targets']
        }

    @staticmethod
    def parse(def_file_path):
        """Parses YAML file to Codepack definition."""
        try:
            with open(def_file_path, 'rt') as f:
                definition = yaml.safe_load(f)
        except (yaml.parser.ParserError, yaml.scanner.ScannerError) as e:
            eprint(
                'invalid Codepack definition YAML:\nyaml.parser.ParserError: {}'
                .format(e))

        Codepack.check(definition)
        return definition

    @staticmethod
    def check(definition):
        """Checks validity of Codepack definition.

        Check items:
            * fields 'apiVersion', 'name', 'description' and 'targets' are
              contained in Codepack definition
            * fields 'name', 'actions' are contained in definition of each target
            * each target has unique name
            * dependencies of all targets are valid and they constitute a DAG

        Note that each action is checked when it is initialized.
        """
        if definition is None:
            eprint('empty Codepack definition file')

        missing_codepack_fields = []
        for field in REQUIRED_CODEPACK_FIELDS:
            if field not in definition:
                missing_codepack_fields.append(field)
        if missing_codepack_fields:
            eprint('required fields are missing in Codepack definition: {}'.
                   format(', '.join(missing_codepack_fields)))
        if definition['apiVersion'] != 'codepack.tensorstack.dev/v1beta1':
            eprint('not supported API version: {}'.format(
                definition['apiVersion']))

        targets = definition['targets']
        target_names = []
        for i, t in enumerate(targets, start=1):
            missing_target_fields = []
            for field in REQUIRED_TARGET_FIELDS:
                if field not in t:
                    missing_target_fields.append(field)
            if missing_target_fields:
                eprint(
                    'required fields are missing in definition of target #{}: {}'
                    .format(i, ', '.join(missing_target_fields)))
            if t['name'] in target_names:
                eprint(
                    'target with name "{}" is repeated in Codepack definition'.
                    format(t['name']))
            target_names.append(t['name'])

        complete_graph = {}
        for t in targets:
            deps = t.get('deps')
            if deps:
                for d in deps:
                    if d not in target_names:
                        eprint('unknown dependency of target {}: {}'.format(
                            t['name'], d))
                complete_graph[t['name']] = set(deps)

        try:
            graphlib.TopologicalSorter(complete_graph).prepare()
        except graphlib.CycleError as e:
            eprint('dependency cycle detected: {}'.format(' -> '.join(
                e.args[1])))

    def run(self, target_name, project):
        """Runs specified target of this Codepack in specified project."""
        if not project:
            project = self.project
            if project:
                click.echo('default project {} is selected'.format(
                    blue(project)))
            else:
                eprint((
                    'project not specified: use "-p" option to specify a project '
                    'or provide "project" field in Codepack definition file'))
        if not target_name:
            target_name = self.default
            if target_name:
                click.echo('default target {} is selected'.format(
                    blue(target_name)))
            else:
                eprint((
                    'target not specified: use "-t" option to specify a target '
                    'or provide "default" field in Codepack definition file'))
        click.echo('{} target {} of codepack {} in project {}'.format(
            *blue('RUN', target_name, self.name, project)))
        self.targets[target_name].exec(project, exec_deps=True)

    def describe(self):
        click.echo(blue('name: ') + self.name)
        click.echo(blue('description: ') + self.description)
        click.echo(blue('project: ') + self.project)
        click.echo(blue('targets:'))
        for k in self.targets.keys():
            click.echo('  - {}'.format(k))

    def __str__(self):
        s = ('Codepack:\n  name: {}\n  description: {}\n  project: {}\n'
             '  targets:\n').format(self.name, self.description, self.project)
        for k in self.targets.keys():
            s = s + '    - {}\n'.format(k)
        return s


class Target():
    """A target of a Codepack.

    A target defines a specific task of the Codepack it belongs to.

    A target can include one or more actions. When a target is executed, all
    of its actions are executed in sequence.

    A target may depend on other targets. If a target with dependencies is
    executed, all of these targets will be topologically sorted and executed
    in sequence.
    """
    def __init__(self, target_data, codepack):
        self.codepack = codepack
        self.name = target_data['name']
        self.deps = target_data.get('deps')

        self.actions = []
        for i, a in enumerate(target_data['actions'], start=1):
            try:
                self.actions.append(create_action(a, self))
            except KeyError as e:
                eprint('{} (#{}) of target {}: {}'.format(
                    e.args[0], i, blue(self.name), ', '.join(e.args[1])))

    def exec(self, project, exec_deps=False):
        """Executes this target in specified project.

        Args:
            project:
                Project to be executed in.
            exec_deps:
                If True and `self.deps` is not None, parses the dependencies,
                sorts them topologically and executes them in sequence.
        """
        if exec_deps and self.deps:
            graph = {}
            Target.parse_deps(graph, self)
            exec_list = list(graphlib.TopologicalSorter(graph).static_order())
            click.echo('Running sequence: {}\n'.format(' -> '.join(
                blue(*exec_list))))
            n = len(exec_list)
            for i, t in enumerate(exec_list, 1):
                click.echo('Target {}/{}: {}'.format(i, n, blue(t)))
                self.codepack.targets[t].exec(project)
        else:
            for a in self.actions:
                a.exec(project)

    def __str__(self):
        s = ('target:\n  codepack: {}\n  name: {}\n  deps: {}\n'
             '  actions:\n').format(self.codepack.name, self.name,
                                    str(self.deps))
        for a in self.actions:
            s = s + '    - {}\n'.format(a.name + a.verb)
        return s

    @staticmethod
    def parse_deps(graph, target):
        """Parses dependencies of the target.

        If the target is not in keys of dict `graph` and it has dependencies,
        the key-value pair `<target>: <set of dependencies>` will be added to
        the dict, and this function will be recursively called to each of the
        dependencies to add recursive dependencies.

        Args:
            graph:
                A dict used to hold dependency.
            target:
                Target instance which dependencies are parsed and added to
                `graph`.

        Returns:
            A dict representing the graph of dependency.
        """
        if target.name not in graph and target.deps:
            graph[target.name] = set(target.deps)
            for t in target.deps:
                Target.parse_deps(graph, target.codepack.targets[t])


class Action():
    """An action of a target.

    An action defines a specific operation of the target it belongs to.

    The `verb` attribute of Action represents type of the operation, its value
    must be one of 'apply', 'copy', 'create', 'mkb' and 'mkdir'.
    """
    def __init__(self, action_data, target):
        self.target = target
        self._path = target.codepack._path
        self.name = action_data.get('name')

    def exec(self, project):
        """Executes this action in specified project."""
        raise NotImplementedError()

    def __str__(self):
        d = self.__dict__.copy()
        s = 'action:\n'

        d.pop('target')
        s = s + '  target: {}\n'.format(self.target.name)

        name = d.pop('name') if 'name' in d else ''
        if name:
            s = s + '  name: {}\n'.format(name)

        verb = d.pop('verb')
        s = s + '  verb: {}\n'.format(verb)

        for k, v in d.items():
            s = s + '  {}: {}\n'.format(k, v)

        return s


class ApplyAction(Action):
    """Action subclass for verb apply."""
    def __init__(self, action_data, target):
        super().__init__(action_data, target)
        self.verb = 'apply'

        missing_action_fields = []
        for field in ['files']:
            if field in action_data:
                object.__setattr__(self, field, action_data[field])
            else:
                missing_action_fields.append(field)
        if missing_action_fields:
            raise KeyError(
                'required fields are missing in definition of apply action:'
                ' {}'.format(missing_action_fields))

    def exec(self, project):
        files = self.files
        print('{} by files {}'.format(*purple('APPLY', str(files))))
        if isinstance(files, list):
            files = [os.path.join(self._path, f) for f in files]
        elif isinstance(files, str):
            files = os.path.join(self._path, files)
        apply(files, project)


class CopyAction(Action):
    """Action subclass for verb copy."""
    def __init__(self, action_data, target):
        super().__init__(action_data, target)
        self.verb = 'copy'

        missing_action_fields = []
        for field in ['src', 'dst']:
            if field in action_data:
                object.__setattr__(self, field, action_data[field])
            else:
                missing_action_fields.append(field)
        if missing_action_fields:
            raise KeyError(
                'required fields are missing in definition of copy action:'
                ' {}'.format(missing_action_fields))

        self.update = action_data[
            'update'] if 'update' in action_data else False

    def exec(self, project):
        print('{} from {} to {}'.format(*purple('COPY', self.src, self.dst)))
        # for now assume src is local path and dst is pvc path
        copy(self.src, self.dst, self._path, project)


class CreateAction(Action):
    """Action subclass for verb create."""
    def __init__(self, action_data, target):
        super().__init__(action_data, target)
        self.verb = 'create'

        missing_action_fields = []
        for field in ['files']:
            if field in action_data:
                object.__setattr__(self, field, action_data[field])
            else:
                missing_action_fields.append(field)
        if missing_action_fields:
            raise KeyError(
                'required fields are missing in definition of create action:'
                ' {}'.format(missing_action_fields))

        self.new = action_data['new'] if 'new' in action_data else True

    def exec(self, project):
        files = self.files
        print('{} by files {}'.format(*purple('CREATE', str(files))))
        if isinstance(files, list):
            files = [os.path.join(self._path, f) for f in files]
        elif isinstance(files, str):
            files = os.path.join(self._path, files)
        create(files, project, self.new)


class DeleteAction(Action):
    """Action subclass for verb delete."""
    def __init__(self, action_data, target):
        super().__init__(action_data, target)
        self.verb = 'delete'

        missing_action_fields = []
        for field in ['files']:
            if field in action_data:
                object.__setattr__(self, field, action_data[field])
            else:
                missing_action_fields.append(field)
        if missing_action_fields:
            raise KeyError(
                'required fields are missing in definition of delete action:'
                ' {}'.format(missing_action_fields))

        self.ignore_error = action_data[
            'ignore_error'] if 'ignore_error' in action_data else True

    def exec(self, project):
        files = self.files
        print('{} by files {}'.format(*purple('DELETE', str(files))))
        if isinstance(files, list):
            files = [os.path.join(self._path, f) for f in files]
        elif isinstance(files, str):
            files = os.path.join(self._path, files)
        delete(files, project, self.ignore_error)


class MkdirAction(Action):
    """Action subclass for verb mkdir."""
    def __init__(self, action_data, target):
        super().__init__(action_data, target)
        self.verb = 'mkdir'

        missing_action_fields = []
        for field in ['path']:
            if field in action_data:
                object.__setattr__(self, field, action_data[field])
            else:
                missing_action_fields.append(field)
        if missing_action_fields:
            raise KeyError(
                'required fields are missing in definition of mkdir action:'
                ' {}'.format(missing_action_fields))

    def exec(self, project):
        print('Make dir {}'.format(self.path))


def create_action(action_data, target):
    """Creates an action by data for a target."""
    verb = action_data['verb']
    if verb == 'apply':
        return ApplyAction(action_data, target)
    elif verb == 'copy':
        return CopyAction(action_data, target)
    elif verb == 'create':
        return CreateAction(action_data, target)
    elif verb == 'delete':
        return DeleteAction(action_data, target)
    elif verb == 'mkdir':
        return MkdirAction(action_data, target)
    else:
        eprint('not supported verb of action: {}'.format(verb))
