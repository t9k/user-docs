"""Implementation of verb copy."""

import os
import re
import select
import socket
import subprocess
import tempfile
import threading

import click

from codepack.cert import create_key_pair
from codepack import client


def copy(src, dst, local_base_path, ns):
    """Copys files from src to dst."""
    src_kind, src_path = parse_path(src, local_base_path)
    dst_kind, dst_path = parse_path(dst, local_base_path)
    # TODO: support more situations
    if src_kind == 'local' and dst_kind == 'local':
        sync(src_path, dst_path)

    elif src_kind == 'local' and dst_kind == 'pvc':
        pvc_name, dst_path = dst_path
        copy_between_local_and_pvc(ns,
                                   src_path,
                                   dst_path,
                                   pvc_name,
                                   src_is_local=True)

    elif src_kind == 'pvc' and dst_kind == 'local':
        pvc_name, src_path = src_path
        copy_between_local_and_pvc(ns,
                                   src_path,
                                   dst_path,
                                   pvc_name,
                                   src_is_local=False)

    elif src_kind == 'pvc' and dst_kind == 'pvc':
        # TODO: copy from PVC to PVC
        raise NotImplementedError()

    click.echo('copied')


def copy_between_local_and_pvc(ns, src_path, dst_path, pvc_name, src_is_local):
    """Copys files between local file system and PVC.

    Args:
        ns: Namespace of the PVC.
        src_path: Source path.
        dst_path: Destination path.
        pvc_name: Name of the PVC.
        src_is_local: If True, `src` is local path, else `dst` is local path.
    """
    public_key, private_key = create_key_pair()
    private_key_file = _create_temp_file(private_key)

    # Pod name is a generateName of 'codepack-copy-pod-'
    pod_name = client.create_copy_pod(ns, pvc_name, public_key)

    try:
        client.wait_for_pod_to_run(ns, pod_name)

        sock_to_pod = client.port_forward(ns, pod_name, client.COPY_POD_PORT)
        sock_for_sync = socket.socket()
        sock_for_sync.bind(('', 0))
        local_port = sock_for_sync.getsockname()[1]
        proxy = threading.Thread(name='Local port forward proxy',
                                 target=_proxy,
                                 args=(sock_to_pod, sock_for_sync))
        proxy.daemon = True
        proxy.start()

        remote_sync(src_path, dst_path, src_is_local, local_port,
                    private_key_file.name)

        proxy.keep = False
        proxy.join()

    finally:
        client.delete_pod(ns, pod_name)


def parse_path(path, local_base_path):
    """Parses path to local path, s3 path or PVC name and path."""
    if path.startswith('s3://'):  # s3 path
        # TODO: handle s3 path
        kind = 's3'
        path = ''
        raise NotImplementedError()
    elif re.match(r'[a-z0-9][a-z0-9\-]*[a-z0-9]:',
                  path):  # match PVC name and path
        kind = 'pvc'
        path = path.split(':', maxsplit=1)
    else:  # local path
        kind = 'local'
        if not os.path.isabs(path):
            path = os.path.join(local_base_path, path)
    return kind, path


def sync(src, dst):
    """Syncs files locally using rsync."""
    cmd = ['rsync']
    # TODO: expose more options of rsync
    if os.path.isdir(src):
        cmd.append('-a')
    cmd.extend([src, dst])
    subprocess.run(cmd, check=True)


def remote_sync(src, dst, src_is_local, port, private_key_file):
    """Syncs files between local and PVC using rsync.

    Args:
        src: Source path.
        dst: Destination path.
        src_is_local: If True, `src` is local path, else `dst` is local path.
        port: Port number of local proxy in string format.
        private_key_file: Path of file that contains private key data.
    """
    cmd = ['rsync', '-a']
    # TODO: expose more options of rsync
    rsh = (
        '/usr/bin/ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null '
        '-o LogLevel=ERROR -p {} -i {}'.format(port, private_key_file))
    cmd.extend(['-e', rsh])
    if src_is_local:
        cmd.extend(['--chown', 't9kuser:t9kuser'])
        dst = 'root@localhost:' + os.path.join('/mnt', dst)
    else:
        src = 'root@localhost:' + os.path.join('/mnt', src)
    if src.endswith('/.'):
        src = src[:-2]
    if dst.endswith('/.'):
        dst = dst[:-2]
    cmd.extend([src, dst])
    subprocess.run(cmd, check=True)


def _create_temp_file(content):
    """Creates a temporary file with given contents."""
    fp = tempfile.NamedTemporaryFile()
    fp.write(content)
    fp.seek(0)
    return fp


def _proxy(sock_to_pod, sock_for_sync):
    """Creates a proxy simply forwarding between two sockets."""
    t = threading.currentThread()

    sock_for_sync.listen(1)
    sock_for_sync_conn, _ = sock_for_sync.accept()

    data_to_pod = b''
    data_for_sync = b''

    with sock_for_sync_conn:
        while getattr(t, 'keep', True):
            rlist = [sock_to_pod, sock_for_sync_conn]
            wlist = []
            if data_to_pod:
                wlist.append(sock_to_pod)
            if data_for_sync:
                wlist.append(sock_for_sync_conn)

            r, w, _ = select.select(rlist, wlist, [])
            for sock in r:
                if sock == sock_to_pod:
                    data = sock.recv(client.SOCKET_BUFFER_SIZE)
                    if data:
                        data_for_sync += data
                else:
                    data = sock.recv(client.SOCKET_BUFFER_SIZE)
                    if data:
                        data_to_pod += data
            for sock in w:
                if sock == sock_to_pod:
                    sent = sock.send(data_to_pod)
                    data_to_pod = data_to_pod[sent:]
                else:
                    sent = sock.send(data_for_sync)
                    data_for_sync = data_for_sync[sent:]

    sock_to_pod.close()
    sock_for_sync.close()
