"""Utility functions."""

import sys
import click


def red(*s, bold=False):
    """Makes the text red and optionally bold."""
    if len(s) > 1:
        return [click.style(i, fg='red', bold=bold) for i in s]
    elif len(s) == 1:
        return click.style(s[0], fg='red', bold=bold)


def blue(*s, bold=False):
    """Makes the text blue and optionally bold."""
    if len(s) > 1:
        return [click.style(i, fg='blue', bold=bold) for i in s]
    elif len(s) == 1:
        return click.style(s[0], fg='blue', bold=bold)


def purple(*s, bold=False):
    """Makes the text purple and optionally bold."""
    if len(s) > 1:
        return [click.style(i, fg=(136, 78, 160), bold=bold) for i in s]
    elif len(s) == 1:
        return click.style(s[0], fg=(136, 78, 160), bold=bold)


def eprint(msg, prefix=True):
    """Prints error message and exits."""
    if prefix:
        click.echo(red('error: ', bold=True) + msg, err=True)
    else:
        click.echo(msg, err=True)
    sys.exit(1)
