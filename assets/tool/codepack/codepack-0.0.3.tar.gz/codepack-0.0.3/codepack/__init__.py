"""
Module `codepack` provides a CLI to quickly run ML projects on T9k
Platform.
"""

from codepack.cli import codepack

__all__ = ['codepack']
