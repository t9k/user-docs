"""Implementation of CLI."""

import click

from codepack import client
from codepack.config import CONFIG, CONFIG_ITEMS
from codepack.core import Codepack
from codepack.utils import blue, eprint
from codepack.version import VERSION


@click.group()
@click.option('-p', '--project')
@click.option('-v', '--verbose', is_flag=True)
@click.version_option(VERSION)
@click.pass_context
def codepack(ctx, project, verbose):
    # TODO: allow using "-p" and "-v" option here
    del ctx, project, verbose  # Unused
    pass


@codepack.command()
@click.argument('codepack_path', type=click.Path(exists=True), required=False)
# Local path of the Codepack to be checked
def check(codepack_path):
    """Checks validity of a Codepack config.

    The following items will be checked:

        * Codepack config has required fields: 'apiVersion', 'name',
          'description' and 'targets'

        * each target has required fields

        * each target has unique name

        * dependencies of all targets are valid and they constitute a DAG

        * each action has required fields of its verb
    """
    if not codepack_path:
        codepack_path = '.'
    codepack_ = Codepack(codepack_path)
    click.echo('Checked, no errors found in codepack {}'.format(
        blue(codepack_.name)))


@codepack.command()
@click.argument('codepack_path', type=click.Path(exists=True), required=False)
# Local path of the Codepack to be described
def describe(codepack_path):
    """Shows details of a Codepack.

    Print details of the specified Codepack, including its name, description,
    project and targets.
    """
    if not codepack_path:
        codepack_path = '.'
    codepack_ = Codepack(codepack_path)
    codepack_.describe()


@codepack.command()
@click.argument('codepack_path', type=click.Path(exists=True), required=False)
# Local path of the Codepack to be run
@click.option('-p',
              '--project',
              type=str,
              metavar='PROJECT_NAME',
              help='Name of the project to be run in.')
@click.option('-t',
              '--target',
              type=str,
              metavar='TARGET_NAME',
              help='Name of the target to be run.')
@click.option('-v',
              '--verbose',
              is_flag=True,
              default=False,
              help='Increase verbosity.')
@click.option('-W',
              '--wait-timeout',
              type=int,
              help='Set Pod waiting timeout in seconds.')
@click.pass_context
# @click.option('--watch', help='watch resource status')
def run(ctx, codepack_path, project, target, verbose, wait_timeout):
    """Runs a target of a Codepack.

    The process is as follows:

        1. Load and parse the Codepack config file.

        2. Check validity of Codepack config.

        3. Parse dependencies of the target to run, sort them topologically
           and execute them in sequence.

        4. For each target, execute its actions in sequence.
    """
    del ctx, verbose  # Unused
    if wait_timeout:
        client.WAIT_TIMEOUT = wait_timeout

    if client.AUTHENTICATION_METHOD == 'incluster':
        current_ns = client.get_current_namespace()
        if project is not None and project != current_ns:
            eprint('Cannot specify project ({}) other than current project '
                   '({})'.format(project, current_ns))
        project = current_ns

    if not codepack_path:
        codepack_path = '.'
    codepack_ = Codepack(codepack_path)
    codepack_.run(target, project)


@codepack.command()
@click.option('-g',
              '--get',
              'get_item',
              type=str,
              metavar='KEY',
              help='Get CLI config item.')
@click.option('-l',
              '--list',
              'list_items',
              is_flag=True,
              default=False,
              help='List CLI config items.')
@click.option('-s',
              '--set',
              'set_item',
              type=str,
              metavar='KEY=VALUE',
              multiple=True,
              help='Set CLI config item.')
@click.pass_context
def config(ctx, get_item, list_items, set_item):
    """Gets and sets Codepack CLI config."""
    if list_items:
        click.echo(CONFIG)
        return
    if get_item:
        if get_item not in CONFIG_ITEMS:
            eprint('Invalid CLI config item: {}'.format(get_item))
        click.echo('{}={}'.format(get_item, getattr(CONFIG, get_item)))
        return
    if set_item:
        for kv in set_item:
            try:
                k, v = kv.split('=', maxsplit=1)
            except ValueError:
                eprint('Usage: codepack config -s <key>=<value>', prefix=False)
            if k not in CONFIG_ITEMS:
                eprint('Invalid CLI config item: {}'.format(k))
            try:
                v = int(v)
            except ValueError:
                pass
            setattr(CONFIG, k, v)
            click.echo(kv)
            CONFIG.save_config_file()
        click.echo('config items set')
        return
    click.echo(config.get_help(ctx))


@codepack.command()
def monitor():
    pass
