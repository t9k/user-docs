"""Initialization of CLI config."""

import os
from pathlib import Path

import yaml

from codepack.utils import eprint

CONFIG_FILE_PATH = os.path.join(str(Path.home()), '.t9k',
                                'codepack-config.yaml')
CONFIG_ITEMS = ['api_key', 'copy_pod_image']


class Config():
    """CLI config."""
    def __init__(self):
        object.__setattr__(self, '_items', {})
        self.load_config_file()

    def load_config_file(self):
        """Loads CLI config items from CLI config file.

        If CLI config file does not exist, makes a default one.
        """
        if not os.path.isfile(CONFIG_FILE_PATH):
            self.make_config_file()
        with open(CONFIG_FILE_PATH, 'rt') as f:
            config = yaml.safe_load(f)
        for k in config.keys():
            if k not in CONFIG_ITEMS:
                eprint('invalid CLI config item: {}'.format(k))
        self._items.update(config)

    def save_config_file(self):
        """Saves CLI config items to CLI config file."""
        with open(CONFIG_FILE_PATH, 'wt') as f:
            f.write(yaml.dump(self._items))

    def __getattr__(self, attr: str):
        return self._items[attr]

    def __setattr__(self, attr: str, value):
        self._items[attr] = value

    def __str__(self):
        s = ''
        for k, v in self._items.items():
            s += '{}={}\n'.format(k, v)
        s = s[:-1]
        return s

    @staticmethod
    def make_config_file():
        """Makes a default CLI config file."""
        initial_configs = {i: None for i in CONFIG_ITEMS}
        dirname = os.path.dirname(CONFIG_FILE_PATH)
        if not os.path.isdir(dirname):
            os.makedirs(dirname)
        with open(CONFIG_FILE_PATH, 'xt') as f:
            f.write(yaml.dump(initial_configs))


CONFIG = Config()
