"""Implementation of verb apply & create."""

import os

from kubernetes.utils.create_from_yaml import FailToCreateError

from codepack.client import (create_from_dir, create_from_yaml, delete_by_dir,
                             delete_by_yaml, FailToDeleteError)
from codepack.utils import eprint


def parse_path(func):
    """Parses arg `path` and check whether each path exists."""
    def wrapper(path, *args, **kwargs):
        if isinstance(path, list):
            for p in path:
                wrapper(p, *args, **kwargs)
        elif isinstance(path, str):
            if os.path.exists(path):
                func(path, *args, **kwargs)
            else:
                eprint('Path not exist: {}'.format(path))
        else:
            raise TypeError('Not supported type for arg `path`: {}'.format(
                type(path)))

    return wrapper


@parse_path
def apply(path, ns):
    """Applies configs to resources by config files.

    The difference between `apply()` and `create()` is that when the resource
    to be created already exists, `apply()` updates it, while `create()`
    creates a new one with name suffixed with current datetime, or errors out.

    Args:
        path:
            Path of YAML config files, could be path of a file or path of a
            directory containing files.
        ns:
            Namespace to be created in.
    """
    if os.path.isfile(path):
        create_from_yaml(ns, path, conflict_strategy='patch')
    elif os.path.isdir(path):
        create_from_dir(ns, path, conflict_strategy='patch')
    else:
        raise RuntimeError(
            'Path is neither a file or a directory: {}'.format(path))


@parse_path
def create(path, ns, new=True):
    """Creates resources from config files.

    Args:
        path:
            Path of YAML config files, could be path of a file or path of a
            directory containing files.
        ns:
            Namespace to be created in.
        new:
            If True, create the resource with name suffixed with current
            datetime if the original name already exists; if False, just
            error out.
    """
    # Catch `FailToCreateError` from `create_from_yaml()` or `create_from_dir()`,
    # print the messages and API exceptions clearly, and error out.
    try:
        if os.path.isfile(path):
            create_from_yaml(ns,
                             path,
                             conflict_strategy='new' if new else 'error')
        elif os.path.isdir(path):
            create_from_dir(ns,
                            path,
                            conflict_strategy='new' if new else 'error')
        else:
            raise RuntimeError(
                'Path is neither a file or a directory: {}'.format(path))
    except FailToCreateError as e:
        msg = ''
        for api_exception in e.api_exceptions:
            if isinstance(api_exception, str):
                msg += api_exception + '\n'
            else:
                msg += 'Error from server ({}): {}\n'.format(
                    api_exception.reason, api_exception.body)
        eprint(msg[:-1])


@parse_path
def delete(path, ns, ignore_error=True):
    """Deletes resources by config files.

    Args:
        path:
            Path of YAML config files, could be path of a file or path of a
            directory containing files.
        ns:
            Namespace to be deleted in.
        ignore_error:
            If True, ignore any FailToDeleteError.
    """
    # Catch `FailToCreateError` from `create_from_yaml()` or `create_from_dir()`,
    # print the messages and API exceptions clearly, and error out.
    try:
        if os.path.isfile(path):
            delete_by_yaml(ns, path, ignore_error)
        elif os.path.isdir(path):
            delete_by_dir(ns, path, ignore_error)
        else:
            raise RuntimeError(
                'Path is neither a file or a directory: {}'.format(path))
    except FailToDeleteError as e:
        msg = ''
        for api_exception in e.api_exceptions:
            if isinstance(api_exception, str):
                msg += api_exception + '\n'
            else:
                msg += 'Error from server ({}): {}\n'.format(
                    api_exception.reason, api_exception.body)
        eprint(msg[:-1])
