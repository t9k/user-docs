"""Correspondence with TensorStack AI Platform."""

from datetime import datetime
import os
import re
import time

import click
from kubernetes import client as klient
from kubernetes import config as konfig
from kubernetes import stream
from kubernetes import utils as kutils
from kubernetes.client.rest import ApiException
from kubernetes.utils.create_from_yaml import FailToCreateError
import yaml

from codepack.config import CONFIG
from codepack.utils import purple, eprint

if ('KUBERNETES_SERVICE_HOST' in os.environ) and ('KUBERNETES_SERVICE_PORT'
                                                  in os.environ):
    konfig.load_incluster_config()
    AUTHENTICATION_METHOD = 'incluster'
else:
    config_file_path = os.getenv('KUBECONFIG', '~/.kube/config')
    config_file_path = os.path.expanduser(config_file_path)
    if not os.path.isfile(config_file_path):
        eprint('kubeconfig file not found at {}'.format(config_file_path))
    try:
        konfig.load_kube_config()
    except konfig.config_exception.ConfigException:
        eprint('Invalid kubeconfig file at {}'.format(config_file_path))
    AUTHENTICATION_METHOD = 'kubeconfig'

v1 = klient.CoreV1Api()
api_client = klient.ApiClient()
custom_objects_api = klient.CustomObjectsApi(api_client)
verbose = False

K8S_API_VERSION = ['v1', 'apps/v1', 'batch/v1beta1', 'extensions/v1beta1']
T9K_API_VERSION = ['tensorstack.dev/v1beta1', 'batch.tensorstack.dev/v1beta1']

COPY_POD_NAME_PREFIX = 'codepack-copy-pod-'
COPY_POD_PORT = 22
COPY_SECRET_NAME = 'codepack-ssh-config'
SOCKET_BUFFER_SIZE = 4096
WAIT_TIMEOUT = 300


def create_copy_pod(ns, pvc_name, public_key):
    """Creates a Pod for copying files.

    Returns:
        Name of the created Pod.
    """
    create_copy_secret(ns, public_key)
    ret = create_pod(ns, create_copy_pod_manifest(pvc_name))
    return ret.metadata.name


def create_copy_pod_manifest(pvc_name):
    """Creates a manifest of Pod for copying files."""
    if CONFIG.copy_pod_image is None:
        eprint('CLI config item copy_pod_image has no value')
    return klient.V1Pod(
        api_version='v1',
        kind='Pod',
        metadata=klient.V1ObjectMeta(generate_name=COPY_POD_NAME_PREFIX),
        spec=klient.V1PodSpec(
            restart_policy='Never',
            containers=[
                klient.V1Container(
                    name='sync',
                    image=CONFIG.copy_pod_image,
                    ports=[
                        klient.V1ContainerPort(name='ssh',
                                               protocol='TCP',
                                               container_port=COPY_POD_PORT)
                    ],
                    volume_mounts=[
                        klient.V1VolumeMount(
                            name='ssh-config',
                            # TODO: compare running as root v.s. normal user
                            mount_path='/root/.ssh/authorized_keys',
                            sub_path='authorized_keys'),
                        klient.V1VolumeMount(name='pvc', mount_path='/mnt')
                    ],
                    resources=klient.V1ResourceRequirements(limits={
                        'cpu': '1',
                        'memory': '1Gi'
                    }))
            ],
            volumes=[
                klient.V1Volume(name='ssh-config',
                                secret=klient.V1SecretVolumeSource(
                                    secret_name=COPY_SECRET_NAME,
                                    default_mode=0o600)),
                klient.V1Volume(
                    name='pvc',
                    persistent_volume_claim=klient.
                    V1PersistentVolumeClaimVolumeSource(claim_name=pvc_name))
            ]))


def create_copy_secret(ns, public_key):
    """Creates a Secret for copying files."""
    try:
        delete_secret(ns, COPY_SECRET_NAME)
    except ApiException as e:
        if e.status != 404:
            raise e
    create_secret(ns, create_copy_secret_manifest(public_key))


def create_copy_secret_manifest(public_key):
    """Creates a manifest of Secret for copying files."""
    return klient.V1Secret(api_version='v1',
                           kind='Secret',
                           metadata=klient.V1ObjectMeta(name=COPY_SECRET_NAME),
                           string_data={'authorized_keys': str(public_key)})


def create_crd(config_dict):
    """Creates a CRD by given config dict."""
    group, version = config_dict['apiVersion'].split('/', maxsplit=1)
    ns = config_dict['metadata']['namespace']
    plural = config_dict['kind'].lower() + 's'

    try:
        ret = custom_objects_api.create_namespaced_custom_object(
            group=group,
            version=version,
            namespace=ns,
            plural=plural,
            body=config_dict)
    except ApiException as e:
        raise FailToCreateError([e]) from e

    return ret


def create_from_dict(config_dict):
    """Creates a resource by given config dict."""
    if 'apiVersion' not in config_dict:
        raise ValueError('Required field "apiVersion" not found in config')

    if config_dict['apiVersion'] in K8S_API_VERSION:
        # TODO: check the "kind" field as well
        k8s_object = kutils.create_from_dict(api_client, config_dict)
    elif config_dict['apiVersion'] in T9K_API_VERSION:
        k8s_object = create_crd(config_dict)
    else:
        raise ValueError('Not supported API version: {}'.format(
            config_dict['apiVersion']))

    return k8s_object


def create_from_dir(ns, dir_path, conflict_strategy):
    """Creates resources by YAML config files under specified dir.

    Args:
        ns:
            Namespace to be created in.
        dir_path:
            Path of a directory containing YAML config files.
        conflict_strategy:
            Strategy adopted when the resource to be created already exists,
            must be one of `'skip'`, `'error'` and `'new'`. If `'skip'`, skip
            the creation; if `'error'`, error out; if `'new'`, create a new
            one with name suffixed with current datetime.
    """
    if not dir_path:
        raise ValueError('argument `dir_path` must be provided')
    elif not os.path.isdir(dir_path):
        raise ValueError('argument `dir_path` must be a path to directory')

    file_paths = [
        os.path.join(dir_path, i) for i in sorted(os.listdir(dir_path))
        if os.path.isfile(os.path.join(dir_path, i)) and (
            i.endswith('yaml') or i.endswith('yml'))
    ]
    if not file_paths:
        click.echo(('No YAML config files are found in directory {},'
                    ' create nothing').format(dir_path))
        return

    failures = []
    k8s_objects_all = []
    for file_path in file_paths:
        # Create resources with a YAML config file by calling `create_from_yaml()`.
        #
        # For each YAML config file, collect its API exceptions of `FailToCreateError`
        # and add them to `failures` list.
        #
        # Finally, if `failures` list is not empty, raise a `FailToCreateError`
        # with it.
        try:
            k8s_objects = create_from_yaml(ns, file_path, conflict_strategy)
            k8s_objects_all.extend(k8s_objects)
        except FailToCreateError as e:
            failures.extend(e.api_exceptions)
    if failures:
        raise FailToCreateError(failures)
    return k8s_objects_all


def create_from_yaml(ns, file_path, conflict_strategy):
    """Creates a resource by specified YAML config file.

    Args:
        ns:
            Namespace to be created in.
        file_path:
            Path of a YAML config file.
        conflict_strategy:
            Strategy adopted when the resource to be created already exists,
            must be one of `'skip'`, `'error'`, `'new'` and `'patch'`.
            If `'skip'`, skip the creation; if `'error'`, error out;
            if `'new'`, create a new one with name suffixed with current
            datetime; if `'patch'`, update the existing resource with this
            config.
    """
    if not file_path:
        raise ValueError('argument `file_path` must be provided')
    elif not os.path.isfile(file_path):
        raise ValueError('argument `file_path` must be a path to file')

    with open(file_path, 'rt') as f:
        config_dicts = yaml.safe_load_all(f)

        failures = []
        k8s_objects = []
        for config_dict in config_dicts:
            if config_dict is None:
                continue

            # Create a resource with a config dict by calling `create_from_dict()`.
            #
            # Only handle `FailToCreateError` with one API exception of code 409
            # (reason "Conflict"), for all other cases, directly raise the error.
            #
            # Based on current conflict strategy:
            # * If "skip", just skip this creation.
            # * If "error", add the API exception to the `failures` list.
            # * If "new", rename the resource and create again. If another
            #   error is raised, directly raise it.
            # * If "patch", update the existing resource with this config.
            #   If another error is raised, directly raise it.
            # Finally, if `failures` list is not empty, raise a `FailToCreateError`
            # with it.
            try:
                config_dict['metadata']['namespace'] = ns
                k8s_object = create_from_dict(config_dict)
                k8s_objects.append(k8s_object)
                click.echo('{} {} created'.format(*purple(
                    config_dict['kind'], config_dict['metadata']['name'])))
            except FailToCreateError as e:
                if len(e.api_exceptions) >= 2:  # multiple errors
                    raise e
                else:  # single error
                    if e.api_exceptions[
                            0].reason == 'Conflict':  # error 409 conflict
                        if conflict_strategy == 'skip':
                            click.echo(
                                '{} with the name {} already exists, skip'.
                                format(
                                    *purple(config_dict['kind'],
                                            config_dict['metadata']['name'])))
                            continue
                        elif conflict_strategy == 'error':
                            msg = '{} with the name {} already exists, abort'.format(
                                *purple(config_dict['kind'],
                                        config_dict['metadata']['name']))
                            click.echo(msg)
                            failures.append(click.unstyle(msg)[:-7])
                        elif conflict_strategy == 'new':
                            name_with_datetime = config_dict['metadata'][
                                'name'] + '-' + datetime.now().strftime(
                                    '%Y%m%d-%H%M%S-%f')
                            click.echo(
                                ('{} with the name {} already exists, use '
                                 'alternative name {}').format(
                                     *purple(config_dict['kind'],
                                             config_dict['metadata']['name'],
                                             name_with_datetime)))
                            config_dict['metadata'][
                                'name'] = name_with_datetime
                            k8s_object = create_from_dict(config_dict)
                            k8s_objects.append(k8s_object)
                            click.echo('{} {} created'.format(
                                *purple(config_dict['kind'],
                                        config_dict['metadata']['name'])))
                        elif conflict_strategy == 'patch':
                            k8s_object = patch_by_dict(config_dict)
                        else:
                            raise ValueError(
                                'Not supported conflict strategy: {}'.format(
                                    conflict_strategy)) from e
                    else:  # other error
                        raise e
    if failures:
        raise FailToCreateError(failures)
    return k8s_objects


def create_pod(ns, manifest):
    """Creates a Pod by given manifest in specified namespace."""
    return v1.create_namespaced_pod(ns, manifest)


def create_secret(ns, manifest):
    """Creates a Secret by given manifest in specified namespace."""
    return v1.create_namespaced_secret(ns, manifest)


def delete_by_dict(config_dict):
    """Deletes a resource by given config dict."""
    if 'apiVersion' not in config_dict:
        raise ValueError('Required field "apiVersion" not found in config')

    if config_dict['apiVersion'] in K8S_API_VERSION:
        # TODO: check the "kind" field as well
        k8s_object = delete_resource(config_dict)
    elif config_dict['apiVersion'] in T9K_API_VERSION:
        k8s_object = delete_crd(config_dict)
    else:
        raise ValueError('Not supported API version: {}'.format(
            config_dict['apiVersion']))

    return k8s_object


def delete_by_dir(ns, dir_path, ignore_error):
    """Deletes resources by YAML config files under specified dir.

    Args:
        ns:
            Namespace to be deleted in.
        dir_path:
            Path of a directory containing YAML config files.
        ignore_error:
            If True, ignore any FailToDeleteError.
    """
    if not dir_path:
        raise ValueError('argument `dir_path` must be provided')
    elif not os.path.isdir(dir_path):
        raise ValueError('argument `dir_path` must be a path to directory')

    file_paths = [
        os.path.join(dir_path, i) for i in sorted(os.listdir(dir_path))
        if os.path.isfile(os.path.join(dir_path, i)) and (
            i.endswith('yaml') or i.endswith('yml'))
    ]
    if not file_paths:
        click.echo(('No YAML config files are found in directory {},'
                    ' delete nothing').format(dir_path))
        return

    failures = []
    rets_all = []
    for file_path in file_paths:
        # Delete resources with a YAML config file by calling `delete_by_yaml()`.
        #
        # For each YAML config file, collect its API exceptions of `FailToDeleteError`
        # and add them to `failures` list.
        #
        # Finally, if `failures` list is not empty, raise a `FailToDeleteError`
        # with it.
        try:
            rets = delete_by_yaml(ns, file_path, ignore_error)
            rets_all.extend(rets)
        except FailToDeleteError as e:
            failures.extend(e.api_exceptions)
    if failures:
        raise FailToDeleteError(failures)
    return rets_all


def delete_by_yaml(ns, file_path, ignore_error):
    """Deletes a resource by specified YAML config file.

    Args:
        ns:
            Namespace to be deleted in.
        file_path:
            Path of a YAML config file.
        ignore_error:
            If True, ignore any FailToDeleteError.
    """
    if not file_path:
        raise ValueError('argument `file_path` must be provided')
    elif not os.path.isfile(file_path):
        raise ValueError('argument `file_path` must be a path to file')

    with open(file_path, 'rt') as f:
        config_dicts = yaml.safe_load_all(f)
        rets = []
        for config_dict in config_dicts:
            if config_dict is None:
                continue
            try:
                config_dict['metadata']['namespace'] = ns
                ret = delete_by_dict(config_dict)
                rets.append(ret)
                click.echo('{} {} deleted'.format(*purple(
                    config_dict['kind'], config_dict['metadata']['name'])))
            except FailToDeleteError as e:
                if not ignore_error:
                    raise e
                else:
                    click.echo('{} {} not exist'.format(*purple(
                        config_dict['kind'], config_dict['metadata']['name'])))

    return rets


def delete_crd(config_dict):
    """Deletes a CRD by its namespace and name."""
    group, version = config_dict['apiVersion'].split('/', maxsplit=1)
    ns = config_dict['metadata']['namespace']
    plural = config_dict['kind'].lower() + 's'
    name = config_dict['metadata']['name']

    try:
        ret = custom_objects_api.delete_namespaced_custom_object(
            group=group,
            version=version,
            namespace=ns,
            plural=plural,
            name=name)
    except ApiException as e:
        raise FailToDeleteError([e]) from e

    return ret


def delete_pod(ns, name):
    """Deletes a Pod by its namespace and name."""
    return v1.delete_namespaced_pod(name, ns)


def delete_resource(config_dict):
    """Deletes a K8s resource by given config dict.

    Refer to `kubernetes.utils.create_from_yaml.create_from_yaml_single_item()`,
    see https://github.com/kubernetes-client/python/blob/master/kubernetes/utils/create_from_yaml.py#L229.
    """
    if config_dict['apiVersion'] == 'v1':
        group = 'core'
        version = 'v1'
    else:
        group, version = config_dict['apiVersion'].split('/', maxsplit=1)

    api_to_use = '{}{}Api'.format(group.capitalize(), version.capitalize())
    api = getattr(klient, api_to_use)(api_client)

    kind = config_dict['kind']
    kind = re.sub(r'(.)([A-Z][a-z]+)', r'\1_\2', kind)
    kind = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', kind).lower()

    try:
        if hasattr(api, 'delete_namespaced_{}'.format(kind)):
            ns = config_dict['metadata']['namespace']
            name = config_dict['metadata']['name']
            ret = getattr(api,
                          'delete_namespaced_{}'.format(kind))(name=name,
                                                               namespace=ns)
        else:
            name = config_dict['metadata']['name']
            ret = getattr(api, 'delete_{}'.format(kind))(name=name)
    except ApiException as e:
        raise FailToDeleteError([e]) from e

    return ret


def delete_secret(ns, name):
    """Deletes a Secret by its namespace and name."""
    return v1.delete_namespaced_secret(name, ns)


def get_crd(ns, group, version, plurals):
    """Gets info of all CRDs of specified type in specified namespace.

    Args:
        ns: Namespace of the CRD.
        group: Group name of the CRD.
        version: Version of the CRD.
        plurals: Plural name of the CRD.

    Examples:

        Create a Notebook:
        ```python
        notebooks = get_crd('demo', 'tensorstack.dev', 'v1beta1', 'notebooks')
        ```
    """
    ret = custom_objects_api.list_namespaced_custom_object(
        group, version, ns, plurals)
    return ret['items']


def get_current_namespace():
    """Gets current namespace if this module is run in a Pod.

    Refer to https://github.com/kubernetes-client/python/issues/363.
    """
    ns_path = '/var/run/secrets/kubernetes.io/serviceaccount/namespace'
    if os.path.exists(ns_path):
        with open(ns_path) as f:
            return f.read().strip()

    raise RuntimeError('Failed to get current project, Secret of service '
                       'account token not mounted')


def get_pod(ns):
    """Gets info of all Pods in specified namespace."""
    ret = v1.list_namespaced_pod(ns)
    return ret.items


def patch_by_dict(config_dict):
    """Patches a resource by given config dict."""
    if 'apiVersion' not in config_dict:
        raise ValueError('Required field "apiVersion" not found in config')

    if config_dict['apiVersion'] in K8S_API_VERSION:
        # TODO: check the "kind" field as well
        k8s_object = patch_resource(config_dict)
    elif config_dict['apiVersion'] in T9K_API_VERSION:
        k8s_object = patch_crd(config_dict)
    else:
        raise ValueError('Not supported API version: {}'.format(
            config_dict['apiVersion']))

    return k8s_object


def patch_crd(config_dict):
    """Patches a CRD by given config dict."""
    group, version = config_dict['apiVersion'].split('/', maxsplit=1)
    ns = config_dict['metadata']['namespace']
    plural = config_dict['kind'].lower() + 's'
    name = config_dict['metadata']['name']

    try:
        ret = custom_objects_api.patch_namespaced_custom_object(
            group=group,
            version=version,
            namespace=ns,
            plural=plural,
            name=name,
            body=config_dict)
    except ApiException as e:
        raise FailToCreateError([e]) from e

    return ret


def patch_resource(config_dict):
    """Patches a K8s resource by given config dict.

    Refer to `kubernetes.utils.create_from_yaml.create_from_yaml_single_item()`,
    see https://github.com/kubernetes-client/python/blob/master/kubernetes/utils/create_from_yaml.py#L229.
    """
    if config_dict['apiVersion'] == 'v1':
        group = 'core'
        version = 'v1'
    else:
        group, version = config_dict['apiVersion'].split('/', maxsplit=1)

    api_to_use = '{}{}Api'.format(group.capitalize(), version.capitalize())
    api = getattr(klient, api_to_use)(api_client)

    kind = config_dict['kind']
    kind = re.sub(r'(.)([A-Z][a-z]+)', r'\1_\2', kind)
    kind = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', kind).lower()

    if hasattr(api, 'patch_namespaced_{}'.format(kind)):
        ns = config_dict['metadata']['namespace']
        name = config_dict['metadata']['name']
        ret = getattr(api,
                      'patch_namespaced_{}'.format(kind))(name=name,
                                                          namespace=ns,
                                                          body=config_dict)
    else:
        name = config_dict['metadata']['name']
        ret = getattr(api, 'patch_{}'.format(kind))(name=name,
                                                    body=config_dict)

    return ret


def port_forward(ns, pod_name, port):
    """Forwards a port of Pod and returns a Unix socket."""
    pf = stream.portforward(v1.connect_get_namespaced_pod_portforward,
                            pod_name,
                            ns,
                            ports=str(port))  # forward one port only
    return pf.socket(port)


def read_pod(ns, name):
    """Gets info of specified Pod."""
    try:
        ret = v1.read_namespaced_pod(name, ns)
    except ApiException as e:
        if e.status != 404:
            raise e
        else:
            raise RuntimeError('Pod {} in project {} does not exist.'.format(
                name, ns)) from e
    return ret


def wait_for_pod_to_run(ns, name):
    """Waits for the specified Pod to run.

    Raises:
        RuntimeError:
            The Pod succeeds, fails or has been pending until timeout.
    """
    wait_time = 0
    while True:
        pod = read_pod(ns, name)
        if pod.status.phase == 'Running':
            return
        elif pod.status.phase == 'Pending':
            if wait_time >= WAIT_TIMEOUT:
                raise RuntimeError(
                    'Pod {} has been pending until timeout'.format(name))
        elif pod.status.phase == 'Succeeded':
            raise RuntimeError('Pod {} succeeded unexpectedly'.format(name))
        elif pod.status.phase == 'Failed':
            raise RuntimeError('Pod {} failed unexpectedly'.format(name))
        else:  # 'Unknown'
            raise RuntimeError(
                'The state of Pod {} could not be obtained'.format(name))

        wait_time += 1
        time.sleep(1)


class FailToDeleteError(FailToCreateError):
    pass


if __name__ == '__main__':
    pass
