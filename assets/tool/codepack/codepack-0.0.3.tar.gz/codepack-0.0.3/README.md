# Codepack

## 安装

执行以下命令安装：

```shell
pip install -e .
```

此外还需要安装 3.1.0 及以上版本的 rsync。macOS 执行以下命令安装：

```shell
brew install rsync
```

基于 Debian 的 Linux 发行版执行以下命令安装：

```shell
apt-get install rsync
```

基于 rpm 的 Linux 发行版执行以下命令安装：

```shell
yum install rsync
```

## 运行（测试）

`examples/mnist-keras/` 是一个用于测试的 Codepack 示例，目前尚不完全。

执行以下命令以查看该示例：

```shell
$ codepack describe examples/mnist-keras
Codepack Details:
name: mnist-keras
description: A simple image classifier based on CNN using tf2.
project: dev-xyx
targets:
  - prepare-env
  - copy-file
  - create-notebook
  - run-distributed-training
  - run-e2e-workflow
```

执行以下命令运行一个 target：

```shell
# 创建一个 PVC 和绑定它的 Notebook, 复制 Codepack 到 PVC 中, 用于快速开始模型开发
$ codepack run examples/mnist-keras -t create-notebook -p <project>

# 创建一个 PVC, 复制 Codepack 到 PVC 中, 创建一个 TrainingJob, 用于快速启动训练
$ codepack run examples/mnist-keras -t run-distributed-training -p <project>
```

## 进度

### 计划

* verb 实现：
    * copy（暴露 rsync 更多选项）
    * mkdir
* 监视资源
* 增加成功/失败判定，错误处理
* 使用 API Key 连接到平台
* 使用 t9kconfig 连接到平台

### 完成

* 子命令实现：
    * `check`
    * `describe`
    * `run`
    * `config`
* verb 实现：
    * apply
    * copy
    * create
* 使用 kubeconfig 连接到 apiserver

### 问题

* Kubernetes Python Client 的 port forward proxy 偶尔会出错：`websocket._exceptions.WebSocketConnectionClosedException: Connection is already closed.`，即连接到 Pod 的 web socket 断开，尚未检查其原因。
* rsync 到 PVC 的路径如果包含不存在的子目录，那么 rsync 命令会自动创建这些子目录而使得它们的权限变为 `root`。

## 参考

* [设计文档](https://docs.google.com/document/d/1S4ZAeuF4JyM-BNnj2T9Z45raE0TGZ3uOsSCM3EcT204/edit?usp=sharing)
