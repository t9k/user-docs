def k8s_object_ref(namespace: str, name: str):
    return {
        "namespace": namespace,
        "name": name
    }


def gen_s3_fileset_storage(secret_name: str, secret_namespace: str):
    return {
        "s3SecretRef": k8s_object_ref(secret_namespace, secret_name)
    }


def gen_minio_fileset_storage(host_config: str, bucket: str, path: str, secret_name: str, secret_namespace: str):
    return {
        "minioSecretRef": k8s_object_ref(secret_namespace, secret_name),
        "hostConfig": host_config,
        "bucket": bucket,
        "path": path
    }


def gen_pvc_fileset_storage(name: str, namespace: str, path: str):
    return {
        "pvcRef": k8s_object_ref(namespace, name),
        "path": path
    }


def gen_local_path_fileset(local_path: str):
    return {
        "localPath": local_path
    }
