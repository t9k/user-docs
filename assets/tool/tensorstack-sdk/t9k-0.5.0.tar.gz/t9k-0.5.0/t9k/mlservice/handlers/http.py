from ..transformer import MLTransformer

from http import HTTPStatus
import json
import tornado.web
from typing import Dict

class LivenessHandler(tornado.web.RequestHandler):
    def get(self):
        self.write("Alive")

class ListHandler(tornado.web.RequestHandler):
    def initialize(self, transformers: Dict[str, MLTransformer]):
        self.transformers = transformers  # pylint:disable=attribute-defined-outside-init

    def get(self):
        self.write(json.dumps(list(self.transformers.values())))

class HTTPHandler(tornado.web.RequestHandler):
    def initialize(self, transformers: Dict[str, MLTransformer]):
        self.transformers = transformers # pylint:disable=attribute-defined-outside-init

    def get_transformer(self, name: str):
        if name not in self.transformers:
            raise tornado.web.HTTPError(
                status_code=HTTPStatus.NOT_FOUND,
                reason="Transformer with model name %s does not exist." % name
            )
        transformer = self.transformers[name]
        return transformer

    def loadBody(self, request):
        return request.body

class PredictHandler(HTTPHandler):
    def post(self, name: str):
        transformer = self.get_transformer(name)
        body = self.loadBody(self.request)
        data = transformer.preprocess(body)
        response = transformer.predict(data)
        response = transformer.postprocess(response)
        self.write(json.dumps(response))
