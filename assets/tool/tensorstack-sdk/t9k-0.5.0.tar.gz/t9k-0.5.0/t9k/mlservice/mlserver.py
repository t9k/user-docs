from .option import args
from .transformer import MLTransformer
from .handlers.http import ListHandler,LivenessHandler,PredictHandler

import logging
import tornado.ioloop
import tornado.web
import tornado.httpserver
from typing import List

class MLServer():
    """MLServer is the server of Transformer.
    
    Typical usage example:

    class Transformer(mlservice.MLTransformer):
        ...

    transform = Transformer()
    server = mlservice.MLServer()
    server.start(transformers=[transform])

    Attributes:
        self.registered_transformers: 
            stores registered transformers, transformer is registered by self.register_transformer.
        self.http_port: 
            listening port of MLServer.
        self.num_processes: 
            num_processes for tornado, detail to see: https://www.tornadoweb.org/en/stable/process.html#module-tornado.process.
    """
    def __init__(self, http_port: int = args.http_port,
                 num_processes: int = args.num_processes):
        self.registered_transformers = {}
        self.http_port = http_port
        self.num_processes = num_processes
        self._http_server = None

    def create_application(self):
        """create http server
        """
        return tornado.web.Application([
            # Server Liveness API returns 200 if server is alive.
            (r"/", LivenessHandler),
            (r"/v1/models",
             ListHandler, dict(transformers=self.registered_transformers)),
            (r"/v1/models/([a-zA-Z0-9_-]+):predict",
             PredictHandler, dict(transformers=self.registered_transformers)),
        ])

    def start(self, transformers: List[MLTransformer]):
        """start http server
        """
        for transformer in transformers:
            self.register_transformer(transformer)

        self._http_server = tornado.httpserver.HTTPServer(
            self.create_application())

        logging.info("Listening on port %s", self.http_port)
        self._http_server.bind(self.http_port)
        logging.info("Will fork %d num_processes", self.num_processes)
        self._http_server.start(self.num_processes)
        tornado.ioloop.IOLoop.current().start()
    
    def register_transformer(self, transformer: MLTransformer):
        """register transformer"""
        if not transformer.name:
            raise Exception(
                "Failed to register transformer, transformer.name must be provided.")
        self.registered_transformers[transformer.name] = transformer
        logging.info("Successfully registered transformer: %s", transformer.name)
