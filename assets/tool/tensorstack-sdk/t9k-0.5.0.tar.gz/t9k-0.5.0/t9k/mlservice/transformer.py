from .option import args

import json
import logging
import requests
import tornado.web
from typing import Dict

PREDICTOR_URL_FORMAT = "http://{0}/v1/models/{1}:predict"

class MLTransformer():
    """MLTransformer is the core class for Transformer.

    Usage: 
    Create a Class inheriting MLTransformer, overwrite method:
    1. "preprocess" for your preprocessing
    2. "postprocess" for your postprocessing

    Attributes:
        name: 
            the Transformer's corresponding model name
        predictor_host: 
            host of predictor,this value will be used to set PREDICTOR_URL_FORMAT's {0}
    """
    def __init__(self, name: str = args.model_name,
                 predictor_host:str = args.predictor_host):
        self.name = name
        self.predictor_host = predictor_host

    def preprocess(self, requestData: any) -> Dict:
        """Preprocess requestData to a json format dict which be passed to self.predict as arg data.
        Args:
            requestData: bytes of request body from user.
        """
        return requestData

    def postprocess(self, responseData: any) -> Dict:
        """postprocess responseData to a json format dict which will be replied to user.
        Args:
            responseData: json format dict of response from predictor.
        """
        return responseData

    def predict(self, data: Dict) -> Dict:
        """send preprocessed data to predictor
        Args:
            data: preprocessed data by self.preprocess.
        Return:
            Dict: response from predictor, it will be passed to self.postprocess as arg responseData.
        """
        if self.predictor_host is None:
            logging.error("predictor_host is missing")
            raise NotImplementedError

        response = requests.post(
            PREDICTOR_URL_FORMAT.format(self.predictor_host, self.name),
            json.dumps(data)
        )
        if response.status_code != 200:
            raise tornado.web.HTTPError(
                status_code=response.status_code,
                reason=response.content)
        return response.json()
