"""Utility functions for printing colored message."""

import functools
from typing import List, Union

import click


def colored(*s,
            color: str = 'black',
            bold: bool = False,
            underline: bool = False) -> Union[List[str], str]:
    """Makes the text colored and optionally bold and underlined.

    Examples:

        Single arg:
        ```
        msg = '{} created'.format(colored(name))
        ```

        Multiple args:
        ```
        msg = '{} {} created'.format(*colored(kind, name))
        ```
    """
    if len(s) > 1:
        return [
            click.style(i, fg=color, bold=bold, underline=underline) for i in s
        ]
    elif len(s) == 1:
        return click.style(s[0], fg=color, bold=bold, underline=underline)


blue = functools.partial(colored, color='blue')
cyan = functools.partial(colored, color='cyan')
magenta = functools.partial(colored, color='magenta')
red = functools.partial(colored, color='red')
yellow = functools.partial(colored, color='yellow')
black = colored
