"""Utility functions for querying information of Git repo."""

import inspect
import os
from typing import Any, Dict, Optional

from t9k.utils.file_utils import abspath, relpath
from t9k.utils.module_utils import get_module

git = get_module(name='git')


def get_git_repo_data() -> Dict[str, Any]:
    if not git:
        return {}

    # get the frame that represents the caller of `apis.create_trial()`
    frame = inspect.stack()[3]
    entry_path = frame[0].f_code.co_filename
    entry_path = os.path.realpath(entry_path)

    local_path = _get_local_path(entry_path)
    return {
        'local_path': local_path,
        'remote_url': _get_remote_url(entry_path),
        'branch': _get_active_branch(entry_path),
        'commit': _get_latest_commit(entry_path),
        'is_dirty': _get_is_dirty(entry_path),
        'entrypoint': relpath(entry_path, local_path),
    }


def _get_local_path(path: str) -> Optional[str]:
    """Gets local path of Git repo corresponded with specified path.

    If the specified path does not correspond with any Git repo, return `None`.
    """
    try:
        repo = git.Repo(path, search_parent_directories=True)
        return repo.working_tree_dir
    except Exception:
        return None


def _get_remote_url(path: str) -> Optional[str]:
    """Gets URL of remote repo of Git repo corresponded with specified path.

    If the specified path does not correspond with any Git repo, return `None`.
    If the Git repo has multiple remote repos, return URL of the first one.
    """
    try:
        repo = git.Repo(path, search_parent_directories=True)
        remotes = list(repo.remotes)
        if remotes:
            return remotes[0].url
        else:
            return None
    except Exception:
        return None


def _get_active_branch(path: str) -> Optional[str]:
    """Gets name of current branch of Git repo corresponded with specified path.

    If the specified path does not correspond with any Git repo, return `None`.
    """
    try:
        repo = git.Repo(path, search_parent_directories=True)
        return repo.active_branch.name
    except Exception:
        return None


def _get_latest_commit(path: str) -> Optional[str]:
    """Gets hash of latest commit on current branch of Git repo corresponded
    with specified path.

    If the specified path does not correspond with any Git repo, return `None`.
    """
    try:
        repo = git.Repo(path, search_parent_directories=True)
        return repo.head.commit.hexsha
    except Exception:
        return None


def _get_is_dirty(path: str) -> Optional[bool]:
    """Returns whether Git repo corresponded with specified path is dirty.

    If the specified path does not correspond with any Git repo, return `None`.
    """
    try:
        repo = git.Repo(path, search_parent_directories=True)
        return repo.is_dirty()
    except Exception:
        return None


def _get_file_status(file_path: str) -> Optional[str]:
    """Gets current status of file in its Git repo.

    If the file path does not refer to an existing file or correspond with
    any Git repo, return `None`.
    """
    try:
        repo = git.Repo(file_path, search_parent_directories=True)
        rel_path = relpath(abspath(file_path), repo.working_tree_dir)
        modified = [diff.a_path for diff in repo.index.diff(None)]
        if rel_path in repo.untracked_files:
            return 'untracked'
        elif rel_path in modified:
            return 'modified'
        else:
            return 'unmodified_or_ignored'
    except Exception:
        return None
