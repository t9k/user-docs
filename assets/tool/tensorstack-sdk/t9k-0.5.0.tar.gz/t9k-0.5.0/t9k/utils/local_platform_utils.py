"""Utility functions for querying information of local platform."""

from enum import Enum
import importlib
import logging
import platform
import sys
from typing import Dict, Union

_logger = logging.getLogger(__name__)


class Platform(Enum):
    LINUX = 1
    DARWIN = 2
    BSD = 3
    WINDOWS = 4
    OTHERS = 5


def get_platform_data() -> Dict[str, Union[str, Dict[str, str]]]:
    """Returns platform data as a dict."""
    platform_data = {}
    platform_data['hostname'] = platform.node()
    platform_data['os'] = platform.platform()
    platform_data['python'] = platform.python_version()

    _logger.debug('Platform info:')
    _logger.debug('  hostname: %s', platform_data['hostname'])
    _logger.debug('  OS version: %s', platform_data['os'])
    _logger.debug('  Python version: %s', platform_data['python'])

    platform_data['pypkgs'] = {}
    packages = [
        'numpy',
        'pandas',
        'tensorflow',  # 'keras' and 'tensorboard' are included
        'torch',
        'torchvision',
        'pytorch_lightning',
        'nltk',
        't9k-sdk',
    ]
    for p in packages:
        if p in sys.modules:
            platform_data['pypkgs'][p] = importlib.import_module(p).__version__

    platform_data['framework'] = []
    frameworks = {
        'tensorflow': 'TensorFlow',
        'torch': 'PyTorch',
        'pytorch_lightning': 'PyTorch Lightning'
    }
    for f, f_name in frameworks.items():
        if f in platform_data['pypkgs']:
            platform_data['framework'].append(f_name)
    # delete the following line
    platform_data['framework'] = ', '.join(platform_data['framework'])

    _logger.debug('  ML framework: %s', platform_data['framework'])
    _logger.debug('  Python packages:')
    for k, v in platform_data['pypkgs'].items():
        _logger.debug('    %s: %s', k, v)

    return platform_data
