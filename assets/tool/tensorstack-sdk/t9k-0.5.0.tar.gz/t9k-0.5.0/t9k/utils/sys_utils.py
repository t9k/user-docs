"""System utility functions."""

import io
import sys


class _StdoutLogger(io.TextIOWrapper):
    """Buffered text stream for duplicating stdout to files."""
    def __init__(self):
        self.terminal = sys.__stdout__
        self.files = {}

    def write(self, message: str) -> None:
        self.terminal.write(message)
        for f in self.files.values():
            f.write(message.replace('\b', ''))

    def close(self) -> None:
        self.flush()
        for f in self.files.values():
            f.close()

    def flush(self) -> None:
        self.terminal.flush()
        for f in self.files.values():
            f.flush()

    def isatty(self) -> bool:
        return True


def _add_stdout_logfile(file_name: str):
    """Adds a file logging stdout."""
    if not isinstance(sys.stdout, _StdoutLogger):
        sys.stdout = _StdoutLogger()

    sys.stdout.files[file_name] = open(file_name, 'a')


def _remove_stdout_logfile(file_name: str):
    """Removes a file logging stdout."""
    sys.stdout.files[file_name].close()
    del sys.stdout.files[file_name]

    if not sys.stdout.files:
        sys.stdout = sys.__stdout__
