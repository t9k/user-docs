"""Utility functions for generating random number and string."""

import random
import re
import string
from typing import Optional

from t9k.utils.datetime_utils import get_local_now


def new_random_name(base_name: Optional[str] = None,
                    date_time: bool = True,
                    time_microsecond: bool = False) -> str:
    """Generates name with base name, current datetime and random suffix."""
    name_splits = []
    if base_name:
        name_splits.append(base_name)
    if date_time:
        name_splits.append(get_local_now(time_microsecond))
    name_splits.append(''.join(
        random.choices(string.ascii_lowercase + string.digits, k=6)))
    return '_'.join(name_splits)


def is_random_name(name: str,
                   date_time: bool = True,
                   time_microsecond: bool = False) -> bool:
    """Checks if the name is a random name defined by `new_random_name()`."""
    if date_time:
        if time_microsecond:
            pattern = r'[0-9]{6}\_[0-9]{6}\_[0-9]{6}\_[a-z0-9]{6}$'
        else:
            pattern = r'[0-9]{6}\_[0-9]{6}\_[a-z0-9]{6}$'
    else:
        pattern = r'[a-z0-9]{6}$'
    return bool(re.search(pattern, name))
