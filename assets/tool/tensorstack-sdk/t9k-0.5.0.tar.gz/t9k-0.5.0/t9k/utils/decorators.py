"""Utility decorators."""

from functools import wraps
import sys
from typing import Callable


def called_once_only(skip: bool = False) -> Callable[[Callable], Callable]:
    """Restricts function to one call."""
    def decorater(f: Callable):
        def wrapper(*args, **kwargs):
            if not wrapper.called:
                wrapper.called = True
                return f(*args, **kwargs)
            elif wrapper.skip:
                return
            else:
                raise RuntimeError(
                    'Function {} can be called once only'.format(f.__name__))

        wrapper.called = False
        wrapper.skip = skip
        return wrapper

    return decorater


def called_once_only_each_instance(
        skip: bool = False) -> Callable[[Callable], Callable]:
    """Restricts method to one call for each instance."""
    def decorater(f: Callable):
        def wrapper(*args, **kwargs):
            instance = id(args[0])
            if instance not in wrapper.called:
                wrapper.called[instance] = True
                return f(*args, **kwargs)
            elif wrapper.skip:
                return
            else:
                raise RuntimeError(
                    'Method {} can be called once only for each instance'.
                    format(f.__name__))

        wrapper.called = {}
        wrapper.skip = skip
        return wrapper

    return decorater


def no_raise(f: Callable) -> Callable:
    """Prevents function from raising any exception but directly exits."""
    @wraps(f)
    def wrapper(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except Exception:  # pylint: disable=broad-except
            sys.exit(1)

    return wrapper
