"""Datetime utility functions."""

from datetime import datetime, timedelta, timezone


def get_local_now(microsecond: bool = False) -> str:
    """Returns current local datetime as a string.

    The string is in `yymmdd_HHMMSS[_ffffff]` format.
    """
    if microsecond:
        return datetime.now().strftime('%y%m%d_%H%M%S_%f')
    else:
        return datetime.now().strftime('%y%m%d_%H%M%S')


def get_local_now_iso() -> str:
    """Returns current local datetime as a string in ISO 8601 format."""
    return datetime.now(timezone.utc).astimezone().isoformat()


def get_utc_now_iso() -> str:
    """Returns current UTC datetime as a string in ISO 8601 format."""
    return datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')


def local_to_utc_iso(dt: str) -> str:
    """Convert local datetime in ISO 8601 format to UTC datetime."""
    return datetime.fromisoformat(dt).astimezone(
        timezone.utc).isoformat().replace('+00:00', 'Z')


def utc_to_local_iso(dt: str) -> str:
    """Convert UTC datetime in ISO 8601 format to local datetime."""
    return datetime.fromisoformat(dt.replace(
        'Z', '+00:00')).astimezone().isoformat()

def format_timedelta(tdelta: timedelta, brief: bool = False) -> str:
    """Formats a timedelta instance."""
    days = tdelta.days
    hours, rem = divmod(tdelta.seconds, 3600)
    minutes, seconds = divmod(rem, 60)

    if days:
        if brief:
            s = '{}d{}h'.format(days, hours)
        else:
            s = '{}d{}h{}m{}s'.format(days, hours, minutes, seconds)
    elif hours:
        if brief:
            s = '{}h{}m'.format(hours, minutes)
        else:
            s = '{}h{}m{}s'.format(hours, minutes, seconds)
    elif minutes:
        s = '{}m{}s'.format(minutes, seconds)
    else:
        s = '{}s'.format(seconds)

    return s
