"""Log functions."""

from datetime import datetime
import logging
import os
import sys

import click

import t9k
from t9k.utils.print_utils import blue, red, yellow
from t9k.utils.decorators import called_once_only

# prefixs for commandline display
INFO_PREFIX = blue('AH INFO: ', bold=True)
WARNING_PREFIX = yellow('AH WARNING: ', bold=True)
ERROR_PREFIX = red('AH ERROR: ', bold=True)

# configs
LOG_PATH = '.ah/logs'
# _echo_info = True
# _echo_warning = True
# _echo_error = True


class EchoHandler(logging.Handler):
    def emit(self, record):
        msg = self.format(record)
        if record.levelname == 'INFO':
            msg = INFO_PREFIX + msg
        elif record.levelname == 'WARNING':
            msg = WARNING_PREFIX + msg
        elif record.levelname == 'ERROR':
            msg = ERROR_PREFIX + msg
        click.echo(msg, file=sys.stderr)


class FileHandler(logging.FileHandler):
    def emit(self, record):
        if self.stream is None:
            self.stream = self._open()
        try:
            msg = self.format(record)
            msg = click.unstyle(msg)
            stream = self.stream
            # issue 35046: merged two stream.writes into one.
            stream.write(msg + self.terminator)
            self.flush()
        except RecursionError:  # See issue 36272
            raise
        except Exception:
            self.handleError(record)


def _get_ah_logger():
    logger = logging.getLogger('t9k.ah')
    logger.setLevel(logging.DEBUG)

    if not os.path.isdir(LOG_PATH):
        os.makedirs(LOG_PATH)
    datetime_string = datetime.now().strftime('%Y%m%d-%H%M%S')

    eh = EchoHandler()
    eh.setLevel(logging.INFO)
    logger.addHandler(eh)

    fh = FileHandler('{}/{}.log'.format(LOG_PATH, datetime_string), delay=True)
    fh.setLevel(logging.DEBUG)
    formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - '
        '[%(filename)s: line %(lineno)d: %(funcName)s()] - %(message)s')
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    logger.propagate = False

    return logger


_logger = _get_ah_logger()


def _log_setup():
    pass


@called_once_only(skip=True)
def print_version():
    _logger.info('TensorStack SDK version %s', t9k.__version__)
