"""Main APIs."""

import logging
from typing import Any, Dict, List, Optional, Sequence, Union

from requests import HTTPError

from t9k.ah.client import CLIENT
from t9k.ah.core import Folder, Model, Dataset, _labels_to_list
from t9k.utils.print_utils import cyan, red
from t9k.utils.uuid_utils import is_uuid

_logger = logging.getLogger(__name__)


def list_folder(type_: str = 'all',
                scope: str = 'all') -> List[Dict[str, Any]]:
    """Lists Folders.

    Examples:
        List all Folders:
        ```
        ah.list_folder()
        ```

        List all Model Folders that current user owns:
        ```
        ah.list_folder(type_='model', scope='own')
        ```

    Args:
        type_:
            Type of the Folders, must be `'model'`, `'dataset'` or `all`.
            If `all`, both Model and Dataset Folders are listed.
        scope:
            Scope of listing, must be `'own'`, `'shared'`, `'public'` or
            `'all'`.

    Returns:
        Folders' data retrieved.
    """
    if type_ not in ['model', 'dataset', 'all']:
        raise ValueError('Invalid Folder type: {}'.format(type_))
    if scope not in ['own', 'shared', 'public', 'all']:
        raise ValueError('Invalid scope: {}'.format(scope))
    return CLIENT.list_folder(folder_type=type_, scope=scope)


def create_folder(type_: str,
                  name: str,
                  labels: Union[str, Sequence[str], None] = None,
                  exist_ok: bool = False) -> Folder:
    """Creates a Folder.

    Examples:
        Create a Model Folder without labels:
        ```
        folder = ah.create_folder(type_='model', name='mnist-keras')
        ```

        Create a Model Folder with three labels:
        ```
        folder = ah.create_folder(
            type_='model',
            name='mnist-keras',
            labels=['Image Classification', 'MNIST', 'Keras'])
        ```

    Args:
        type_:
            Type of the Folder, must be `'model'` or `'dataset'`.
        name:
            Name of the Folder.
        labels:
            Labels of the Folder, can be a string, a sequence of string or
            `None`.
        exist_ok:
            If True and Folder with `type_` and `name` already exists, return
            a `Folder` instance representing this Folder; if False and Folder
            exists, raise a `RuntimeError`.

    Returns:
        A `Folder` instance representing created Folder.
    """
    if type_ not in ['model', 'dataset']:
        raise ValueError('Invalid Folder type: {}'.format(type_))
    _logger.info('Creating %s Folder %s', type_.capitalize(), cyan(name))

    labels = _labels_to_list(labels)

    try:
        id_ = CLIENT.create_folder(folder_type=type_,
                                   folder_name=name,
                                   labels=labels)
    except HTTPError as e:
        resp = e.response
        if resp.status_code == 400 and resp.text == 'folder already exists':
            if exist_ok:
                _logger.info('%s Folder %s already exists and is reused',
                             type_.capitalize(), cyan(name))
                return get_folder(type_=type_, name=name)
            else:
                _logger.error('%s Folder already exists: %s',
                              type_.capitalize(), red(name))
                raise RuntimeError("{} Folder already exists: '{}'".format(
                    type_.capitalize(), name)) from e
        else:
            raise e

    return Folder(id_=id_,
                  owner=CLIENT.user_name,
                  type_=type_,
                  name=name,
                  labels=labels)


def get_folder(owner: Optional[str] = None,
               type_: Optional[str] = None,
               name: Optional[str] = None,
               id_: Optional[str] = None) -> Folder:
    """Gets a Folder.

    Examples:
        Get a Folder of current user:
        ```
        folder = ah.get_folder(type_='model', name='mnist-keras')
        ```

        Get a Folder of another user:
        ```
        folder = ah.get_folder(owner='another',
                               type_='model',
                               name='mnist-keras')
        ```

        Get a Folder by ID:
        ```
        folder = ah.get_folder(id_='b81f187a-ad73-4f6e-b3b4-8b95b063ec32')
        ```

    Args:
        owner:
            Owner of the Folder. Default to current user that logged in to
            Asset Hub server, which means you get your own Folder. You can also
            specify another user, which means you get another user's Folder.
            In the second case, you (current user) must have view permission of
            the Folder.
        type_:
            Type of the Folder.
        name:
            Name of the Folder.
        id_:
            ID of the Folder. If this arg is provided, all of the above args
            are not required.

    Returns:
        A `Folder` instance representing retrieved Folder.
    """
    if id_:
        if not is_uuid(id_):
            _logger.error('Invalid Folder ID format: %s', red(id_))
            raise ValueError("Invalid Folder ID format: '{}'".format(id_))
        folder_data = CLIENT.get_folder_data_by_id(folder_id=id_)['folder']
        type_ = folder_data['type']
        name = folder_data['name']
        owner = folder_data['owner']
        labels = folder_data['labels']
    else:
        if not (type_ and name):
            _logger.error('If `id_` is not provided, `type_` and `name` must '
                          'be provided')
            raise RuntimeError('If `id_` is not provided, `type_` and `name` '
                               'must be provided')
        owner = owner or CLIENT.user_name
        folder_data = CLIENT.get_folder_data_by_name(owner=owner,
                                                     folder_type=type_,
                                                     folder_name=name)
        id_ = folder_data['id']
        labels = folder_data['labels']

    return Folder(id_=id_, owner=owner, type_=type_, name=name, labels=labels)


def get_asset(id_: str) -> Union[Model, Dataset]:
    """Gets an Asset directly by ID.

    If you want to get Asset by its ref, use `ah.get_folder().get_asset()`.

    Args:
        id_: ID of the Asset.

    Returns:
        A `Model` or `Dataset` instance representing retrieved Model or
        Dataset.
    """
    if not is_uuid(id_):
        _logger.error('Invalid Asset ID format: %s', red(id_))
        raise ValueError("Invalid Asset ID format: '{}'".format(id_))
    asset_data = CLIENT.get_asset_data_by_id(asset_id=id_)
    name = asset_data['name']
    labels = asset_data['labels']
    folder_id = asset_data['folder']
    folder_data = CLIENT.get_folder_data_by_id(folder_id=folder_id)['folder']
    owner = folder_data['owner']
    folder_type = folder_data['type']
    folder_name = folder_data['name']
    folder_labels = folder_data['labels']

    folder = Folder(id_=folder_id,
                    owner=owner,
                    type_=folder_type,
                    name=folder_name,
                    labels=folder_labels)

    if folder_type == 'model':
        return Model(id_=id_, folder=folder, name=name, labels=labels)
    else:
        return Dataset(id_=id_, folder=folder, name=name, labels=labels)
