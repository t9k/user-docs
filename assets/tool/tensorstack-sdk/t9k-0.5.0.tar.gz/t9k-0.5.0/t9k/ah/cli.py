"""Implementation of CLI."""

from datetime import datetime
import sys
from typing import Optional, Tuple, Union

import click
import tabulate

import t9k
from t9k import CONFIG
from t9k.ah.apis import list_folder, create_folder, get_folder, get_asset
from t9k.ah.client import login
from t9k.ah.core import Branch, Commit, Dataset, Folder, Model, Tag
from t9k.utils.datetime_utils import get_local_now_iso, format_timedelta
from t9k.utils.decorators import no_raise
from t9k.utils.file_utils import human_readable_size
from t9k.utils.print_utils import red
from t9k.utils.uuid_utils import is_uuid

CONTEXT_SETTINGS = dict(help_option_names=['-h', '--help'])

tabulate.PRESERVE_WHITESPACE = True


@click.group(context_settings=CONTEXT_SETTINGS)
@click.option('-v', '--verbose', is_flag=True)
@click.version_option(t9k.__version__)
@click.pass_context
def cli(ctx, verbose):
    del ctx, verbose  # Unused
    pass


@click.option('-H',
              '--host',
              type=str,
              metavar='SERVER_URL',
              help='URL of Asset Hub server.')
@click.option('-k',
              '--api-key',
              type=str,
              metavar='API_KEY',
              help='API Key for requesting Asset Hub server.')
@cli.command('login', context_settings=CONTEXT_SETTINGS)
@no_raise
def cli_login(host: Optional[str], api_key: Optional[str]):
    """Try to log in to Asset Hub server and update SDK config file.

    If any of the arguments is not provided, the value of config item with
    the same name in SDK config file will be used.
    """
    if host:
        CONFIG['asset_hub_host'] = host
    if api_key:
        CONFIG['api_key'] = api_key
    login()
    CONFIG.save()


@click.option('-H',
              '--host',
              is_flag=True,
              default=False,
              help='Remove host value.')
@cli.command('logout', context_settings=CONTEXT_SETTINGS)
def cli_logout(host: bool):
    """Remove API Key and optionally host in SDK config file."""
    CONFIG['api_key'] = ''
    if host:
        CONFIG['asset_hub_host'] = ''
    CONFIG.save()
    if host:
        click.echo('Removed host and API Key')
    else:
        if CONFIG['asset_hub_host']:
            click.echo('Removed API Key for host {}'.format(
                CONFIG['asset_hub_host']))
        else:
            click.echo('Removed API Key')


@click.group(context_settings=CONTEXT_SETTINGS)
def ls():
    """List resources."""
    pass


@click.option('-t',
              '--type',
              'folder_type',
              type=click.Choice(['model', 'dataset', 'all']),
              default='all',
              help='Type of the Folders.')
@click.option('-s',
              '--scope',
              type=click.Choice(['own', 'shared', 'public', 'all']),
              default='all',
              help='Scope of listing.')
@click.option('-d',
              '--detail',
              is_flag=True,
              default=False,
              help='Show detailed information about Folders.')
@ls.command('folder', context_settings=CONTEXT_SETTINGS)
@no_raise
def ls_folder(folder_type: str, scope: str, detail: bool):
    """List Folders.

    \b
    Examples:
        \b
        # List all Folders:
        ah ls folder
        \b
        # List all Model Folders that you own:
        ah ls folder -t model -s own
    """
    login()

    folders = list_folder(type_=folder_type, scope=scope)

    headers = []
    if folder_type == 'all':
        headers.append('TYPE')
    if detail:
        headers.extend(
            ['NAME', 'ID', 'ASSETS', 'OWNER', 'LABELS', 'CREATED', 'MODIFIED'])
    else:
        headers.extend(['NAME', 'ASSETS', 'OWNER', 'CREATED'])

    table = []
    for folder in folders:
        name = folder['folder']['name']
        assets = folder['assets']
        owner = folder['folder']['owner']
        t_delta = datetime.fromisoformat(
            get_local_now_iso()) - datetime.fromisoformat(
                folder['folder']['createdTimestamp'].replace('Z', '+00:00'))
        created = format_timedelta(t_delta, brief=True) + ' ago'

        row = []
        if folder_type == 'all':
            type_ = folder['folder']['type']
            row.append(type_)
        if detail:
            id_ = folder['folder']['id']
            labels = ', '.join(folder['folder']['labels'])
            t_delta = datetime.fromisoformat(
                get_local_now_iso()) - datetime.fromisoformat(
                    folder['folder']['modifiedTimestamp'].replace(
                        'Z', '+00:00'))
            modified = format_timedelta(t_delta, brief=True) + ' ago'
            row.extend([name, id_, assets, owner, labels, created, modified])
        else:
            row.extend([name, assets, owner, created])
        table.append(row)

    click.echo(
        tabulate.tabulate(table, headers, tablefmt='plain', numalign='left'))


@ls.command('model', context_settings=CONTEXT_SETTINGS)
@click.argument('folder',
                type=str,
                metavar='([[OWNER/]model/]FOLDER_NAME | FOLDER_ID)')
@no_raise
def ls_model(folder: str):
    """List Models in a Folder.

    \b
    Examples:
        \b
        # List Models in you own Folder:
        ah ls model image-classification
        \b
        # List Models in another user's Folder:
        ah ls model another/model/image-classification
        \b
        # Specify Folder by ID:
        ah ls model b81f187a-ad73-4f6e-b3b4-8b95b063ec32
    """
    login()

    folder = _get_folder(folder=folder, type_='model')
    models = folder.list_asset()

    headers = ['NAME', 'ID', 'BRANCHES', 'LABELS', 'CREATED', 'MODIFIED']

    table = []
    for m in models:
        name = m['asset']['name']
        id_ = m['asset']['id']
        branches = m['branches']
        labels = ', '.join(m['asset']['labels'])
        t_delta = datetime.fromisoformat(
            get_local_now_iso()) - datetime.fromisoformat(
                m['asset']['createdTimestamp'].replace('Z', '+00:00'))
        created = format_timedelta(t_delta, brief=True) + ' ago'
        t_delta = datetime.fromisoformat(
            get_local_now_iso()) - datetime.fromisoformat(
                m['asset']['modifiedTimestamp'].replace('Z', '+00:00'))
        modified = format_timedelta(t_delta, brief=True) + ' ago'
        table.append([name, id_, branches, labels, created, modified])

    click.echo(
        tabulate.tabulate(table, headers, tablefmt='plain', numalign='left'))


@ls.command('dataset', context_settings=CONTEXT_SETTINGS)
@click.argument('folder',
                type=str,
                metavar='([[OWNER/]dataset/]FOLDER_NAME | FOLDER_ID)')
@no_raise
def ls_dataset(folder: str):
    """List Datasets in a Folder.

    \b
    Examples:
        \b
        # List Datasets in you own Folder:
        ah ls dataset images
        \b
        # List Datasets in another user's Folder:
        ah ls dataset another/dataset/images
        \b
        # Specify Folder by ID:
        ah ls dataset 36f6acbd-6cdb-433d-9a55-b061724d526e
    """
    login()

    folder = _get_folder(folder=folder, type_='dataset')
    datasets = folder.list_asset()

    headers = ['NAME', 'ID', 'LABELS', 'CREATED', 'MODIFIED']

    table = []
    for ds in datasets:
        name = ds['asset']['name']
        id_ = ds['asset']['id']
        labels = ', '.join(ds['asset']['labels'])
        t_delta = datetime.fromisoformat(
            get_local_now_iso()) - datetime.fromisoformat(
                ds['asset']['createdTimestamp'].replace('Z', '+00:00'))
        created = format_timedelta(t_delta, brief=True) + ' ago'
        t_delta = datetime.fromisoformat(
            get_local_now_iso()) - datetime.fromisoformat(
                ds['asset']['modifiedTimestamp'].replace('Z', '+00:00'))
        modified = format_timedelta(t_delta, brief=True) + ' ago'
        table.append([name, id_, labels, created, modified])

    click.echo(
        tabulate.tabulate(table, headers, tablefmt='plain', numalign='left'))


@ls.command('branch', context_settings=CONTEXT_SETTINGS)
@click.argument('model',
                type=str,
                metavar='([[OWNER/]model/]FOLDER_NAME/MODEL_NAME | MODEL_ID)')
@click.option('-h',
              '--human-readable',
              is_flag=True,
              default=False,
              help='Print sizes in human readable format.')
@no_raise
def ls_branch(model: str, human_readable: bool):
    """List branches in a Model.

    \b
    Examples:
        \b
        # List branches of Model in you own Folder:
        ah ls branch image-classification/cnn-keras
        \b
        # List branches of Model in another user's Folder:
        ah ls dataset another/model/image-classification/cnn-keras
        \b
        # Specify Model by ID:
        ah ls branch db791378-a4eb-4244-9063-1f55cea441d7
    """
    login()

    model = _get_asset(model, 'model')
    branches = model.list_branch()

    headers = ['NAME', 'COMMIT_ID', 'SIZE', 'MODIFIED']

    table = []
    for b in branches:
        name = b['id']
        commit_id = b['commit_id'][:12]
        if human_readable:
            size = human_readable_size(b['size_bytes'])
        else:
            size = str(b['size_bytes']) + 'B'
        t_delta = datetime.fromisoformat(
            get_local_now_iso()) - datetime.fromtimestamp(
                b['mtime']).astimezone()
        modified = format_timedelta(t_delta, brief=True) + ' ago'
        table.append([name, commit_id, size, modified])

    click.echo(
        tabulate.tabulate(table,
                          headers,
                          tablefmt='plain',
                          colalign=['left', 'left', 'right', 'left']))


@ls.command('commit', context_settings=CONTEXT_SETTINGS)
@click.argument(
    'branch',
    type=str,
    metavar='([OWNER/]ASSET_TYPE/FOLDER_NAME/ASSET_NAME | ASSET_ID)'
    '[:BRANCH]')
@no_raise
def ls_commit(branch: str):
    """List commits of a branch of Asset.

    \b
    Examples:
        \b
        # List commits of branch of Model in you own Folder:
        ah ls branch image-classification/cnn-keras:v1
        \b
        # List commits of Dataset in another user's Folder:
        ah ls branch another/dataset/images/mnist
        # or
        ah ls branch another/dataset/images/mnist:main
        \b
        # Specify Model by ID:
        ah ls branch db791378-a4eb-4244-9063-1f55cea441d7:v1
    """
    login()

    try:
        branch = _get_ref(branch)
        commits = branch.list_commit()
    except AssertionError:
        eprint('Invalid argument: {}'.format(branch))

    headers = ['COMMIT_ID', 'MESSAGE', 'CREATED']

    table = []
    for c in commits:
        commit_id = c['id'][:12]
        msg = c['message']
        t_delta = datetime.fromisoformat(
            get_local_now_iso()) - datetime.fromtimestamp(
                c['creation_date']).astimezone()
        created = format_timedelta(t_delta, brief=True) + ' ago'
        table.append([commit_id, msg, created])

    click.echo(
        tabulate.tabulate(table, headers, tablefmt='plain', numalign='left'))


@ls.command('object', context_settings=CONTEXT_SETTINGS)
@click.argument(
    'ref',
    type=str,
    metavar='([OWNER/]ASSET_TYPE/FOLDER_NAME/ASSET_NAME | ASSET_ID)'
    '[:BRANCH | :tag/TAG | @COMMIT]')
@click.option('-h',
              '--human-readable',
              is_flag=True,
              default=False,
              help='Print sizes in human readable format.')
@no_raise
def ls_object(ref: str, human_readable: bool):
    """List objects of a reference of Asset.

    \b
    Examples:
        \b
        # List objects of branch of Model in you own Folder:
        ah ls object model/image-classification/cnn-keras:v1
        \b
        # List objects of tag of Dataset in another user's Folder:
        ah ls object another/dataset/images/mnist:tag/20220101
        \b
        # Specify Asset by ID:
        ah ls object db791378-a4eb-4244-9063-1f55cea441d7@4d0e202f
    """
    login()

    try:
        ref = _get_ref(ref)
        objects = ref.list_object()
    except AssertionError:
        eprint('Invalid argument: {}'.format(ref))

    headers = ['PATH', 'BYTES', 'CHECKSUM', 'MODIFIED']

    table = []
    for obj in objects:
        path = obj['path']
        if human_readable:
            size = human_readable_size(obj['size_bytes'])
        else:
            size = str(obj['size_bytes']) + 'B'
        checksum = obj['checksum']
        t_delta = datetime.fromisoformat(
            get_local_now_iso()) - datetime.fromtimestamp(
                obj['mtime']).astimezone()
        created = format_timedelta(t_delta, brief=True) + ' ago'
        table.append([path, size, checksum, created])

    click.echo(
        tabulate.tabulate(table,
                          headers,
                          tablefmt='plain',
                          colalign=['left', 'right', 'left', 'left']))


@click.group(context_settings=CONTEXT_SETTINGS)
def create():
    """Create resources."""
    pass


@click.group(context_settings=CONTEXT_SETTINGS)
def delete():
    """Delete resources."""
    pass


@create.command('folder', context_settings=CONTEXT_SETTINGS)
@click.argument('folder', type=str, metavar='ASSET_TYPE/FOLDER_NAME')
@click.option('-l',
              '--label',
              type=str,
              metavar='LABEL',
              multiple=True,
              help='Labels of the Folder.')
@no_raise
def cli_create_folder(folder: str, label: Tuple[str]):
    """Create a Folder.

    \b
    Examples:
        \b
        # Create a Model Folder:
        ah create folder model/image-classification
        \b
        # Create a Dataset Folder with labels:
        ah create folder dataset/images -l "CV"
    """
    login()

    if '/' in folder:
        asset_type, folder_name = folder.split('/')
    else:
        eprint('Invalid argument: {}'.format(folder))
    create_folder(type_=asset_type, name=folder_name, labels=label)


@delete.command('folder', context_settings=CONTEXT_SETTINGS)
@click.argument('folder',
                type=str,
                metavar='([OWNER/]ASSET_TYPE/FOLDER_NAME | FOLDER_ID)')
@no_raise
def delete_folder(folder: str):
    """Delete a Folder.

    \b
    Examples:
        \b
        # Delete your own Folder:
        ah delete folder model/image-classification
        \b
        # Delete another user's Folder:
        ah delete folder another/model/image-classification
        \b
        # Delete a Folder by ID:
        ah delete folder f260547c-edc5-4712-80cd-57376209b387
    """
    login()

    folder = _get_folder(folder=folder)
    folder.delete()


@create.command('model', context_settings=CONTEXT_SETTINGS)
@click.argument('model',
                type=str,
                metavar='[[OWNER/]model/]FOLDER_NAME/MODEL_NAME')
@click.option('-l',
              '--label',
              type=str,
              metavar='LABEL',
              multiple=True,
              help='Labels of the Folder.')
@no_raise
def create_model(model: str, label: Tuple[str]):
    """Create a Model.

    \b
    Examples:
        \b
        # Create a Model in your own Folder:
        ah create model model/image-classification/cnn-keras
        \b
        # Create a Model in another user's Folder with labels:
        ah create model another/model/image-classification/cnn-keras -l "Image Classification"
    """
    login()

    if '/' in model:
        folder_ref, model_name = model.rsplit('/', 1)
        folder = _get_folder(folder=folder_ref, type_='model')
        folder.create_asset(name=model_name, labels=label)
    else:
        eprint('Invalid argument: {}'.format(model))


@delete.command('model', context_settings=CONTEXT_SETTINGS)
@click.argument('model',
                type=str,
                metavar='([[OWNER/]model/]FOLDER_NAME/MODEL_NAME | MODEL_ID)')
@no_raise
def delete_model(model: str):
    """Delete a Model.

    \b
    Examples:
        \b
        # Delete a Model in your own Folder:
        ah delete model model/image-classification/cnn-keras
        \b
        # Delete a Model in another user's Folder:
        ah delete model another/model/image-classification/cnn-keras
        \b
        # Delete a Model by ID:
        ah delete model db791378-a4eb-4244-9063-1f55cea441d7
    """
    login()

    model = _get_asset(asset=model, type_='model')
    model.delete()


@create.command('dataset', context_settings=CONTEXT_SETTINGS)
@click.argument('dataset',
                type=str,
                metavar='[[OWNER/]dataset/]FOLDER_NAME/DATASET_NAME')
@click.option('-l',
              '--label',
              type=str,
              metavar='LABEL',
              multiple=True,
              help='Labels of the Folder.')
@no_raise
def create_dataset(dataset: str, label: Tuple[str]):
    """Create a Dataset.

    \b
    Examples:
        \b
        # Create a Dataset in your own Folder:
        ah create dataset dataset/images/mnist
        \b
        # Create a Dataset in another user's Folder with labels:
        ah create dataset another/dataset/images/mnist -l "Image Classification"
    """
    login()

    if '/' in dataset:
        folder_ref, dataset_name = dataset.rsplit('/', 1)
        folder = _get_folder(folder=folder_ref, type_='dataset')
        folder.create_asset(name=dataset_name, labels=label)
    else:
        eprint('Invalid argument: {}'.format(dataset))


@delete.command('dataset', context_settings=CONTEXT_SETTINGS)
@click.argument(
    'dataset',
    type=str,
    metavar='([[OWNER/]dataset/]FOLDER_NAME/DATASET_NAME | DATASET_ID)')
@no_raise
def delete_dataset(dataset: str):
    """Delete a Dataset.

    \b
    Examples:
        \b
        # Delete a Dataset in your own Folder:
        ah delete dataset dataset/images/mnist
        \b
        # Delete a Dataset in another user's Folder:
        ah delete dataset another/dataset/images/mnist
        \b
        # Delete a Dataset by ID:
        ah delete dataset 8e023cea-fda8-4f95-b8cb-937e348ba9ff
    """
    login()

    dataset = _get_asset(asset=dataset, type_='dataset')
    dataset.delete()


@create.command('branch', context_settings=CONTEXT_SETTINGS)
@click.argument('branch',
                type=str,
                metavar='([[OWNER/]model/]FOLDER_NAME/MODEL_NAME | MODEL_ID)'
                ':BRANCH')
@no_raise
def create_branch(branch: str):
    """Create a new branch of Model.

    \b
    Examples:
        \b
        # Create a branch of Model in your own Folder:
        ah create branch model/image-classification/cnn-keras:v1
        \b
        # Create a branch of Model in another user's Folder:
        ah create branch another/model/image-classification/cnn-keras:v1
        \b
        # Specify Model by ID:
        ah create branch db791378-a4eb-4244-9063-1f55cea441d7:v1
    """
    login()

    if ':' in branch:
        asset_ref, branch = branch.split(':')
        model = _get_asset(asset=asset_ref, type_='model')
        model.create_branch(name=branch)
    else:
        eprint('Invalid argument: {}'.format(branch))


@delete.command('branch', context_settings=CONTEXT_SETTINGS)
@click.argument('branch',
                type=str,
                metavar='([[OWNER/]model/]FOLDER_NAME/MODEL_NAME | MODEL_ID)'
                ':BRANCH')
@no_raise
def delete_branch(branch: str):
    """Delete a non-main branch of Model.

    \b
    Examples:
        \b
        # Delete a branch of Model in your own Folder:
        ah delete branch model/image-classification/cnn-keras:v1
        \b
        # Delete a branch of Model in another user's Folder:
        ah delete branch another/model/image-classification/cnn-keras:v1
        \b
        # Specify Model by ID:
        ah delete branch db791378-a4eb-4244-9063-1f55cea441d7:v1
    """
    login()

    if ':' in branch:
        asset_ref, branch = branch.split(':')
        model = _get_asset(asset=asset_ref, type_='model')
        model.get_branch(name=branch).delete()
    else:
        eprint('Invalid argument: {}'.format(branch))


@cli.command('commit', context_settings=CONTEXT_SETTINGS)
@click.argument(
    'branch',
    type=str,
    metavar='([OWNER/]ASSET_TYPE/FOLDER_NAME/ASSET_NAME | ASSET_ID)'
    '[:BRANCH]')
@click.option('-m',
              '--message',
              type=str,
              metavar='MESSAGE',
              help='Commit message.')
@click.option('-d',
              '--delete',
              type=str,
              metavar='PATH',
              multiple=True,
              help='Files or directories to delete from the branch.')
@click.option('-a',
              '--add',
              type=click.Path(exists=True),
              metavar='(LOCAL_PATH | LOCAL_PATH:PATH)',
              multiple=True,
              help='Files or directories to add to the branch.')
def cli_commit(branch: str, message: str, delete: Tuple[str], add: Tuple[str]):
    """Commit changes to a branch.

    First delete, then add.

    \b
    Examples:
        \b
        # Add a file as object to a branch of Model in your own Folder:
        ah commit model/image-classification/cnn-keras:v1 -m "add ..." -a model.pt
        \b
        # Specify path in Model for an object to add:
        ah commit model/image-classification/cnn-keras:v1 -m "add ..." -a model.pt:saved_model/[model.pt]
        \b
        # Add all files under a directory as objects:
        ah commit model/image-classification/cnn-keras:v1 -m "add ..." -a ./saved_model
        \b
        # Delete an object from a Dataset in another user's Folder:
        ah commit another/dataset/images/mnist -m "delete ..." -d "0.png"
        \b
        # Delete all objects under the same path:
        ah commit another/dataset/images/mnist -m "delete ..." -d "data/"
    """
    login()

    try:
        branch = _get_ref(branch)

        add_list = []
        add_dict = {}
        for i in add:
            if ':' in i:
                local_path, path = i.split(':')
                add_dict[local_path] = path
            else:
                add_list.append(i)
        if add_dict:
            for local_path in add_list:
                add_dict[local_path] = None
            branch.create_commit(msg=message, delete=delete, add=add_dict)
        else:
            branch.create_commit(msg=message, delete=delete, add=add_list)
    except AssertionError:
        eprint('Invalid argument: {}'.format(branch))


@cli.command('download', context_settings=CONTEXT_SETTINGS)
@click.argument(
    'ref',
    type=str,
    metavar='([OWNER/]ASSET_TYPE/FOLDER_NAME/ASSET_NAME | ASSET_ID)'
    '[:BRANCH | :tag/TAG | @COMMIT]')
@click.option('-p',
              '--path',
              type=str,
              metavar='PATH',
              multiple=True,
              help='Files or directories to download from the reference.')
@click.option('-s',
              '--save-dir',
              type=click.Path(),
              metavar='SAVE_DIR',
              default='.',
              help='Local directory which objects are downloaded to.')
def download(ref: str, path: str, save_dir: str):
    """Download objects of Asset.
    
    \b
    Examples:
        \b
        # Download all objects of a branch of Model to current working directory:
        ah download model/image-classification/cnn-keras:v1
        \b
        # Download an object to specified directory:
        ah download model/image-classification/cnn-keras:v1 -p model.pt -s ./saved_model
        \b
        # Download all objects under the same path:
        ah download model/image-classification/cnn-keras:v1 -p saved_model/
        \b
        # Specify reference by tag:
        ah download model/image-classification/cnn-keras:tag/20220101
        \b
        # Specify reference by commit:
        ah download model/image-classification/cnn-keras@a41ac4ec
    """
    login()

    if not path:
        path = ['./']

    try:
        ref = _get_ref(ref)
        ref.download(paths=path, save_dir=save_dir)
    except AssertionError:
        eprint('Invalid argument: {}'.format(ref))


@click.group(context_settings=CONTEXT_SETTINGS)
def rename():
    """Create resources."""
    pass


@click.group(context_settings=CONTEXT_SETTINGS)
def label():
    """Delete resources."""
    pass


@rename.command('folder', context_settings=CONTEXT_SETTINGS)
@click.argument('folder',
                type=str,
                metavar='([OWNER/]ASSET_TYPE/FOLDER_NAME | FOLDER_ID)',
                nargs=1)
@click.argument('name', type=str, metavar='NAME', nargs=1)
@no_raise
def rename_folder(folder: str, name: str):
    """Rename a Folder.

    \b
    Examples:
        \b
        # Rename your own Folder:
        ah rename folder model/image-classification image-segmentation
        \b
        # Rename another user's Folder:
        ah rename folder another/model/image-classification image-segmentation
    """
    login()

    folder = _get_folder(folder=folder)
    folder.update(name=name)


@label.command('folder', context_settings=CONTEXT_SETTINGS)
@click.argument('folder',
                type=str,
                metavar='([OWNER/]ASSET_TYPE/FOLDER_NAME | FOLDER_ID)')
@click.option('-d',
              '--delete',
              type=str,
              metavar='LABEL',
              multiple=True,
              help='Labels to delete from the Folder.')
@click.option('-a',
              '--add',
              type=str,
              metavar='LABEL',
              multiple=True,
              help='Labels to add to the Folder.')
@no_raise
def label_folder(folder: str, delete: Tuple[str], add: Tuple[str]):
    """Label a Folder.

    If a label to delete does not exist, do nothing. First delete, then add.

    \b
    Examples:
        \b
        # Add some labels to your own Folder:
        ah label folder model/image-classification -a "CV"
        \b
        # Delete and add some labels to another user's Folder:
        ah label folder another/model/image-classification -d "CV" -a "Image"
    """
    login()

    folder = _get_folder(folder=folder)
    new_labels = folder.labels.copy()
    for l in delete:
        if l in new_labels:
            new_labels.remove(l)
    for l in add:
        if l not in new_labels:
            new_labels.append(l)
    folder.update(labels=new_labels)


@rename.command('model', context_settings=CONTEXT_SETTINGS)
@click.argument('model',
                type=str,
                metavar='([[OWNER/]model/]FOLDER_NAME/MODEL_NAME | MODEL_ID)',
                nargs=1)
@click.argument('name', type=str, metavar='NAME', nargs=1)
@no_raise
def rename_model(model: str, name: str):
    """Rename a Model.

    \b
    Examples:
        \b
        # Rename a Model in your own Folder:
        ah rename model model/image-classification/cnn-keras cnn-torch
        \b
        # Rename a Model in another user's Folder:
        ah rename model another/model/image-classification/cnn-keras cnn-torch
    """
    login()

    model = _get_asset(asset=model, type_='model')
    model.update(name=name)


@label.command('model', context_settings=CONTEXT_SETTINGS)
@click.argument('model',
                type=str,
                metavar='([[OWNER/]model/]FOLDER_NAME/MODEL_NAME | MODEL_ID)')
@click.option('-d',
              '--delete',
              type=str,
              metavar='LABEL',
              multiple=True,
              help='Labels to delete from the Model.')
@click.option('-a',
              '--add',
              type=str,
              metavar='LABEL',
              multiple=True,
              help='Labels to add to the Model.')
@no_raise
def label_model(model: str, delete: Tuple[str], add: Tuple[str]):
    """Label a Model.

    If a label to delete does not exist, do nothing. First delete, then add.

    \b
    Examples:
        \b
        # Add some labels to a Model in your own Folder:
        ah label model model/image-classification/cnn-keras -a "Image Classification"
        \b
        # Delete and add some labels to a Model in another user's Folder:
        ah label model another/model/image-classification/cnn-keras -d "Image Classification" -a "Keras"
    """
    login()

    model = _get_asset(asset=model, type_='model')
    new_labels = model.labels.copy()
    for l in delete:
        if l in new_labels:
            new_labels.remove(l)
    for l in add:
        if l not in new_labels:
            new_labels.append(l)
    model.update(labels=new_labels)


@rename.command('dataset', context_settings=CONTEXT_SETTINGS)
@click.argument(
    'dataset',
    type=str,
    metavar='([[OWNER/]dataset/]FOLDER_NAME/DATASET_NAME | DATASET_ID)',
    nargs=1)
@click.argument('name', type=str, metavar='NAME', nargs=1)
@no_raise
def rename_dataset(dataset: str, name: str):
    """Rename a Dataset.

    \b
    Examples:
        \b
        # Rename a Dataset in your own Folder:
        ah rename dataset dataset/images/mnist fashion-mnist
        \b
        # Rename a Dataset in another user's Folder:
        ah rename dataset another/dataset/images/mnist fashion-mnist
    """
    login()

    dataset = _get_asset(asset=dataset, type_='dataset')
    dataset.update(name=name)


@label.command('dataset', context_settings=CONTEXT_SETTINGS)
@click.argument(
    'dataset',
    type=str,
    metavar='([[OWNER/]dataset/]FOLDER_NAME/DATASET_NAME | DATASET_ID)')
@click.option('-d',
              '--delete',
              type=str,
              metavar='LABEL',
              multiple=True,
              help='Labels to delete from the Dataset.')
@click.option('-a',
              '--add',
              type=str,
              metavar='LABEL',
              multiple=True,
              help='Labels to add to the Dataset.')
@no_raise
def label_dataset(dataset: str, delete: Tuple[str], add: Tuple[str]):
    """Label a Dataset.

    If a label to delete does not exist, do nothing. First delete, then add.

    \b
    Examples:
        \b
        # Add some labels to a Dataset in your own Folder:
        ah label dataset dataset/images/mnist -a "Image Classification"
        \b
        # Delete and add some labels to a Dataset in another user's Folder:
        ah label dataset another/dataset/images/mnist -d "Image Classification" -a "Single Channel"
    """
    login()

    dataset = _get_asset(asset=dataset, type_='dataset')
    new_labels = dataset.labels.copy()
    for l in delete:
        if l in new_labels:
            new_labels.remove(l)
    for l in add:
        if l not in new_labels:
            new_labels.append(l)
    dataset.update(labels=new_labels)


cli.add_command(ls)
cli.add_command(create)
cli.add_command(delete)
cli.add_command(rename)
cli.add_command(label)


def _get_folder(folder: str, type_: Optional[str] = None) -> Folder:
    if is_uuid(folder):
        return get_folder(id_=folder)
    else:
        parts = folder.split('/')
        if len(parts) == 1:
            assert type_
            return get_folder(type_=type_, name=folder)
        elif len(parts) == 2:
            if type_:
                assert type_ == parts[0]
                folder_name = parts[1]
            else:
                type_, folder_name = parts
            return get_folder(type_=type_, name=folder_name)
        if len(parts) == 3:
            if type_:
                assert type_ == parts[1]
                owner, _, folder_name = parts
            else:
                owner, type_, folder_name = parts
            return get_folder(owner=owner, type_=type_, name=folder_name)
        else:
            eprint('Invalid argument: {}'.format(folder))


def _get_asset(asset: str,
               type_: Optional[str] = None) -> Union[Model, Dataset]:
    if is_uuid(asset):
        asset_id = asset
        return get_asset(id_=asset_id)
    else:
        if '/' in asset:
            folder_ref, asset_name = asset.rsplit('/', 1)
            folder = _get_folder(folder=folder_ref, type_=type_)
            return folder.get_asset(name=asset_name)
        else:
            eprint('Invalid argument: {}'.format(asset))


def _get_ref(ref: str) -> Union[Branch, Tag, Commit]:
    repo_ref = {}
    if ':' in ref:
        asset_ref, branch_or_tag = ref.split(':')
        if branch_or_tag.startswith('tag/'):
            repo_ref['tag'] = branch_or_tag[4:]
        else:
            repo_ref['branch'] = branch_or_tag
    elif '@' in ref:
        asset_ref, commit = ref.split('@')
        repo_ref['commit'] = commit
    else:
        asset_ref = ref
        repo_ref['branch'] = 'main'

    asset = _get_asset(asset=asset_ref)
    if 'branch' in repo_ref:
        branch = repo_ref['branch']
        if asset.type == 'dataset':
            if branch == 'main':
                return asset._branch
            else:
                eprint('Invalid branch for Dataset: {}'.format(branch))
        else:
            return asset.get_branch(name=branch)
    elif 'tag' in repo_ref:
        return asset.get_tag(name=repo_ref['tag'])
    else:
        return asset.get_commit(id_=repo_ref['commit'])


def eprint(msg, prefix=True):
    """Prints error message and exits."""
    if prefix:
        click.echo(red('error: ', bold=True) + msg, err=True)
    else:
        click.echo(msg, err=True)
    sys.exit(1)
