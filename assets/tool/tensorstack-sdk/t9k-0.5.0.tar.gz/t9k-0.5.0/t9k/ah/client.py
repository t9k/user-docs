"""Asset Hub client."""

import logging
import os
from typing import (Any, BinaryIO, Dict, Iterator, List, Mapping, Optional,
                    Sequence, Union, TYPE_CHECKING)

import requests
from requests import HTTPError
import simplejson
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TimeRemainingColumn,
    TransferSpeedColumn,
)

from t9k import CONFIG
from t9k.utils.file_utils import (abspath, basename, dirname, exists, isdir,
                                  isfile, join, relpath, get_file_size)
from t9k.utils.print_utils import red, cyan, magenta
from t9k.utils.url_utils import check_url
from t9k.utils.uuid_utils import is_uuid

if TYPE_CHECKING:
    from t9k.ah.core import _Ref

_logger = logging.getLogger(__name__)


def _all_methods_online_only(cls):

    def online_only(func):

        def wrapper(self, *args, offline_ok=False, **kwargs):
            if self.online:
                return func(self, *args, **kwargs)
            elif offline_ok:
                return
            else:
                _logger.error('Cannot correspond with Asset Hub server for not'
                              ' logging in, please first call `ah.login()`')
                raise RuntimeError('Cannot correspond with Asset Hub server '
                                   'for not logging in, please first call '
                                   '`ah.login()`')

        return wrapper

    for attr in cls.__dict__:
        if callable(getattr(cls, attr)) and attr not in [
                '__init__', '_determine_object_key', 'test_connection',
                'get_user_name', 'request'
        ]:
            setattr(cls, attr, online_only(getattr(cls, attr)))
    return cls


@_all_methods_online_only
class _AssetHubClient(object):
    """Corresponds with Asset Hub server."""

    def __init__(self):
        self.host = None
        self.api_key = None

        self.headers = {}
        self.timeout = None

        self.online = False

    def create_folder(self, folder_type: str, folder_name: str,
                      labels: List[str]) -> str:
        """Creates a Folder.

        Args:
            folder_type:
                Type of the Folder, must be `'model'` or `'dataset'`.
            folder_name:
                Name of the Folder.
            labels:
                Labels of the Folder.

        Returns:
            ID of the Folder.
        """
        _logger.debug('Create Folder %s of type %s', folder_name, folder_type)
        assert folder_type in ['model', 'dataset']
        url = '{}/apis/v1/folders'.format(self.host)
        folder_data = {
            'type': folder_type,
            'name': folder_name,
            'labels': labels
        }
        return self.request(method='POST', url=url,
                            json_data=folder_data)['id']

    def list_folder(self,
                    folder_type: str = 'all',
                    scope: str = 'all') -> List[Dict[str, Any]]:
        """Lists Folders.

        Args:
            folder_type:
                Type of the Folders, must be `'model'`, `'dataset'` or `all`.
                If `all`, both Model and Dataset Folders are listed.
            scope:
                Scope of listing, must be `'own'`, `'shared'`, `'public'` or
                `'all'`.

        Returns:
            Folders' data retrieved.
        """
        _logger.debug('List %s Folders', scope)
        url = '{}/apis/v1/folders'.format(self.host)
        params = {'scope': scope}
        if folder_type in ['model', 'dataset']:
            params['type'] = folder_type
        return self.request(method='GET', url=url, params=params)

    def get_folder_data_by_id(self, folder_id: str) -> Dict[str, Any]:
        """Gets Folder data by ID.

        Returns:
            Folder data retrieved.
        """
        _logger.debug('Get data of Folder with ID %s', folder_id)
        url = '{}/apis/v1/folders/{}'.format(self.host, folder_id)
        try:
            return self.request(method='GET', url=url)
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 403 and resp.text == 'permission denied':
                _logger.error(
                    'Folder with ID %s does not exist, or you do not have '
                    'view permission', red(folder_id))
                raise RuntimeError(
                    'Folder with ID {} does not exist, or you do not have '
                    'view permission'.format(folder_id)) from e
            else:
                raise e

    def get_folder_data_by_name(self, owner: str, folder_type: str,
                                folder_name: str) -> Dict[str, Any]:
        """Gets Folder data by name and other arguments.

        Args:
            owner: Owner of the Folder.
            folder_type: Type of the Folder, must be `'model'` or `'dataset'`.
            folder_name: Name of the Folder.

        Returns:
            Folder data retrieved.
        """
        _logger.debug('Get data of Folder %s of type %s of user %s',
                      folder_name, folder_type, owner)
        url = '{}/apis/v1/ref'.format(self.host)
        params = {
            'asset_ref': '{}/{}/{}'.format(owner, folder_type, folder_name)
        }
        try:
            return self.request(method='GET', url=url, params=params)['folder']
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 404 and resp.text == 'folder not found':
                _logger.error('%s Folder %s of user %s does not exist',
                              folder_type.capitalize(),
                              *red(folder_name, owner))
                raise RuntimeError(
                    '{} Folder {} of user {} does not exist'.format(
                        folder_type.capitalize(), folder_name, owner)) from e
            else:
                raise e

    def update_folder(self, folder_id: str, name: str,
                      labels: List[str]) -> None:
        """Updates name and labels of a Folder."""
        _logger.debug('Update Folder with ID %s with name %s and labels %s',
                      folder_id, name, labels)
        url = '{}/apis/v1/folders/{}'.format(self.host, folder_id)
        updates = {'name': name, 'labels': labels}
        try:
            self.request(method='PUT', url=url, json_data=updates)
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 400 and resp.text == 'folder name already exists':
                _logger.error('Folder name %s already exists', red(name))
                raise RuntimeError(
                    "Folder name already exists: '{}'".format(name)) from e
            else:
                raise e

    def delete_folder(self, folder_id: str) -> None:
        """Deletes a Folder by ID."""
        _logger.debug('Delete Folder with ID %s', folder_id)
        url = '{}/apis/v1/folders/{}'.format(self.host, folder_id)
        self.request(method='DELETE', url=url)

    def create_asset(self, asset_name: str, folder_id: str,
                     labels: List[str]) -> str:
        """Creates an Asset.

        Args:
            folder_type:
                Type of the Folder, must be `'model'` or `'dataset'`.
            folder_name:
                Name of the Folder.
            labels:
                Labels of the Asset, can be a string, a sequence of string
                or `None`.

        Returns:
            ID of the Asset.
        """
        _logger.debug('Create Asset %s', asset_name)
        url = '{}/apis/v1/assets'.format(self.host)
        asset_data = {
            'name': asset_name,
            'folder': folder_id,
            'labels': labels
        }
        return self.request(method='POST', url=url, json_data=asset_data)['id']

    def list_asset(self, folder_id: str) -> List[Dict[str, Any]]:
        """Lists Assets in specified Folder.

        Args:
            folder_id: ID of the Folder in which Assets are listed.

        Returns:
            Assets' data retrieved.
        """
        _logger.debug('List Assets in Folder with ID %s', folder_id)
        url = '{}/apis/v1/assets'.format(self.host)
        params = {'fid': folder_id}
        return self.request(method='GET', url=url, params=params)

    def get_asset_data_by_id(self, asset_id: str) -> Dict[str, Any]:
        """Gets Asset data by ID.

        Returns:
            Asset data retrieved.
        """
        _logger.debug('Get data of Asset with ID %s', asset_id)
        url = '{}/apis/v1/assets/{}'.format(self.host, asset_id)
        return self.request(method='GET', url=url)

    def get_asset_data_by_name(self,
                               owner: str,
                               asset_type: str,
                               folder_name: str,
                               asset_name: str,
                               branch: Optional[str] = None,
                               tag: Optional[str] = None,
                               commit: Optional[str] = None) -> Dict[str, Any]:
        """Gets Asset data by name and other arguments.

        Args:
            owner:
                Owner of the Asset.
            asset_type:
                Type of the Asset, must be `'model'` or `'dataset'`.
            folder_name:
                Name of the Folder that the Asset is in.
            asset_name:
                Name of the Asset.
            branch:
                Branch of the Asset.
            tag:
                Tag of the Asset.
            commit:
                Commit ID of the Asset. Priorities of the last 3 arguments are:
                `branch` > `tag` > `commit`.

        Returns:
            Asset data retrieved.
        """
        _logger.debug(
            'Get data of Asset %s of type %s in folder %s of user %s from '
            'server', asset_name, asset_type, folder_name, owner)
        ref = '{}/{}/{}/{}'.format(owner, asset_type, folder_name, asset_name)
        if branch:
            ref += ':branch/{}'.format(branch)
        elif tag:
            ref += ':tag/{}'.format(tag)
        elif commit:
            ref += ':{}'.format(commit)
        url = '{}/apis/v1/ref'.format(self.host)
        params = {'asset_ref': ref}
        try:
            data = self.request(method='GET', url=url, params=params)
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 404:
                if resp.text == 'asset not found':
                    _logger.error('%s %s does not exist in Folder %s',
                                  asset_type.capitalize(),
                                  *red(asset_name, folder_name))
                    raise RuntimeError(
                        "{} does not exist in Folder '{}': '{}'".format(
                            asset_type.capitalize(), folder_name,
                            asset_name)) from e
                elif 'branch not found' in resp.text:
                    _logger.error('Branch %s of Model %s does not exist',
                                  *red(branch, asset_name))
                    raise RuntimeError(
                        "Branch of Model '{}' does not exist: '{}'".format(
                            asset_name, branch)) from e
                elif 'tag not found' in resp.text:
                    _logger.error('Tag %s of %s %s does not exist', red(tag),
                                  asset_type.capitalize(), red(asset_name))
                    raise RuntimeError(
                        "Commit of {} '{}' does not exist: '{}'".format(
                            asset_type.capitalize(), asset_name, tag)) from e
                elif 'commit not found' in resp.text:
                    _logger.error('Commit %s of %s %s does not exist',
                                  red(commit), asset_type.capitalize(),
                                  red(asset_name))
                    raise RuntimeError(
                        "Commit of {} '{}' does not exist: '{}'".format(
                            asset_type.capitalize(), asset_name,
                            commit)) from e
                else:
                    raise e
            else:
                raise e
        del data['folder']
        return data

    def update_asset(self, asset_id: str, asset_type: str, name: str,
                     labels: List[str]) -> None:
        """Updates name or labels of an Asset."""
        _logger.debug('Update Asset with ID %s with name %s and labels %s',
                      asset_id, name, labels)
        url = '{}/apis/v1/assets/{}'.format(self.host, asset_id)
        updates = {'name': name, 'labels': labels}
        try:
            self.request(method='PUT', url=url, json_data=updates)
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 400 and resp.text.startswith(
                    'asset') and resp.text.endswith('already exists'):
                _logger.error('%s name %s already exists',
                              asset_type.capitalize(), red(name))
                raise RuntimeError("{} name already exists: '{}'".format(
                    asset_type.capitalize(), name)) from e
            else:
                raise e

    def delete_asset(self, asset_id: str) -> None:
        """Deletes Asset by ID."""
        _logger.debug('Delete Asset with ID %s', asset_id)
        url = '{}/apis/v1/assets/{}'.format(self.host, asset_id)
        self.request(method='DELETE', url=url)

    def create_branch(self, asset_id: str, branch_name: str, ref: str) -> None:
        """Creates a branch of Asset.

        Args:
            asset_id:
                ID of the Asset.
            branch_name:
                Name of the branch.
            ref:
                Reference (branch name, tag name or commit ID) that the created
                branch points to.
        """
        _logger.debug('Create branch %s from ref %s of Asset with ID %s',
                      branch_name, ref, asset_id)
        url = '{}/apis/v1/assets/{}/branches'.format(self.host, asset_id)
        branch_data = {'name': branch_name, 'source': ref}
        self.request(method='POST', url=url, json_data=branch_data)

    def create_empty_branch(self, asset_id: str, branch_name: str) -> str:
        """Creates an empty branch of Asset.

        Args:
            asset_id:
                ID of the Asset.
            branch_name:
                Name of the branch.

        Returns:
            ID of the fisrt commit.
        """
        _logger.debug('Create empty branch %s of Asset with ID %s',
                      branch_name, asset_id)
        first_commit = self.list_commit(asset_id=asset_id,
                                        branch_name='main')[-1]
        assert first_commit['parents'] == []
        self.create_branch(asset_id=asset_id,
                           branch_name=branch_name,
                           ref=first_commit['id'])
        return first_commit['id']

    def list_branch(self, asset_id: str) -> Dict[str, Any]:
        """Lists branches of specified Asset.

        Args:
            asset_id: ID of the Asset whose branches are listed.

        Returns:
            Branches' data retrieved.
        """
        _logger.debug('List branches of Asset with ID %s', asset_id)
        url = '{}/apis/v1/assets/{}/branches'.format(self.host, asset_id)
        return self.request(method='GET', url=url)['results']

    def list_commit(self, asset_id: str, branch_name: str) -> Dict[str, Any]:
        """Lists commits of specified branch.

        Args:
            asset_id: ID of the Asset.
            branch_name: Name of the branch whose commits are listed.

        Returns:
            Commits' data retrieved.
        """
        _logger.debug('List commits of branch %s of Asset with ID %s',
                      branch_name, asset_id)
        url = '{}/apis/v1/assets/{}/branches/{}/commits'.format(
            self.host, asset_id, branch_name)
        return self.request(method='GET', url=url)['results']

    def delete_branch(self, asset_id: str, branch_name: str) -> None:
        """Deletes a branch of Asset."""
        _logger.debug('Delete branch %s of Asset with ID %s', branch_name,
                      asset_id)
        url = '{}/apis/v1/assets/{}/branches/{}'.format(
            self.host, asset_id, branch_name)
        try:
            self.request(method='DELETE', url=url)
        except HTTPError as e:
            resp = e.response
            if (resp.status_code == 500 and
                    'cannot delete repository default branch' in resp.text):
                _logger.error('Cannot delete main branch')
                raise RuntimeError('Cannot delete main branch') from e
            else:
                raise e

    def create_tag(self, asset_id: str, asset_type: str, asset_name: str,
                   tag_name: str, ref: str) -> None:
        """Creates a tag of Asset.

        Args:
            asset_id:
                ID of the Asset.
            asset_type:
                Type of the Asset.
            asset_name:
                Name of the Asset.
            tag_name:
                Name of the tag.
            ref:
                Reference (branch name, tag name or commit ID) that the created
                tag points to.
        """
        _logger.debug('Create tag %s from ref %s of Asset with ID %s',
                      tag_name, ref, asset_id)
        url = '{}/apis/v1/assets/{}/tags'.format(self.host, asset_id)
        tag_data = {'tag': tag_name, 'ref': ref}
        try:
            self.request(method='POST', url=url, json_data=tag_data)
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 409 and 'tag already exists' in resp.text:
                _logger.error('Tag %s of %s %s already exists', red(tag_name),
                              asset_type.capitalize(), red(asset_name))
                raise RuntimeError(
                    "Tag of {} '{}' already exists: '{}'".format(
                        asset_type.capitalize(), asset_name, tag_name)) from e
            else:
                raise e

    def list_tag(self, asset_id: str) -> None:
        """Lists tags of specified Asset.

        Args:
            asset_id: ID of the Asset whose tags are listed.

        Returns:
            Tags' data retrieved.
        """
        _logger.debug('List tags of Asset with ID %s', asset_id)
        url = '{}/apis/v1/assets/{}/tags'.format(self.host, asset_id)
        return self.request(method='GET', url=url)['results']

    def delete_tag(self, asset_id: str, tag_name: str) -> None:
        """Deletes a tag of Asset."""
        _logger.debug('Delete tag %s of Asset with ID %s', tag_name, asset_id)
        url = '{}/apis/v1/assets/{}/tags/{}'.format(self.host, asset_id,
                                                    tag_name)
        self.request(method='DELETE', url=url)

    def list_object(self, asset_id: str, ref: str) -> Dict[str, Any]:
        """Lists objects of specified commit.

        Due to limitations of lakeFS API, if you have the same branch name
        and tag name, you can only get objects of the branch. Thus it is 

        Args:
            asset_id:
                ID of the Asset.
            ref:
                Reference (branch name, tag name or commit ID) whose objects
                are listed.
        """
        _logger.debug('List objects of ref %s of Asset with ID %s', ref,
                      asset_id)
        url = '{}/apis/v1/assets/{}/refs/{}/objects/ls'.format(
            self.host, asset_id, ref)
        return self.request(method='GET', url=url)['results']

    def download(self, ref_obj: '_Ref', paths: Sequence[str],
                 save_dir: str) -> None:
        """Downloads objects of specified reference.

        Args:
            ref_obj:
                A `Branch`, `Tag` or `Commit` instance.
            paths:
                Files or directories to download from the reference, is a
                sequence of paths in reference. Here format `a/.../b` signifies
                a file while `a/.../b/` signifies a directory.
            save_dir:
                Local directory which objects are downloaded to. If directory
                does not exist, create it.
        """
        if not ref_obj._objects_map:
            ref_obj.list_object()
        objects_map = ref_obj._objects_map

        ref_type = ref_obj.type
        if ref_type == 'branch':
            ref_print = ref_obj.name
            ref = ref_obj.name
        elif ref_type == 'tag':
            ref_print = ref_obj.name
            ref = ref_obj.id
        else:  # 'commit'
            ref_print = ref_obj.id
            ref = ref_obj.id

        download_keys = []

        for key in paths:
            if not key.endswith('/'):  # file
                if key in objects_map:
                    download_keys.append(key)
                else:
                    _logger.error('File %s does not exist in %s %s', red(key),
                                  ref_type, red(ref_print))
                    raise RuntimeError(
                        "File does not exist in {} '{}': '{}'".format(
                            ref_type, ref_print, key))
            else:  # dir
                if key == './':  # all objects
                    key = ''
                is_dir_flag = False
                for k in objects_map:
                    if k.startswith(key):
                        is_dir_flag = True
                        download_keys.append(k)
                if not is_dir_flag:
                    _logger.error('Directory %s does not exist in %s %s',
                                  red(key), ref_type, red(ref_print))
                    raise RuntimeError(
                        "Directory does not exist in {} '{}': '{}'".format(
                            ref_type, ref_print, key))

        object_num = len(download_keys)
        for i, key in enumerate(download_keys, start=1):
            file_path = join(save_dir, key)
            os.makedirs(dirname(file_path), exist_ok=True)
            _logger.info('Downloading object %s/%s %s:', i, object_num,
                         cyan(key))
            self._download_object(asset_id=ref_obj.asset.id,
                                  ref=ref,
                                  key=key,
                                  size=objects_map[key]['size_bytes'],
                                  download_path=file_path)

    def _download_object(self, asset_id: str, ref: str, key: str, size: int,
                         download_path: str) -> None:
        """Downloads an object of specified reference."""
        _logger.debug('Download object %s of ref %s of Asset with ID %s', key,
                      ref, asset_id)
        url = '{}/apis/v1/assets/{}/refs/{}/objects'.format(
            self.host, asset_id, ref)
        params = {'path': key, 'apikey': self.api_key}

        _logger.debug('Request info:')
        _logger.debug('  URL: %s', url)
        _logger.debug('  method: GET')
        _logger.debug('  params: %s', params)

        progress = Progress(' ' * 8,
                            BarColumn(bar_width=None),
                            '[progress.percentage]{task.percentage:>3.1f}%',
                            '•',
                            DownloadColumn(),
                            '•',
                            TransferSpeedColumn(),
                            '•',
                            TimeRemainingColumn(),
                            console=Console(stderr=True))
        with progress:
            task_id = progress.add_task('download', start=False)
            progress.update(task_id, total=size)

            with requests.get(url=url,
                              params=params,
                              stream=True,
                              timeout=self.timeout,
                              allow_redirects=False) as r:
                r.raise_for_status()
                progress.start_task(task_id)
                with open(download_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=16384):  # 16KB
                        f.write(chunk)
                        progress.update(task_id, advance=len(chunk))

    def update_branch(
        self,
        asset_id: str,
        branch_name: str,
        msg: str,
        delete: Union[Sequence[str], None] = None,
        add: Union[Sequence[str], Mapping[str, str], None] = None
    ) -> Optional[str]:
        """Updates a branch of Asset.

        First delete, then add.

        Args:
            asset_id:
                ID of the Asset.
            branch_name:
                Name of the branch to update.
            msg:
                Update message.
            delete:
                Files or directories to delete from the branch, can be a
                sequence of local paths or `None`. If empty sequence or `None`,
                delete nothing.
            add:
                Files or directories to add to the branch, can be a sequence
                of local paths, a mapping from local paths to their paths in
                branch, or `None`. If empty sequence, empty mapping or `None`,
                add nothing.

        Returns:
            ID of created commit if the branch is updated, `None` if not.
        """
        _logger.debug('Update branch %s of Asset with ID %s', branch_name,
                      asset_id)
        if not (add or delete):
            return

        op_id = self._start_updating_branch(asset_id=asset_id,
                                            branch_name=branch_name)
        _logger.debug('Start operation with ID %s', op_id)
        try:
            if delete:
                if isinstance(delete, Sequence):
                    for key in delete:
                        if not key.endswith('/'):
                            self._delete_object(op_id=op_id, key=key)
                        else:
                            self._delete_dir(op_id=op_id, key=key)
                else:
                    _logger.error(
                        'Sequence or NoneType instance expected but %s '
                        'instance received for arg delete',
                        type(delete).__name__)
                    raise TypeError('Invalid type for delete')
            if add:
                if isinstance(add, Sequence):
                    for path in add:
                        if not exists(path):
                            _logger.error('Path %s does not exist', *red(path))
                            raise FileNotFoundError(
                                "No such file or directory: '{}'".format(path))
                        elif isfile(path):
                            self._add_file(op_id=op_id, file_path=path)
                        else:
                            self._add_dir(op_id=op_id, dir_path=path)
                elif isinstance(add, Mapping):
                    for path, key in add:
                        if not exists(path):
                            _logger.error('Path %s does not exist', *red(path))
                            raise FileNotFoundError(
                                "No such file or directory: '{}'".format(path))
                        elif isfile(path):
                            self._add_file(op_id=op_id,
                                           file_path=path,
                                           key=key)
                        else:
                            self._add_dir(op_id=op_id, dir_path=path, key=key)
                else:
                    _logger.error(
                        'Sequence, Mapping or NoneType instance expected but '
                        '%s instance received for arg add',
                        type(add).__name__)
                    raise TypeError('Invalid type for add')
        except Exception as e:
            _logger.debug('Cancel operation with ID %s', op_id)
            self._cancel_updating_branch(op_id=op_id)
            raise e

        try:
            _logger.debug('Complete operation with ID %s', op_id)
            return self._complete_updating_branch(op_id=op_id, msg=msg)
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 400 and resp.text == 'commit: no changes':
                _logger.debug(
                    'Commit contains no changes, cancel operation with ID %s',
                    op_id)
                self._cancel_updating_branch(op_id=op_id)
            else:
                raise e

    def _start_updating_branch(self, asset_id: str, branch_name: str) -> str:
        """Starts updating a branch of Asset.

        Args:
            asset_id: ID of the Asset.
            branch_name: Name of the branch to update.

        Returns:
            An operation ID.
        """
        _logger.debug('Start updating branch %s of Asset with ID %s',
                      branch_name, asset_id)
        url = '{}/apis/v1/update'.format(self.host)
        params = {'asset': asset_id, 'branch': branch_name}
        return self.request(method='POST', url=url, params=params)['op_id']

    def _add_file(self,
                  op_id: str,
                  file_path: str,
                  key: Optional[str] = None) -> Dict[str, Any]:
        """Uploads a local file as an object to specified operation.

        Args:
            op_id:
                ID of the operation to which the object is uploaded. It is
                returned by `start_updating_branch()`.
            file_path:
                Path of the file to be uploaded.
            key:
                Key of the object. It might be modified by
                `_determine_object_key()`.

        Returns:
            Object data.
        """
        file_path = abspath(file_path)
        assert isfile(file_path)

        key = self._determine_object_key(file_path, key)
        return self._upload_object(op_id=op_id, key=key, file_path=file_path)

    def _add_dir(self,
                 op_id: str,
                 dir_path: str,
                 key: Optional[str] = None) -> List[Dict[str, Any]]:
        """Uploads all files under a local directory as objects to specified
        operation.

        Args:
            op_id:
                ID of the operation to which objects are uploaded. It is
                returned by `start_updating_branch()`.
            dir_path:
                Path of the directory under which all files are to be uploaded.
            key:
                Key of the object. It might be modified by
                `_determine_object_key()`.

        Returns:
            Objects data.
        """
        dir_path = abspath(dir_path)
        assert isdir(dir_path)

        key = self._determine_object_key(dir_path, key)

        objs_data = []
        for root, _, files in os.walk(dir_path):
            for file in files:
                file_path = join(root, file)
                file_key = join(key, relpath(file_path, dir_path))
                data = self._upload_object(op_id=op_id,
                                           key=file_key,
                                           file_path=file_path)
                objs_data.append(data)

        return objs_data

    @staticmethod
    def _determine_object_key(path: str, key: Optional[str] = None) -> str:
        if not key:
            return basename(path)

        if key.startswith('/'):
            key = key[1:]
        if key.endswith('/'):
            key = key + basename(path)
        return key

    def _upload_object(self, op_id: str, key: str,
                       file_path: str) -> Dict[str, Any]:
        """Uploads an object to specified operation."""
        _logger.debug('Upload file %s to path %s of operation %s', file_path,
                      key, op_id)
        _logger.info('Uploading object %s:', cyan(key))
        assert isfile(file_path)
        size = get_file_size(file_path)
        if size <= 100 * 1024 * 1024:  # 100MiB
            print(' ' * 9 + 'Uploading...', end='', flush='True')
            url = '{}/apis/v1/objects'.format(self.host)
            params = {'opID': op_id, 'path': key}
            files = {'content': open(file_path, 'rb')}
            data = self.request(method='PUT',
                                url=url,
                                params=params,
                                files=files)
            print('\r' + ' ' * 9 + 'Done' + ' ' * 8, flush='True')
            return data
        elif size <= 10 * 1024 * 1024 * 10000:  # 97GiB + 672MiB
            self._multipart_upload_object(op_id=op_id,
                                          key=key,
                                          size=size,
                                          file_path=file_path)
        else:
            size_in_gib = round(size / 1024**3, 2)
            _logger.error(
                'Cannot upload object %s, its size %sGiB exceeds the limit '
                'of 97.65GiB', *red(key, size_in_gib))
            raise RuntimeError(
                'Cannot upload object {}, its size {}GiB exceeds the limit '
                'of 97.65GiB'.format(key, size_in_gib))

    def _multipart_upload_object(self, op_id: str, key: str, size: int,
                                 file_path: str) -> None:
        # copied from `t9k.aimd.client._AIMDClient._multipart_upload()`
        url_create = '{}/apis/v1/multipart'.format(self.host)
        params = {'opID': op_id, 'path': key}
        upload_id = self.request(method='POST', url=url_create,
                                 params=params)['uploadId']

        def read_in_chunks(file_object: BinaryIO,
                           chunk_size: int) -> Iterator[bytes]:
            while True:
                data = file_object.read(chunk_size)
                if not data:
                    break
                yield data

        if size > 6 * 1024 * 1024 * 10000:
            chunk_size = size // 10000
        else:
            chunk_size = 6 * 1024 * 1024

        progress = Progress(' ' * 8,
                            BarColumn(bar_width=None),
                            '[progress.percentage]{task.percentage:>3.1f}%',
                            '•',
                            DownloadColumn(),
                            '•',
                            TransferSpeedColumn(),
                            '•',
                            TimeRemainingColumn(),
                            console=Console(stderr=True))
        with progress:
            task_id = progress.add_task('download', start=False)
            progress.update(task_id, total=size)
            with open(file_path, 'rb') as f:
                parts = []
                progress.start_task(task_id)
                for n, piece in enumerate(read_in_chunks(f, chunk_size),
                                          start=1):
                    url_upload = ('{}/apis/v1/multipart/{}').format(
                        self.host, upload_id)
                    params = {'opID': op_id, 'path': key, 'partNum': n}
                    etag = self.request(method='PUT',
                                        url=url_upload,
                                        params=params,
                                        data=piece)['etag']
                    parts.append({'etag': etag, 'partNumber': n})
                    progress.update(task_id, advance=len(piece))
                url_complete = ('{}/apis/v1/multipart/{}').format(
                    self.host, upload_id)
                params = {'opID': op_id, 'path': key}
                self.request(method='POST',
                             url=url_complete,
                             params=params,
                             json_data={'parts': parts})

    def _delete_object(self, op_id: str, key: str) -> None:
        """Deletes an object from specified operation."""
        _logger.debug('Delete object %s from operation %s', key, op_id)
        _logger.info('Deleting object %s:', cyan(key))
        print(' ' * 9 + 'Deleting...', end='', flush='True')
        url = '{}/apis/v1/objects'.format(self.host)
        params = {'opID': op_id, 'path': key}
        self.request(method='DELETE', url=url, params=params)
        print('\r' + ' ' * 9 + 'Done' + ' ' * 8, flush='True')

    def _delete_dir(self, op_id: str, key: str) -> None:
        """Deletes a directory from specified operation."""
        _logger.debug('Delete directory %s from operation %s', key, op_id)
        _logger.info('Deleting all objects under path %s:', cyan(key))
        print(' ' * 9 + 'Deleting...', end='', flush='True')
        url = '{}/apis/v1/objects'.format(self.host)
        params = {'opID': op_id, 'path': key}
        self.request(method='DELETE', url=url, params=params)
        print('\r' + ' ' * 9 + 'Done' + ' ' * 8, flush='True')

    def _complete_updating_branch(self, op_id: str, msg: str) -> str:
        """Completes updating a branch of Asset.
        
        Returns:
            ID of created commit.
        """
        _logger.debug('Complete updating operation %s', op_id)
        url = '{}/apis/v1/update/{}'.format(self.host, op_id)
        commit_data = {'message': msg}
        return self.request(method='POST', url=url,
                            json_data=commit_data)['commit']

    def _cancel_updating_branch(self, op_id: str) -> None:
        """Cancels updating a branch of Asset."""
        _logger.debug('Cancel updating operation %s', op_id)
        url = '{}/apis/v1/operation/{}'.format(self.host, op_id)
        self.request(method='DELETE', url=url)

    def test_connection(self) -> None:
        """Tests connection to server.

        Raises:
            requests.HTTPError: Incorrect URL of server or invalid API key.
        """
        _logger.debug('Test connection to Asset Hub server with URL %s',
                      self.host)
        url = '{}/apis/v1/folders'.format(self.host)
        params = {'scope': 'own'}
        try:
            resp = self.request(method='GET', url=url, params=params)
            # resp should be like
            # [{'folders': {...}, 'permission': ..., 'assets': ...}, ...]
            assert isinstance(resp, list)
        except requests.ConnectionError as e:
            _logger.error('Unable to connect to Asset Hub server, please check'
                          ' your network connection or status of server')
            raise e

        url = '{}/oauth2/userinfo'.format(self.host)
        params = {'apikey': self.api_key}
        self.user_name = self.request(method='GET', url=url,
                                      params=params)['preferred_username']

        _logger.debug('Get user name "%s"', self.user_name)
        _logger.info('Logged in to Asset Hub server %s as user %s',
                     magenta(self.host), magenta(self.user_name, bold=True))

    def request(self,
                method: str,
                url: str,
                params: Optional[Dict[str, Any]] = None,
                json_data: Optional[Any] = None,
                data: Optional[Any] = None,
                files: Optional[Dict[str, Any]] = None,
                headers: Optional[Dict[str, str]] = None) -> str:
        """Sends request to server.

        Args:
            method: Method of the HTTP request.
            url: URL of the HTTP request.
            params: Query parameters of the HTTP request.
            data: Contents to be sent in the request body.
            headers: Headers of the HTTP request.

        Returns:
            A dict parsed from JSON in content of the response, or a string of
            content of the response if the response body does not contain valid
            JSON.

        Raises:
            requests.HTTPError: An HTTP error occurred.
        """
        params = params if params else {}
        params['apikey'] = self.api_key
        headers = headers if headers else self.headers

        _logger.debug('Request info:')
        _logger.debug('  URL: %s', url)
        _logger.debug('  method: %s', method)
        _logger.debug('  params: %s', params)
        if json_data:
            _logger.debug('  json: %s', json_data)
        if data:
            _logger.debug('  data: %s', data)
        if files:
            _logger.debug('  file: %s', files)

        resp = requests.request(method=method,
                                url=url,
                                params=params,
                                json=json_data,
                                data=data,
                                files=files,
                                headers=headers,
                                timeout=self.timeout,
                                allow_redirects=False)
        if not resp.ok:
            http_error_msg = ''
            if resp.status_code == 302:
                _logger.error('API Key not provided')
                raise ValueError('API Key not provided')
            if 400 <= resp.status_code < 500:
                if resp.status_code == 400 and resp.text.startswith(
                        'api key') and resp.text.endswith('not found\n'):
                    raise RuntimeError('Invalid API Key')
                elif resp.status_code == 400 and resp.text.startswith(
                        'query is needed'):
                    _logger.error(
                        'Empty string provided for API Key, please provide '
                        'a valid API Key')
                    raise ValueError('Empty string provided for API Key')
                elif resp.status_code == 404 and not resp.text:
                    raise ValueError('Incorrect URL of Asset Hub server')
                else:
                    http_error_msg = '%s Client Error: %s for URL %s' % (
                        resp.status_code, resp.reason, resp.url)
                    if resp.text:
                        http_error_msg = http_error_msg + ': ' + resp.text
            elif 500 <= resp.status_code < 600:
                http_error_msg = '%s Server Error: %s for URL %s' % (
                    resp.status_code, resp.reason, resp.url)
                if resp.text:
                    http_error_msg = http_error_msg + ': ' + resp.text
            if http_error_msg:
                raise requests.HTTPError(http_error_msg, response=resp)
        _logger.debug('Request succeeded')

        try:
            return resp.json()
        except simplejson.JSONDecodeError:
            return resp.text


CLIENT = _AssetHubClient()


def login(host: Optional[str] = None,
          api_key: Optional[str] = None,
          timeout: Optional[int] = None) -> None:
    """Logs in to Asset Hub server.

    Sets up the client that corresponds with Asset Hub server.

    Args:
        host:
            URL of Asset Hub server. Defaults to server URL given by SDK config
            file if one is set.
        api_key:
            API Key for requesting server. Defaults to API Key given by
            SDK config file if one is set.
        timeout:
            How many seconds to wait for server to send data before giving up.

    Raises:
        requests.HTTPError:
            Unable to connect to server.
    """
    if host:
        CLIENT.host = host
    elif CONFIG['asset_hub_host']:
        CLIENT.host = CONFIG['asset_hub_host']
        host = CONFIG['asset_hub_host']
    else:
        _logger.error('Host not provided by either argument or config')
        raise ValueError('Host not provided')

    if api_key:
        CLIENT.api_key = api_key
    elif CONFIG['api_key']:
        CLIENT.api_key = CONFIG['api_key']
        api_key = CONFIG['api_key']
    else:
        _logger.error('API Key not provided by either argument or config')
        raise ValueError('API Key not provided')

    check_url(CLIENT.host)
    if not is_uuid(CLIENT.api_key):
        _logger.error('Invalid API Key format: %s', red(CLIENT.api_key))
        raise ValueError('Invalid API Key format: {}'.format(CLIENT.api_key))

    if CLIENT.host.endswith('/'):
        CLIENT.host = CLIENT.host[:-1]
    _logger.debug('Log in to host %s with API Key %s', host, api_key)

    CLIENT.timeout = timeout

    try:
        CLIENT.test_connection()
    except requests.ConnectionError as e:
        _logger.error('Unable to connect to Asset Hub server: %s', red(host))
        raise e
    except ValueError as e:
        if e.args[0] == 'Invalid API Key':
            _logger.error('Invalid API Key: %s, please check the API Key',
                          red(api_key))
            raise ValueError('Invalid API Key: {}'.format(api_key)) from e
        elif e.args[0] == 'Incorrect URL of Asset Hub server':
            _logger.error(
                'Incorrect URL of Asset Hub server: %s, please '
                'check the URL', red(host))
            raise ValueError(
                'Incorrect URL of Asset Hub server: {}'.format(host)) from e
        else:
            raise e

    CLIENT.online = True


def logout() -> None:
    """Logs out from the current Asset Hub server.

    The client is unset, it can no longer correspond with Asset Hub server
    until it is set up again.
    """
    if CLIENT.online:
        _logger.info('Logged out from Asset Hub server %s',
                     magenta(CLIENT.host))
        CLIENT.online = False
    else:
        _logger.warning(
            'Not log out, for having not logged in to any Asset Hub server')
