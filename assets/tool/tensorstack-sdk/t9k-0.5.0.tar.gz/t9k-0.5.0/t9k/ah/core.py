"""Core classes."""

import logging
from typing import Any, Dict, List, Mapping, Optional, Sequence, Union

from requests import HTTPError

from t9k.ah.client import CLIENT
from t9k.utils.print_utils import cyan, red
from t9k.utils.uuid_utils import is_uuid

_logger = logging.getLogger(__name__)


def _all_methods_alive_only(cls):

    def online_only(func):

        def wrapper(self, *args, **kwargs):
            if self._alive:
                return func(self, *args, **kwargs)
            else:
                _logger.error(
                    'Cannot call method, because its `delete()` method has '
                    'been called, corresponding item has been deleted in '
                    'server')
                raise RuntimeError(
                    'Cannot call method, because its `delete()` method has '
                    'been called, corresponding item has been deleted in '
                    'server')

        return wrapper

    for attr in cls.__dict__:
        if callable(getattr(cls, attr)) and attr not in ['__init__']:
            setattr(cls, attr, online_only(getattr(cls, attr)))
    return cls


@_all_methods_alive_only
class Folder(object):
    """Represents a Folder in server."""

    def __init__(self,
                 id_: str,
                 owner: str,
                 type_: str,
                 name: str,
                 labels: Union[str, Sequence[str], None] = None) -> None:
        assert is_uuid(id_)
        assert type_ in ['model', 'dataset']

        self._id = id_
        self._owner = owner
        self._type = type_
        self._name = name
        self._labels = labels

        self._alive = True

    @property
    def id(self) -> str:
        return self._id

    @property
    def owner(self) -> str:
        return self._owner

    @property
    def type(self) -> str:
        return self._type

    @property
    def name(self) -> str:
        return self._name

    @property
    def labels(self) -> List[str]:
        return self._labels

    def update(self,
               name: Optional[str] = None,
               labels: Union[str, Sequence[str], None] = None) -> None:
        """Updates name or labels of this Folder.

        If neither `name` or `labels` is provided, do nothing.
        """
        msg = 'Update Folder {} with'.format(cyan(self.name))
        no_name = name is None
        no_labels = labels is None

        if no_name and no_labels:
            return
        if no_name:
            name = self.name
        else:
            self._name = name
            msg += ' name {}'.format(cyan(name))
        if no_labels:
            labels = self.labels
        else:
            labels = _labels_to_list(labels)
            if self._labels == labels:
                _logger.info('Labels of Folder %s remain unchanged',
                             cyan(self.name))
            else:
                self._labels = labels
                if not no_name:
                    msg += ' and'
                msg += ' labels {}'.format(cyan(labels))

        if not msg.endswith('with'):
            _logger.info(msg)
        CLIENT.update_folder(folder_id=self.id, name=name, labels=labels)

    def list_asset(self) -> List[Dict[str, Any]]:
        """Lists Assets in this Folder."""
        return CLIENT.list_asset(folder_id=self.id)

    def create_asset(self,
                     name: str,
                     labels: Union[str, Sequence[str], None] = None,
                     exist_ok: bool = False) -> Union['Model', 'Dataset']:
        """Creates an Asset in this Folder.

        Type of the Asset depends on type of this Folder.

        Args:
            name:
                Name of the Asset.
            labels:
                Labels of the Asset, can be a string, a sequence of string or
                `None`.
            exist_ok:
                If True and Asset with `name` already exists, return a `Model`
                or `Dataset` instance representing this Asset; if False and
                Asset exists, raise a `RuntimeError`.

        Returns:
            A `Model` or `Dataset` instance representing created Model or
            Dataset, depending on type of this Folder.
        """
        msg = 'Creating {} {} in Folder {}'.format(self.type.capitalize(),
                                                   *cyan(name, self.name))
        if CLIENT.user_name != self.owner:
            msg += ' of user {}'.format(cyan(self.owner))
        _logger.info(msg)

        labels = _labels_to_list(labels)

        try:
            id_ = CLIENT.create_asset(asset_name=name,
                                      folder_id=self.id,
                                      labels=labels)
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 400 and resp.text.startswith(
                    'asset') and resp.text.endswith('already exists'):
                if exist_ok:
                    _logger.info(
                        '%s %s in Folder %s already exists and is reused',
                        self.type.capitalize(), *cyan(name, self.name))
                    return self.get_asset(name=name)
                else:
                    _logger.error('%s %s already exists in Folder %s',
                                  self.type.capitalize(),
                                  *red(name, self.name))
                    raise RuntimeError(
                        "{} already exists in Folder '{}': '{}'".format(
                            self.type.capitalize(), self.name, name)) from e
            else:
                raise e

        if self.type == 'model':
            return Model(id_=id_, folder=self, name=name, labels=labels)
        else:
            return Dataset(id_=id_, folder=self, name=name, labels=labels)

    def get_asset(self, name: str) -> Union['Model', 'Dataset']:
        """Gets an Asset in this Folder.

        If you want to get Asset directly by its ID, use `ah.get_asset()`.

        Type of the Asset depends on type of this Folder.

        Args:
            name: Name of the Asset.

        Returns:
            A `Model` or `Dataset` instance representing retrieved Model or
            Dataset, depending on type of this Folder.
        """
        asset_data = CLIENT.get_asset_data_by_name(owner=self.owner,
                                                   asset_type=self.type,
                                                   folder_name=self.name,
                                                   asset_name=name)['asset']
        asset_id = asset_data['id']
        labels = asset_data['labels']

        if self.type == 'model':
            return Model(id_=asset_id, folder=self, name=name, labels=labels)
        else:
            return Dataset(id_=asset_id, folder=self, name=name, labels=labels)

    def delete(self) -> None:
        """Deletes this Folder."""
        msg = 'Deleting {} Folder {}'.format(self.type.capitalize(),
                                             cyan(self.name))
        if CLIENT.user_name != self.owner:
            msg += ' of user {}'.format(cyan(self.owner))
        _logger.info(msg)

        CLIENT.delete_folder(folder_id=self.id)

        self._alive = False


class _Asset(object):
    """Represents an Asset in server."""

    def __init__(self,
                 id_: str,
                 folder: Folder,
                 name: str,
                 labels: Union[str, Sequence[str], None] = None) -> None:
        assert is_uuid(id_)

        self._id = id_
        self._folder = folder
        self._type = ''
        self._name = name
        self._labels = labels

        self._alive = True

    @property
    def id(self) -> str:
        return self._id

    @property
    def folder(self) -> str:
        return self._folder

    @property
    def type(self) -> str:
        return self._type

    @property
    def name(self) -> str:
        return self._name

    @property
    def labels(self) -> List[str]:
        return self._labels

    def update(self,
               name: Optional[str] = None,
               labels: Union[str, Sequence[str], None] = None) -> None:
        """Updates name or labels of this Asset.

        If neither `name` or `labels` is provided, do nothing.
        """
        msg = 'Update {} {} with'.format(self.type.capitalize(),
                                         cyan(self.name))
        no_name = name is None
        no_labels = labels is None

        if no_name and no_labels:
            return
        if no_name:
            name = self.name
        else:
            self._name = name
            msg += ' name {}'.format(cyan(name))
        if no_labels:
            labels = self.labels
        else:
            labels = _labels_to_list(labels)
            if self._labels == labels:
                _logger.info('Labels of Folder %s remain unchanged',
                             cyan(self.name))
            else:
                self._labels = labels
                if not no_name:
                    msg += ' and'
                msg += ' labels {}'.format(cyan(labels))

        _logger.info(msg)
        CLIENT.update_asset(asset_id=self.id,
                            asset_type=self.type,
                            name=name,
                            labels=labels)

    def delete(self) -> None:
        """Deletes this Asset."""
        msg = 'Deleting {} {} in Folder {}'.format(
            self.type.capitalize(), *cyan(self.name, self.folder.name))
        if CLIENT.user_name != self.folder.owner:
            msg += ' of user {}'.format(cyan(self.folder.owner))
        _logger.info(msg)

        CLIENT.delete_asset(asset_id=self.id)

        self._alive = False


@_all_methods_alive_only
class Model(_Asset):
    """Represents a Model in server."""

    def __init__(self,
                 id_: str,
                 folder: 'Folder',
                 name: str,
                 labels: Union[str, Sequence[str], None] = None) -> None:
        super().__init__(id_, folder, name, labels)
        self._type = 'model'

    def list_branch(self) -> List[Dict[str, Any]]:
        """Lists branches in this Model."""
        return CLIENT.list_branch(asset_id=self.id)

    def create_branch(self, name: str):
        """Creates an empty branch of this Model.

        Args:
            name: Name of the branch.

        Returns:
            A `Branch` instance representing created branch.
        """
        _logger.info('Creating branch %s of Model %s', *cyan(name, self.name))

        try:
            id_ = CLIENT.create_empty_branch(asset_id=self.id,
                                             branch_name=name)
        except HTTPError as e:
            resp = e.response
            if resp.status_code == 409 and 'branch already exists' in resp.text:
                _logger.error('Branch %s of Model %s already exists',
                              *red(name, self.name))
                raise RuntimeError(
                    "Branch of Model '{}' already exists: '{}'".format(
                        self.name, name)) from e
            else:
                raise e

        return Branch(asset=self, name=name, id_=id_)

    def get_branch(self, name: str) -> 'Branch':
        """Gets a branch of this Model.

        Args:
            name: Name of the branch.

        Returns:
            A `Branch` instance representing retrieved branch.
        """
        id_ = CLIENT.get_asset_data_by_name(owner=self.folder.owner,
                                            asset_type=self.folder.type,
                                            folder_name=self.folder.name,
                                            asset_name=self.name,
                                            branch=name)['commit']

        return Branch(asset=self, name=name, id_=id_)

    def list_tag(self) -> List[Dict[str, Any]]:
        """Lists tags in this Model."""
        return CLIENT.list_tag(asset_id=self.id)

    def get_tag(self, name: str) -> 'Tag':
        """Gets a tag of this Model.

        Note that you are not able to get a tag with the same name of a branch.

        Args:
            name: Name of the tag.

        Returns:
            A `Tag` instance representing retrieved tag.
        """
        id_ = CLIENT.get_asset_data_by_name(owner=self.folder.owner,
                                            asset_type=self.folder.type,
                                            folder_name=self.folder.name,
                                            asset_name=self.name,
                                            tag=name)['commit']

        return Tag(asset=self, name=name, id_=id_)

    def get_commit(self, id_: str) -> 'Commit':
        """Gets a commit of this Model.

        Args:
            id_: ID of the commit.

        Returns:
            A `Commit` instance representing retrieved commit.
        """
        CLIENT.get_asset_data_by_name(owner=self.folder.owner,
                                      asset_type=self.folder.type,
                                      folder_name=self.folder.name,
                                      asset_name=self.name,
                                      commit=id_)

        return Commit(asset=self, id_=id_)


@_all_methods_alive_only
class Dataset(_Asset):
    """Represents a Dataset in server."""

    def __init__(self,
                 id_: str,
                 folder: 'Folder',
                 name: str,
                 labels: Union[str, Sequence[str], None] = None) -> None:
        super().__init__(id_, folder, name, labels)
        self._type = 'dataset'

        last_commit_id = CLIENT.list_commit(asset_id=id_,
                                            branch_name='main')[0]['id']
        self._branch = Branch(asset=self, name='main', id_=last_commit_id)

    @property
    def commit_id(self) -> str:
        return self._branch.id

    def list_commit(self) -> List[Dict[str, Any]]:
        """Lists commits of this Dataset."""
        return self._branch.list_commit()

    def list_object(self) -> List[Dict[str, Any]]:
        """Lists objects of this Dataset."""
        return self._branch.list_object()

    def create_commit(
            self,
            msg: str,
            add: Union[Sequence[str], Mapping[str, str], None] = None,
            delete: Optional[Sequence[str]] = None) -> Optional['Commit']:
        """Commits changes to this Dataset.

        First delete, then add.

        Examples:
            Add a file as object to this Dataset:
            ```
            dataset.create_commit(msg='add ...', add=['0.png'])
            ```

            Specify path in Datset for an object to add:
            ```
            dataset.create_commit(msg='add ...', add={'0.png': 'data/'})
            ```

            Add all files under a directory as objects:
            ```
            dataset.create_commit(msg='add ...', add=['./data'])
            ```

            Delete an object from this Dataset:
            ```
            dataset.create_commit(msg='delete ...', delete=['0.png'])
            ```

            Delete all objects under the same path:
            ```
            dataset.create_commit(msg='delete ...', delete=['data/'])
            ```

        Args:
            msg:
                Commit message.
            add:
                Files or directories to add to the branch, can be a sequence
                of local paths, a mapping from local paths to their paths in
                branch, or `None`. If empty sequence, empty mapping or `None`,
                add nothing.
            delete:
                Files or directories to delete from the branch, can be a
                sequence of local paths or `None`. If empty sequence or `None`,
                delete nothing.

        Returns:
            A `Commit` instance representing created commit if changes are
            commited, `None` if not.
        """
        _logger.info('Committing changes to Dataset %s', cyan(self.name))

        return self._branch.create_commit(msg=msg, add=add, delete=delete)

    def get_commit(self,
                   index: Optional[int] = None,
                   id_: Optional[str] = None) -> 'Commit':
        """Gets a commit of this Dataset.

        Args:
            index:
                Index of the commit in this branch, e.g. `0` for last commit,
                `-1` for first commit.
            id_:
                ID of the commit. If `index` is provided, `id_` will not be
                used.

        Returns:
            A `Commit` instance representing retrieved commit.
        """
        if index is not None:
            complete_id = self.list_commit()[index]['id']
        elif id_ is not None:
            match_num = 0
            for commit in self.list_commit():
                if commit['id'].startswith(id_):
                    complete_id = commit['id']
                    match_num += 1
            if match_num == 0:
                _logger.error('Commit %s of branch %s does not exist',
                              *red(id_, self.name))
                raise RuntimeError(
                    "Commit of branch '{}' does not exist: '{}'".format(
                        self.name, id_))
            elif match_num > 1:
                _logger.error('Multiple commits of branch %s match ID %s',
                              *red(self.name, id_))
                raise RuntimeError(
                    "Multiple commits of branch '{}' match ID: '{}'".format(
                        self.name, id_))
        else:
            _logger.error('Either `index` or `id_` must be provided')
            raise RuntimeError('Either `index` or `id_` must be provided')

        return Commit(asset=self, id_=complete_id)

    def list_tag(self) -> List[Dict[str, Any]]:
        """Lists tags in this Dataset."""
        return CLIENT.list_tag(asset_id=self.id)

    def get_tag(self, name: str) -> 'Tag':
        """Gets a tag of this Dataset.

        Note that you are not able to get a tag with the same name of a branch.

        Args:
            name: Name of the tag.

        Returns:
            A `Tag` instance representing retrieved tag.
        """
        assert name != 'main'

        id_ = CLIENT.get_asset_data_by_name(owner=self.folder.owner,
                                            asset_type=self.folder.type,
                                            folder_name=self.folder.name,
                                            asset_name=self.name,
                                            tag=name)['commit']

        return Tag(asset=self, name=name, id_=id_)

    def download(self,
                 paths: Optional[Sequence[str]] = None,
                 save_dir: str = '.') -> None:
        """Downloads objects of this Dataset.

        Args:
            paths:
                Files or directories to download from the Dataset, is a
                sequence of paths in Dataset. Here format `a/.../b` signifies
                a file while `a/.../b/` signifies a directory. Defaults to all
                objects.
            save_dir:
                Local directory which objects are downloaded to. If directory
                does not exist, create it. Defaults to current working
                directory.
        """
        self._branch.download(paths=paths, save_dir=save_dir)


class _Ref(object):
    """Represents a reference of Asset."""

    def __init__(self, asset: Union[Model, Dataset], id_: str) -> None:
        self._asset = asset
        self._type = ''
        self._objects_map = {}
        self._id = id_

    @property
    def asset(self) -> str:
        return self._asset

    @property
    def type(self) -> str:
        return self._type

    @property
    def id(self) -> str:
        return self._id

    def list_object(self) -> List[Dict[str, Any]]:
        """Lists objects of this reference."""
        ref = self.name if hasattr(self, 'name') else self.id
        object_data = CLIENT.list_object(asset_id=self.asset.id, ref=ref)
        self._objects_map = {obj['path']: obj for obj in object_data}
        return object_data

    def download(self) -> None:
        raise NotImplementedError()


@_all_methods_alive_only
class Branch(_Ref):
    """Represents a branch of Asset."""

    def __init__(self, asset: Union[Model, Dataset], name: str,
                 id_: str) -> None:
        super().__init__(asset, id_)
        self._type = 'branch'
        self._name = name

        self._alive = True

    @property
    def name(self) -> str:
        return self._name

    def list_commit(self) -> List[Dict[str, Any]]:
        """Lists commits of this branch."""
        return CLIENT.list_commit(asset_id=self.asset.id,
                                  branch_name=self.name)

    def create_commit(
        self,
        msg: str,
        delete: Union[Sequence[str], None] = None,
        add: Union[Sequence[str], Mapping[str, str], None] = None
    ) -> Optional['Commit']:
        """Commits changes to this branch.

        First delete, then add.

        Examples:
            Add a file as object to this branch:
            ```
            dataset.create_commit(msg='add ...', add=['model.pt'])
            ```

            Specify path in Model for an object to add:
            ```
            dataset.create_commit(msg='add ...', add={'model.pt': 'saved_model/'})
            ```

            Add all files under a directory as objects:
            ```
            dataset.create_commit(msg='add ...', add=['./saved_model'])
            ```

            Delete an object from this Model:
            ```
            dataset.create_commit(msg='delete ...', delete=['model.pt'])
            ```

            Delete all objects under the same path:
            ```
            dataset.create_commit(msg='delete ...', delete=['saved_model/'])
            ```

        Args:
            msg:
                Commit message.
            delete:
                Files or directories to delete from the branch, can be a
                sequence of paths in branch or `None`. If empty sequence or
                `None`, delete nothing. If files or directories to delete do
                not exist, do nothing (rather than raise an error). Here format
                `a/.../b` signifies a file, while `a/.../b/` signifies a
                directory.
            add:
                Files or directories to add to the branch, can be a sequence
                of local paths, a mapping from local paths to their paths in
                branch, or `None`. If empty sequence, empty mapping or `None`,
                add nothing.

        Returns:
            A `Commit` instance representing created commit if changes are
            commited, `None` if not.
        """
        _logger.info('Committing changes to branch %s of Model %s',
                     *cyan(self.name, self.asset.name))

        id_ = CLIENT.update_branch(asset_id=self.asset.id,
                                   branch_name=self.name,
                                   msg=msg,
                                   delete=delete,
                                   add=add)

        if id_:
            _logger.info('New commit %s created', cyan(id_[:12]))
            self._id = id_
            return Commit(asset=self.asset, id_=id_)
        else:
            _logger.warning('No changes to commit')

    def get_commit(self,
                   index: Optional[int] = None,
                   id_: Optional[str] = None) -> 'Commit':
        """Gets a commit of this branch.

        Args:
            index:
                Index of the commit in this branch, e.g. `0` for last commit,
                `-1` for first commit.
            id_:
                ID of the commit. If `index` is provided, `id_` will not be
                used.

        Returns:
            A `Commit` instance representing retrieved commit.
        """
        if index is not None:
            complete_id = self.list_commit()[index]['id']
        elif id_ is not None:
            match_num = 0
            for commit in self.list_commit():
                if commit['id'].startswith(id_):
                    complete_id = commit['id']
                    match_num += 1
            if match_num == 0:
                _logger.error('Commit %s of branch %s does not exist',
                              *red(id_, self.name))
                raise RuntimeError(
                    "Commit of branch '{}' does not exist: '{}'".format(
                        self.name, id_))
            elif match_num > 1:
                _logger.error('Multiple commits of branch %s match ID %s',
                              *red(self.name, id_))
                raise RuntimeError(
                    "Multiple commits of branch '{}' match ID: '{}'".format(
                        self.name, id_))
        else:
            _logger.error('Either `index` or `id_` must be provided')
            raise RuntimeError('Either `index` or `id_` must be provided')

        return Commit(asset=self.asset, id_=complete_id)

    def create_tag(self, name: str) -> 'Tag':
        """Creates a tag that points to this branch.

        Args:
            name: Name of the tag.

        Returns:
            A `Tag` instance representing created tag.
        """
        _logger.info('Creating tag %s of Model %s from branch %s',
                     *cyan(name, self.asset.name, self.name))

        CLIENT.create_tag(asset_id=self.asset.id,
                          asset_type=self.asset.type,
                          asset_name=self.asset.name,
                          tag_name=name,
                          ref=self.id)

        return Tag(asset=self.asset, name=name, id_=self.id)

    def download(self,
                 paths: Optional[Sequence[str]] = None,
                 save_dir: str = '.') -> None:
        """Downloads objects of this branch.

        Args:
            paths:
                Files or directories to download from the branch, is a sequence
                of paths in branch. Here format `a/.../b` signifies a file
                while `a/.../b/` signifies a directory. Defaults to all
                objects.
            save_dir:
                Local directory which objects are downloaded to. If directory
                does not exist, create it. Defaults to current working
                directory.
        """
        if paths is None:
            paths = ['./']
        elif len(paths) == 0:
            return

        CLIENT.download(ref_obj=self, paths=paths, save_dir=save_dir)

    def delete(self) -> None:
        """Deletes this branch."""
        _logger.info('Deleting branch %s of Model %s',
                     *cyan(self.name, self.asset.name))

        CLIENT.delete_branch(asset_id=self.asset.id, branch_name=self.name)

        self._alive = False


@_all_methods_alive_only
class Tag(_Ref):
    """Represents a tag of Asset."""

    def __init__(self, asset: Union[Model, Dataset], name: str,
                 id_: str) -> None:
        super().__init__(asset, id_)
        self._type = 'tag'
        self._name = name

        self._alive = True

    @property
    def name(self) -> str:
        return self._name

    def create_tag(self, name: str) -> 'Tag':
        """Creates another tag that points to this tag.

        Args:
            name: Name of the tag.

        Returns:
            A `Tag` instance representing created tag.
        """
        _logger.info('Creating tag %s of Model %s from tag %s',
                     *cyan(name, self.asset.name, self.name))

        CLIENT.create_tag(asset_id=self.asset.id,
                          asset_type=self.asset.type,
                          asset_name=self.asset.name,
                          tag_name=name,
                          ref=self.id)

        return Tag(asset=self.asset, name=name, id_=self.id)

    def download(self,
                 paths: Optional[Sequence[str]] = None,
                 save_dir: str = '.') -> None:
        """Downloads objects of this tag.

        Args:
            paths:
                Files or directories to download from the tag, is a sequence
                of paths in tag. Here format `a/.../b` signifies a file
                while `a/.../b/` signifies a directory. Defaults to all
                objects.
            save_dir:
                Local directory which objects are downloaded to. If directory
                does not exist, create it. Defaults to current working
                directory.
        """
        if paths is None:
            paths = ['./']
        elif len(paths) == 0:
            return

        CLIENT.download(ref_obj=self, paths=paths, save_dir=save_dir)

    def delete(self) -> None:
        """Deletes this tag."""
        _logger.info('Deleting tag %s of %s %s', cyan(self.name),
                     self.asset.type.capitalize(), cyan(self.asset.name))

        CLIENT.delete_tag(asset_id=self.asset.id, tag_name=self.name)

        self._alive = False


class Commit(_Ref):
    """Represents a commit of Asset."""

    def __init__(self, asset: Union[Model, Dataset], id_: str) -> None:
        super().__init__(asset, id_)
        self._type = 'commit'

    def create_tag(self, name: str) -> 'Tag':
        """Creates a tag that points to this commit.

        Args:
            name: Name of the tag.

        Returns:
            A `Tag` instance representing created tag.
        """
        _logger.info('Creating tag %s of Model %s from commit %s',
                     *cyan(name, self.asset.name, self.id))

        CLIENT.create_tag(asset_id=self.asset.id,
                          asset_type=self.asset.type,
                          asset_name=self.asset.name,
                          tag_name=name,
                          ref=self.id)

        return Tag(asset=self.asset, name=name, id_=self.id)

    def download(self,
                 paths: Optional[Sequence[str]] = None,
                 save_dir: str = '.') -> None:
        """Downloads objects of this commit.

        Args:
            paths:
                Files or directories to download from the commit, is a sequence
                of paths in commit. Here format `a/.../b` signifies a file
                while `a/.../b/` signifies a directory. Defaults to all
                objects.
            save_dir:
                Local directory which objects are downloaded to. If directory
                does not exist, create it. Defaults to current working
                directory.
        """
        if paths is None:
            paths = ['./']
        elif len(paths) == 0:
            return

        CLIENT.download(ref_obj=self, paths=paths, save_dir=save_dir)


def _labels_to_list(labels: Union[str, Sequence[str], None]) -> List[str]:
    if labels is None:
        return []
    elif isinstance(labels, str):
        return [labels]
    elif isinstance(labels, Sequence):
        for label in labels:
            assert isinstance(label, str)
        return list(labels)
    else:
        _logger.error(
            'str, Sequence or NoneType instance expected but %s instance '
            'received for arg labels',
            type(labels).__name__)
        raise TypeError('Invalid type for labels')
