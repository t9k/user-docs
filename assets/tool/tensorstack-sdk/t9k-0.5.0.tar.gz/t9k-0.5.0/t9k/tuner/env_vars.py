# Copyright (c) Microsoft Corporation.
# Licensed under the MIT license.

import os
from collections import namedtuple


_trial_env_var_names = [
    'TUNER_EXP_ID',
    'TUNER_TRIAL_JOB_ID',
    'TUNER_TRIAL_SEQ_ID',
    'AUTO_TUNE_SERVER_ADDR'
]


def _load_env_vars(env_var_names):
    env_var_dict = {k: os.environ.get(k) for k in env_var_names}
    return namedtuple('EnvVars', env_var_names)(**env_var_dict)


trial_env_vars = _load_env_vars(_trial_env_var_names)
