"""Artifact class."""

from glob import glob
import logging
import os
import shutil
from typing import Any, Dict, List, Optional, Sequence

from requests import HTTPError

from t9k.aimd.client import CLIENT
from t9k.utils.datetime_utils import get_local_now_iso
from t9k.utils.decorators import called_once_only_each_instance
from t9k.utils.file_utils import (abspath, basename, dirname, isdir,
                                       isfile, join, relpath, get_file_size,
                                       get_file_md5, read_yaml_file,
                                       update_json_file, write_yaml_file,
                                       update_yaml_file)
from t9k.utils.print_utils import black, blue, cyan, red
from t9k.utils.uuid_utils import new_uuid

_logger = logging.getLogger(__name__)

ARTIFACT_PATH = '.aimd/artifacts'


def _open_only(func):
    def wrapper(self, *args, **kwargs):
        if self.is_open:
            return func(self, *args, **kwargs)
        else:
            _logger.error('Artifact is not open to change, because it has '
                          'already been uploaded to remote server.')
            raise RuntimeError(
                'Artifact is not open to change, because it has '
                'already been uploaded to remote server.')

    return wrapper


class Artifact(object):
    """Implementation of Artifact, a set of files that a Trial inputs or
    outputs.

    Args:
        artifact_data:
            Data of Artifact to initialize a new Artifact.
        repo_data:
            Data of the repo that the Artifact belongs to.
        object_data:
            Data of objects of the Artifact.
        can_be_logged:
            If True, the Artifact initialized can be logged by a Trial.

    Attributes:
        id:
            ID of the Artifact.
        name:
            Name of repo of the Artifact.
        description:
            Description of the Artifact.
        commit:
            Hash of commit of the Artifact. It is None if the Artifact has
            never been uploaded.
        version:
            Version of the Artifact. It is None if the Artifact has never been
            uploaded.
        aliases:
            Aliases of the Artifact.
        objects:
            Data of objects of the Artifact.
        repo:
            Data of repo of the Artifact.
        remote:
            Location of the Artifact in remote AIMD server. It is None if
            the Artifact has never been uploaded.
        is_open:
            If True, the Artifact has not been uploaded yet and thus open to
            changes.
    """

    def __init__(self,
                 artifact_data: Dict[str, Any],
                 repo_data: Dict[str, str],
                 object_data: Optional[Sequence[Dict[str, Any]]] = None,
                 can_be_logged: bool = True):
        self.parse_from_dict(artifact_data)
        self._repo = repo_data
        if object_data:
            self._objects_map = {obj['key']: obj for obj in object_data}
        else:
            self._objects_map = {}
        self._prepare_local_file()

        # Indicate whether the Artifact has been uploaded and thus no longer
        # open to changes. Only open Artifacts can call its `upload()` method;
        # only closed Artifacts can be used by a Trial.
        self._is_open = not bool(self._commit)

        # If the Artifact is loaded from local or server, it cannot be logged;
        # if the Artifact has beed logged once, it cannot be logged.
        self._can_be_logged = can_be_logged

    @property
    def id(self) -> str:
        return self._metadata['id']

    @property
    def name(self) -> str:
        return self._repo['name']

    @property
    def description(self) -> str:
        return self._description

    @property
    def commit(self) -> str:
        return self._commit

    @property
    def version(self) -> str:
        return self._version

    @property
    def aliases(self) -> List[str]:
        return self._aliases

    @property
    def objects(self) -> List[Dict[str, str]]:
        return list(self._objects_map.values())

    @property
    def repo(self) -> Dict[str, str]:
        return self._repo

    @property
    def remote(self) -> List[Dict[str, str]]:
        return self._remote

    @property
    def is_open(self) -> bool:
        return self._is_open

    def local_path(self, key: Optional[str] = None) -> Optional[str]:
        """Returns local path of the Artifact of its object."""
        if not key:
            return self._path
        elif key in self._objects_map:
            return join(self._object_path, key)
        return

    def parse_from_dict(self, artifact_data: Dict[str, Any]) -> None:
        """Parses an Artifact instance from a dict."""
        self._metadata = artifact_data['metadata']
        self._description = artifact_data['description']

        self._commit = artifact_data['commit']
        self._version = artifact_data['version']

        aliases = artifact_data['aliases']
        if aliases is None:
            self._aliases = []
        elif isinstance(aliases, list):
            self._aliases = aliases
        else:
            raise ValueError('Invalid aliases')

        self._creating_timestamp = artifact_data['creatingTimestamp']

        self._remote = artifact_data.get('_remote', [])

    def to_dict(self) -> Dict[str, Any]:
        """Converts Artifact instance to a dict and returns it."""
        return {
            'kind': 'Artifact',
            'metadata': self._metadata,
            'description': self._description,
            'commit': self._commit,
            'version': self._version,
            'aliases': self._aliases or None,
            'creatingTimestamp': self._creating_timestamp,
            '_remote': self._remote,
        }

    def upload(self,
               folder_id: Optional[str] = None,
               folder_path: Optional[str] = None,
               make_folder: bool = False) -> Dict[str, Any]:
        """Uploads Artifact to server.

        For information of the arguments, refer to `create_trial()` API.

        Returns:
            Data of the posted Artifact from server.
        """
        self._upload_info = {
            'folder_id': folder_id,
            'folder_path': folder_path,
            'make_folder': make_folder,
        }

        _logger.info('Uploading Artifact %s', cyan(self.id))
        artifact_data = self._upload()

        artifact_addr = '{}/web/#/folders/{}/?artifactVersion={}'.format(
            dirname(CLIENT.host), artifact_data['metadata']['folder'],
            artifact_data['version'])
        _logger.info('Artifact uploaded, view its data by visiting %s',
                     blue(artifact_addr, underline=True))

        return artifact_data

    @called_once_only_each_instance()
    def _upload(self) -> Dict[str, Any]:
        """Implements uploading Artifact to server.

        This method will post complete data of the Artifact to server by
        calling `CLIENT.add_artifact()`.

        This method could only be called once. Once posted the Artifact
        is no longer open to changes.
        """
        new_data = CLIENT.add_artifact(self)
        self._metadata = new_data['metadata']
        _logger.debug('Update Artifact with new metadata %s from server',
                      new_data['metadata'])
        self._commit = new_data['commit']
        self._version = new_data['version']
        _logger.debug(
            'Update Artifact with new commit %s and version %s from server',
            new_data['commit'], new_data['version'])

        folder_id = new_data['metadata']['folder']
        folder_path = CLIENT.get_folder_path_by_id(folder_id=folder_id)
        self._remote.append({
            'host': CLIENT.host,
            'path': folder_path,
            'version': new_data['version']
        })

        write_yaml_file(self._metadata_path, self.to_dict())

        self._is_open = False

        return new_data

    @staticmethod
    def _load_from_local(artifact_path: str) -> 'Artifact':
        """Loads an Artifact by ID from local."""
        _logger.info('Loading Artifact from local path %s',
                     black(artifact_path, underline=True))

        metadata_file_path = join(artifact_path, 'metadata.yaml')
        repo_file_path = join(artifact_path, '..', 'metadata.yaml')
        object_file_path = join(artifact_path, 'object_list.yaml')

        if not (isfile(metadata_file_path) and isfile(repo_file_path)
                and isfile(object_file_path)):
            _logger.error(
                'Failed to load Artifact in path: %s, the directory must '
                'contain file `metadata.yaml` and `metrics.yaml`, and the '
                'parent directory must contain file `metadata.yaml`',
                red(artifact_path))
            raise RuntimeError(
                'Failed to load Artifact in path: {}, the directory must '
                'contain file `metadata.yaml` and `metrics.yaml`, and the '
                'parent directory must contain file `metadata.yaml`'.format(
                    artifact_path))

        def load_data_file(file_path: str) -> Dict[str, Any]:
            msg = ('Invalid data file of Artifact: {}, please read the '
                   'exception message and check the file').format(
                       red(file_path))
            return read_yaml_file(file_path, error_msg=msg)

        artifact_data = load_data_file(metadata_file_path)
        repo_data = load_data_file(repo_file_path)
        object_data = load_data_file(object_file_path)

        return Artifact(artifact_data=artifact_data,
                        repo_data=repo_data,
                        object_data=object_data,
                        can_be_logged=False)

    @staticmethod
    def _load_from_server(artifact_id: str) -> 'Artifact':
        """Loads an Artifact by ID from server."""
        _logger.info('Loading Artifact %s from server', cyan(artifact_id))
        try:
            artifact_data = CLIENT.get_artifact_data_by_id(
                artifact_id=artifact_id)
        except HTTPError as e:
            _logger.debug('Artifact with ID %s does not exist in server',
                          artifact_id)
            raise RuntimeError('Artifact with ID {} does not exist'.format(
                artifact_id)) from e

        full_repo_data = CLIENT.get_folder_data_by_id(
            folder_id=artifact_data['metadata']['folder'])
        assert full_repo_data['type'] == 'artifact'
        repo_data = {
            'name': full_repo_data['metadata']['name'],
            'type': full_repo_data['config']['profile']['type'],
        }

        folder_id = artifact_data['metadata']['folder']
        folder_path = CLIENT.get_folder_path_by_id(folder_id=folder_id)
        artifact_data['_remote'] = [{
            'host': CLIENT.host,
            'path': folder_path,
            'version': artifact_data['version']
        }]

        artifact_objects = CLIENT.ls_artifact_object_by_id(
            artifact_id=artifact_id)
        object_data = [
            {
                'key': obj['path'],
                'size': obj['size_bytes'],
                # 'digest': obj['checksum'],
            } for obj in artifact_objects
        ]

        artifact = Artifact(artifact_data=artifact_data,
                            repo_data=repo_data,
                            object_data=object_data,
                            can_be_logged=False)

        update_yaml_file(artifact._object_list_path,
                         update=artifact._objects_map,
                         postprocessor=lambda x: list(x.values()))

        return artifact

    def _prepare_local_file(self) -> None:
        """Prepares local directory and file for Artifact.

        Create a directory of Artifact, under the directory create some YAML
        files to store Artifact data and put files of objects of this Artifact.

        If the directory already exists, do nothing. This occurs when loading
        a local Artifact.
        """
        self._repo_path = join(ARTIFACT_PATH, self.name)
        self._path = join(self._repo_path, self.id)
        self._metadata_path = join(self._path, 'metadata.yaml')
        self._object_list_path = join(self._path, 'object_list.yaml')
        self._object_path = join(self._path, 'objects')
        self._reference_path = join(self._object_path, 'references.json')
        if isdir(self._path):
            return

        _logger.debug('Create local directory for Artifact %s', self.id)

        os.makedirs(self._path)
        os.makedirs(self._object_path)
        self._update_repo_metadata()
        write_yaml_file(self._metadata_path, self.to_dict())

        _logger.debug('Local directory created: %s', abspath(self._path))

    def _update_repo_metadata(self) -> None:
        """Updates local metadata file of repo of the Artifact."""
        repo_metadata_path = join(self._repo_path, 'metadata.yaml')

        def update_func(data: Dict[str, Any]) -> Dict[str, Any]:
            if 'artifacts' not in data:
                data['artifacts'] = []
            data['artifacts'].append({
                'id': self.id,
                'timestamp': self._metadata['timestamp'],
                'description': self.description,
            })
            return data

        update_yaml_file(repo_metadata_path,
                         postprocessor=update_func,
                         not_exist_initial=self._repo.copy())

    @_open_only
    def add_file(self, file_path: str, key: Optional[str] = None) -> None:
        """Adds a local file as an object of the Artifact.

        The file will be copied to object path of the Artifact, the specific
        subpath depends on its key, for example:

        ```
        # file copied to `<object-path>/1.png`
        artifact.add_file(file_path='1.png')
        # or
        artifact.add_file(file_path='1.png', key='1.png')

        # file copied to `<object-path>/a/1.png`
        artifact.add_file(file_path='1.png', key='a/')
        # or
        artifact.add_file(file_path='1.png', key='a/1.png')
        ```
        """
        file_path = abspath(file_path)
        if not isfile(file_path):
            _logger.error('Path %s does not refer to an existing file',
                          file_path)
            raise RuntimeError(
                'Path {} does not refer to an existing file.'.format(
                    file_path))
        file_size = get_file_size(file_path)
        if file_size > 10 * 1024 * 1024 * 10000:  # 97GiB + 672MiB
            file_size_in_gib = round(file_size / 1024**3, 2)
            _logger.error(
                'Cannot add file %s to Artifact, its size %sGiB exceeds the '
                'limit of 97.65GiB', file_path, file_size_in_gib)
            raise RuntimeError(
                'Cannot add file {} to Artifact, its size {}GiB exceeds the '
                'limit of 97.65GiB'.format(file_path, file_size_in_gib))

        key = self._determine_object_key(file_path, key)

        dst_path = join(self._object_path, key)
        os.makedirs(dirname(dst_path), exist_ok=True)

        shutil.copy(src=file_path, dst=dst_path)
        self._objects_map[key] = {
            'key': key,
            'size': file_size,
            # Temporarily remove field "digest" and disable MD5 check, for the
            # "checksum" value returned by `/artifacts/{id}/objects/ls` is in
            # fact the ETag of object. For multipart uploaded object, the ETag
            # cannot be used to check the file.
            #
            # 'digest': get_file_md5(dst_path),
        }
        update_yaml_file(
            self._object_list_path,
            preprocessor=lambda x: {obj['key']: obj
                                    for obj in x},
            update=self._objects_map,
            postprocessor=lambda x: list(x.values()),
        )

        _logger.debug('Add file %s as object %s of Artifact %s', file_path,
                      key, self.id)

    @_open_only
    def add_dir(self, dir_path: str, key: Optional[str] = None) -> None:
        """Adds all files under a local directory as objects of the Artifact.

        The directory will be copied to object path of the Artifact, the
        specific subpath depends on its key, for example:

        ```
        # dir copied to `<object-path>/a`
        artifact.add_dir(dir_path='a/')
        # or
        artifact.add_dir(dir_path='a')
        # or
        artifact.add_dir(dir_path='a/', key='a')

        # dir copied to `<object-path>/b/a`
        artifact.add_dir(dir_path='a/', key='b/')
        # or
        artifact.add_dir(dir_path='a/', key='b/a')
        ```
        """
        dir_path = abspath(dir_path)
        if not isdir(dir_path):
            _logger.error('Path %s does not refer to an existing directory',
                          dir_path)
            raise RuntimeError(
                'Path {} does not refer to an existing directory.'.format(
                    dir_path))

        key = self._determine_object_key(dir_path, key)

        dst_path = join(self._object_path, key)
        os.makedirs(dirname(dst_path), exist_ok=True)
        shutil.copytree(src=dir_path, dst=dst_path, dirs_exist_ok=True)
        for root, _, files in os.walk(dst_path):
            for file in files:
                file_path = join(root, file)
                file_key = relpath(file_path, self._object_path)
                self._objects_map[file_key] = {
                    'key': file_key,
                    'size': get_file_size(file_path),
                    # 'digest': get_file_md5(file_path),
                }
        update_yaml_file(self._object_list_path,
                         preprocessor=lambda x: {obj['key']: obj
                                                 for obj in x},
                         update=self._objects_map,
                         postprocessor=lambda x: list(x.values()))

        _logger.debug('Add directory %s to %s of Artifact %s', dir_path, key,
                      self.id)

    @_open_only
    def add_reference(self, uri: str, key: Optional[str] = None) -> None:
        """Adds a URI as an object reference to the Artifact."""
        key = self._determine_object_key(uri, key)
        update = {key: uri}
        update_json_file(self._reference_path, update=update)

        _logger.debug('Add reference %s to %s of Artifact %s', uri, key,
                      self.id)

    def download(self) -> None:
        """Downloads all Artifact objects to local.

        For each object, if it already exists in object path and passes size
        and MD5 checking, it will not be downloaded.
        """
        _logger.info('Downloading objects of Artifact %s', cyan(self.id))
        # TODO: multi-thread downloading
        object_num = len(self._objects_map)
        for i, obj in enumerate(self._objects_map.values(), start=1):
            key = obj['key']
            size = obj['size']
            file_path = join(self._object_path, key)
            if not (isfile(file_path)
                    and get_file_size(file_path) == obj['size']):
                # and get_file_md5(file_path) == obj['digest']):
                dir_name = dirname(key)
                os.makedirs(join(self._object_path, dir_name), exist_ok=True)
                _logger.info('Downloading object %s/%s %s:', i, object_num,
                             cyan(key))
                CLIENT.download_artifact_object(artifact_id=self.id,
                                                key=key,
                                                size=size,
                                                download_path=file_path)

                if not (isfile(file_path)
                        and get_file_size(file_path) == obj['size']):
                    # and get_file_md5(file_path) == obj['digest']):
                    raise RuntimeError('Download error')

        _logger.info('Download complete, all objects saved to %s',
                     black(self._path, underline=True))

    @staticmethod
    def _determine_object_key(path: str, key: Optional[str]) -> str:
        if not key:
            return basename(path)

        if key.startswith('/'):
            key = key[1:]
        if key.endswith('/'):
            key = key + basename(path)
        return key


def _new_artifact(name: str,
                  type_: str,
                  description: str,
                  aliases: Optional[Sequence[str]] = None) -> Artifact:
    """Creates and initializes a new Artifact instance."""
    new_id = new_uuid()
    _logger.info('Creating Artifact %s of type %s with ID %s',
                 *cyan(name, type_, new_id))

    # Artifact data
    artifact_data = {
        'kind': 'Artifact',
        'metadata': {
            'folder': None,
            'name': '',
            'editor': None,
            'id': new_id,
            'timestamp': None,
        },
        'description': description,
        'commit': None,
        'version': None,
        'aliases': aliases,
        'creatingTimestamp': get_local_now_iso(),
    }

    # Artifact repo data
    repo_data = {
        'name': name,
        'type': type_,
    }

    _logger.debug('Artifact summary:')
    _logger.debug('  name: %s', name)
    _logger.debug('  type: %s', type_)
    _logger.debug('  ID: %s', artifact_data['metadata']['id'])
    _logger.debug('  description: %s', description)
    if aliases:
        _logger.debug('    aliases: %s', aliases)

    artifact = Artifact(artifact_data=artifact_data, repo_data=repo_data)
    _logger.debug('Artifact creation and initialization complete')

    return artifact


def _get_artifact_path_by_id(id_: str) -> Optional[str]:
    """Trys to get local path of Artifact by its ID.

    Only Artifact_PATH will be searched.
    """
    artifact_paths = glob('{}/*/*-*-*-*-*'.format(ARTIFACT_PATH))
    for p in artifact_paths:
        if basename(p) == id_:
            return p

    _logger.debug(
        'Failed to get Artifact path for no local Artifact matched the ID: %s',
        id_)
    return
