"""AIMD client."""

import collections
import logging
from typing import Any, BinaryIO, Dict, Iterator, List, Optional, Tuple

import requests
import simplejson
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TimeRemainingColumn,
    TransferSpeedColumn,
)

from t9k import CONFIG
from t9k.aimd.containers import Metric, Metrics
from t9k.utils.file_utils import join, basename, dirname
from t9k.utils.print_utils import red, blue, cyan, magenta
from t9k.utils.url_utils import check_url
from t9k.utils.uuid_utils import is_uuid

_logger = logging.getLogger(__name__)


def _all_methods_online_only(cls):
    def online_only(func):
        def wrapper(self, *args, offline_ok=False, **kwargs):
            if self.online:
                return func(self, *args, **kwargs)
            elif offline_ok:
                return
            else:
                _logger.error('Cannot correspond with AIMD server for not '
                              'logging in, please first call `aimd.login()`')
                raise RuntimeError('Cannot correspond with AIMD server for not'
                                   ' logging in, please first call '
                                   '`aimd.login()`')

        return wrapper

    for attr in cls.__dict__:
        if callable(getattr(cls, attr)) and attr not in [
                '__init__', 'test_connection', 'request'
        ]:
            setattr(cls, attr, online_only(getattr(cls, attr)))
    return cls


@_all_methods_online_only
class _AIMDClient(object):
    """Corresponds with AIMD server.

    Attributes:
        api_key:
            API Key for requesting server.
        headers:
            HTTP headers of request.
        online:
            Flag to indicate whether client can connect to AIMD server. If
            False, any method call (except for magic methods) without kwarg
            `offline_ok = True` will raise a RuntimeError, any with kwarg
            `offline_ok = True` will do nothing.
        host:
            URL of server.
        timeout:
            How many seconds to wait for server to send data before giving up.
    """

    def __init__(self):
        self.host = None
        self.api_key = None

        self.headers = {}
        self.timeout = None

        self.online = False

    def add_trial(self, trial) -> Optional[Dict[str, str]]:
        """Posts a new Trial to server.

        Args:
            trial: Trial instance which data is to be posted.

        Returns:
            Metadata of the posted Trial from server.

        Raises:
            requests.HTTPError: Invalid Trial data format.
        """
        trial_data = trial.to_dict()
        metadata = trial_data['metadata']
        id_ = metadata['id']
        name = metadata['name']
        upload = trial_data.pop('_upload')
        params = trial_data.pop('parameters')
        metrics = trial_data.pop('metrics')
        _logger.debug('Post Trial "%s" to server', name)

        folder_id, folder_path = self.determine_folder_used(
            upload['folder_id'], upload['folder_path'], upload['make_folder'])
        metadata['folder'] = folder_id
        _logger.info('Creating Trial %s in folder %s',
                     *cyan(name, folder_path))
        _logger.debug('Create Trial "%s" in folder with ID %s', name,
                      folder_id)

        conflict_strategy = upload['conflict_strategy']

        url = '{}/apis/v1/trials'.format(self.host)
        try:
            self.request(method='POST', url=url, json_data=trial_data)
        except requests.HTTPError as e:
            resp = e.response
            if resp.status_code == 400 and 'uuid already exists' in resp.text:
                trial_addr = join(dirname(self.host), 'web/#/trials', id_, '')
                _logger.error(
                    'Trial with ID %s has already been uploaded, visit %s. You'
                    ' can move it or create a shortcut of it',
                    red(metadata['id']), blue(trial_addr, underline=True))
                raise RuntimeError(
                    'Trial with ID {} has already been uploaded'.format(
                        metadata['id'])) from e
            elif resp.status_code == 400 and resp.text.startswith(
                    'Trial') and resp.text.endswith('already exists'):
                if conflict_strategy == 'skip':
                    _logger.info(
                        'Trial with name %s already exists in folder %s, skip '
                        'this upload', *cyan(name, folder_path))
                    return
                elif conflict_strategy == 'error':
                    _logger.error(
                        'Trial with name %s already exists in folder %s, abort',
                        *red(name, folder_path))
                    raise RuntimeError(
                        'Trial with name {} already exists in folder {}'.
                        format(name, folder_path)) from e
                elif conflict_strategy == 'new':
                    _logger.info(
                        'Trial with name %s already exists in folder %s, '
                        'upload with local name %s',
                        *cyan(name, folder_path, trial._local_name))
                    metadata['name'] = trial._local_name
                    self.request(method='POST', url=url, json_data=trial_data)
                elif conflict_strategy == 'replace':
                    _logger.info(
                        'Trial with name %s already exists in folder %s, '
                        'upload to replace it', *cyan(name, folder_path))
                    exist_id = self.get_trial_id_by_name(folder_id=folder_id,
                                                         trial_name=name)
                    self.delete_trial(trial_id=exist_id)
                    self.request(method='POST', url=url, json_data=trial_data)
                else:
                    _logger.error('Not supported conflict strategy: %s',
                                  conflict_strategy)
                    raise ValueError(
                        'Not supported conflict strategy: {}'.format(
                            conflict_strategy)) from e
            else:
                raise e

        if params:
            _logger.debug(
                'Parameters are provided and post them to server as well')
            self.update_parameters(trial_id=id_, params=params)

        if metrics:
            _logger.debug(
                'Metrics are provided and post them to server as well')
            for metrics_type in metrics:
                self.append_metrics(trial_id=id_,
                                    metrics_type=metrics_type,
                                    metrics=metrics[metrics_type])

        new_metadata = self.get_trial_data(id_)['metadata']
        return new_metadata

    def delete_trial(self, trial_id: str) -> None:
        """Deletes a Trial in server.

        Args:
            trial_id: ID of Trial.

        Raises:
            requests.HTTPError: Trial with trial_id does not exist.
        """
        _logger.debug('Delete Trial %s in server', trial_id)
        url = '{}/apis/v1/trials/{}'.format(self.host, trial_id)
        self.request(method='DELETE', url=url)

    def get_trial_data(self,
                       trial_id: str,
                       full: bool = False) -> Dict[str, Any]:
        """Gets Trial data by ID from server.

        Args:
            trial_id: ID of Trial.
            full: If True, get data of params and metrics of Trial as well.

        Returns:
            Trial data retrieved.

        Raises:
            requests.HTTPError: Trial with trial_id does not exist.
        """
        _logger.debug('Get data of Trial with ID %s from server', trial_id)
        url = '{}/apis/v1/trials/{}'.format(self.host, trial_id)
        trial_data = self.request(method='GET', url=url)['doc']
        if full:
            trial_data['parameters'] = self.get_parameters(trial_id)
            trial_data['metrics'] = self.get_metrics(trial_id)
        return trial_data

    def update_trial(self, trial_id: str, trial_data: Dict[str, Any]) -> None:
        """Posts updated full Trial data to server.

        Args:
            trial_id: ID of Trial.
            trial_data: Updated Trial data.

        Raises:
            requests.HTTPError:
                Trial with trial_id does not exist or invalid data format.
        """
        _logger.debug('Post Trial data %s to server', trial_data)
        url = '{}/apis/v1/trials/{}'.format(self.host, trial_id)
        self.request(method='PUT', url=url, json_data=trial_data)

    def get_trial_id_by_name(self, folder_id: str, trial_name: str) -> str:
        """Gets Trial ID by name and folder ID from server."""
        _logger.debug('Get Trial id by folder id %s and name %s', folder_id,
                      trial_name)
        url = '{}/apis/v1/trials/id'.format(self.host)
        params = {'folder': folder_id, 'name': trial_name}
        return self.request(method='GET', url=url, params=params)

    def update_platform(self, trial_id: str, platform_info: dict) -> None:
        """Posts updated platform info of Trial to server.

        Args:
            trial_id: ID of Trial.
            platform_info: Updated platform info.

        Raises:
            requests.HTTPError: Trial with trial_id does not exist.
        """
        _logger.debug('Post platform info %s of Trial %s to server',
                      platform_info, trial_id)
        url = '{}/apis/v1/trials/{}'.format(self.host, trial_id)
        trial_data = self.request(method='GET', url=url)['doc']
        trial_data['platform'] = platform_info
        self.request(method='PUT', url=url, json_data=trial_data)

    def update_status(self,
                      trial_id: str,
                      status: str,
                      end_time: Optional[str] = None) -> None:
        """Posts updated status of Trial to server.

        Args:
            trial_id:
                ID of Trial.
            status:
                Updated status of Trial, must be 'Running', 'Succeeded' or
                'Failed'.
            end_time:
                End time of Trial.

        Raises:
            requests.HTTPError: Trial with trial_id does not exist.
        """
        _logger.debug('Post status "%s" of Trial %s to server', status,
                      trial_id)
        url = '{}/apis/v1/trials/{}/status'.format(self.host, trial_id)
        if end_time is None:
            status_data = {
                'status': status,
            }
        else:
            status_data = {
                'status': status,
                'endTime': end_time,
            }
        self.request(method='POST', url=url, json_data=status_data)

    def update_parameters(self, trial_id: str, params: Dict[str, Any]) -> None:
        """Posts updated parameters of Trial to server.

        Args:
            trial_id: ID of Trial.
            params: Updated parameters of Trial.

        Raises:
            requests.HTTPError: Trial with trial_id does not exist.
        """
        _logger.debug('Post parameters %s to server', params)
        url = '{}/apis/v1/trials/{}/parameters'.format(self.host, trial_id)
        self.request(method='POST', url=url, json_data=params)

    def get_parameters(self, trial_id: str) -> Dict[str, Any]:
        """Gets parameters of Trial by ID from server."""
        _logger.debug('Get parameters from server')
        url = '{}/apis/v1/trials/{}/parameters'.format(self.host, trial_id)
        return self.request(method='GET', url=url)

    def append_metrics(self, trial_id: str, metrics_type: str,
                       metrics: List[Metric]) -> None:
        """Posts additional metrics of Trial to server.

        Args:
            trial_id:
                ID of Trial.
            metrics:
                Additional metrics of Trial.
            metrics_type:
                Type of metrics.

        Raises:
            requests.HTTPError: Trial with trial_id does not exist.
        """
        _logger.debug('Post additional "%s" metrics %s to server',
                      metrics_type, metrics)
        url = '{}/apis/v1/trials/{}/metrics/{}'.format(self.host, trial_id,
                                                       metrics_type)
        self.request(method='POST', url=url, json_data=metrics)

    def get_metrics(self, trial_id: str) -> Metrics:
        """Gets metrics of Trial by ID from server."""
        _logger.debug('Get metrics from server')
        url = '{}/apis/v1/trials/{}/metrics'.format(self.host, trial_id)
        return self.request(method='GET', url=url)

    def add_artifact(self, artifact) -> Dict[str, Any]:
        """Posts a new Artifact to server.

        Args:
            artifact: Artifact instance which data is to be posted.

        Returns:
            Data of the posted Artifact from server.

        Raises:
            requests.HTTPError: Invalid Artifact data format.
        """
        artifact_data = artifact.to_dict()
        del artifact_data['_remote']
        upload = artifact._upload_info
        repo = artifact.repo
        _logger.debug('Post Artifact "%s" to server')

        # 1. post metadata of Artifact
        folder_id, folder_path = self.determine_folder_used(
            upload['folder_id'], upload['folder_path'], upload['make_folder'])
        _logger.debug('Artifact %s is added in folder %s with id %s',
                      repo['name'], folder_path, folder_id)

        url = '{}/apis/v1/artifacts'.format(self.host)
        params = {
            'folder': folder_id,
            'repo': repo['name'],
            'type': repo['type'],
        }

        artifact_id = self.request(method='POST',
                                   url=url,
                                   json_data=artifact_data,
                                   params=params)['id']

        # 2. post objects
        object_num = len(artifact.objects)
        url = '{}/apis/v1/artifacts/{}/objects'.format(self.host, artifact_id)
        for i, obj in enumerate(artifact.objects, start=1):
            key = obj['key']
            size = obj['size']
            file_path = join(artifact._object_path, key)
            _logger.info('Uploading object %s/%s %s:', i, object_num,
                         cyan(key))
            if size <= 100 * 1024 * 1024:  # 100MiB
                print(' ' * 11 + 'Uploading...', end='', flush='True')
                params = {'key': key}
                files = {'content': open(file_path, 'rb')}
                self.request(method='POST',
                             url=url,
                             params=params,
                             files=files)
                print('\r' + ' ' * 11 + 'Done' + ' ' * 8, flush='True')

            elif size <= 10 * 1024 * 1024 * 10000:  # 97GiB + 672MiB
                self._multipart_upload(artifact_id=artifact_id,
                                       key=key,
                                       size=size,
                                       file_path=file_path)
            else:
                size_in_gib = round(size / 1024**3, 2)
                _logger.error(
                    'Cannot upload object %s, its size %sGiB exceeds the limit '
                    'of 97.65GiB', *red(key, size_in_gib))
                raise RuntimeError(
                    'Cannot upload object {}, its size {}GiB exceeds the limit '
                    'of 97.65GiB'.format(key, size_in_gib))

        # 3. finish
        url = '{}/apis/v1/artifacts/{}/finalize'.format(self.host, artifact_id)
        self.request(method='PUT', url=url)

        new_data = self.get_artifact_data_by_id(artifact_id)
        return new_data

    def _multipart_upload(self, artifact_id: str, key: str, size: int,
                          file_path: str) -> None:
        url_create = '{}/apis/v1/artifacts/{}/multipart'.format(
            self.host, artifact_id)
        params = {'key': key}
        upload_id = self.request(method='POST', url=url_create,
                                 params=params)['uploadId']

        def read_in_chunks(file_object: BinaryIO,
                           chunk_size: int) -> Iterator[bytes]:
            while True:
                data = file_object.read(chunk_size)
                if not data:
                    break
                yield data

        if size > 6 * 1024 * 1024 * 10000:
            chunk_size = size // 10000
        else:
            chunk_size = 6 * 1024 * 1024

        progress = Progress(' ' * 10,
                            BarColumn(bar_width=None),
                            '[progress.percentage]{task.percentage:>3.1f}%',
                            '•',
                            DownloadColumn(),
                            '•',
                            TransferSpeedColumn(),
                            '•',
                            TimeRemainingColumn(),
                            console=Console(stderr=True))
        with progress:
            task_id = progress.add_task('download', start=False)
            progress.update(task_id, total=size)
            with open(file_path, 'rb') as f:
                parts = []
                progress.start_task(task_id)
                for n, piece in enumerate(read_in_chunks(f, chunk_size),
                                          start=1):
                    url_upload = (
                        '{}/apis/v1/artifacts/{}/multipart/{}').format(
                            self.host, artifact_id, upload_id)
                    params = {'key': key, 'partNum': n}
                    etag = self.request(method='PUT',
                                        url=url_upload,
                                        params=params,
                                        data=piece)['etag']
                    parts.append({'etag': etag, 'partNumber': n})
                    progress.update(task_id, advance=len(piece))
                url_complete = ('{}/apis/v1/artifacts/{}/multipart/{}').format(
                    self.host, artifact_id, upload_id)
                params = {'key': key}
                self.request(method='POST',
                             url=url_complete,
                             params=params,
                             json_data={'parts': parts})

    def download_artifact_object(self, artifact_id: str, key: str, size: int,
                                 download_path: str) -> None:
        """Downloads an Artifact object from server."""
        url = '{}/apis/v1/artifacts/{}/objects'.format(self.host, artifact_id)
        params = {'key': key, 'apikey': self.api_key}

        _logger.debug('Request info:')
        _logger.debug('  URL: %s', url)
        _logger.debug('  method: GET')
        _logger.debug('  params: %s', params)

        progress = Progress(' ' * 10,
                            BarColumn(bar_width=None),
                            '[progress.percentage]{task.percentage:>3.1f}%',
                            '•',
                            DownloadColumn(),
                            '•',
                            TransferSpeedColumn(),
                            '•',
                            TimeRemainingColumn(),
                            console=Console(stderr=True))
        with progress:
            task_id = progress.add_task('download', start=False)
            progress.update(task_id, total=size)
            with requests.get(url=url,
                              params=params,
                              stream=True,
                              timeout=self.timeout,
                              allow_redirects=False) as r:
                r.raise_for_status()
                progress.start_task(task_id)
                with open(download_path, 'wb') as f:
                    for chunk in r.iter_content(chunk_size=16384):  # 16KB
                        f.write(chunk)
                        progress.update(task_id, advance=len(chunk))

    def get_artifact_data_by_id(self, artifact_id: str) -> Dict[str, Any]:
        """Gets Artifact data from server by ID.

        Args:
            artifact_id: ID of Artifact.

        Returns:
            Artifact data retrieved.

        Raises:
            requests.HTTPError: Artifact with artifact_id does not exist.
        """
        _logger.debug('Get Artifact data from server by ID %s', artifact_id)
        url = '{}/apis/v1/artifacts/{}'.format(self.host, artifact_id)
        return self.request(method='GET', url=url)

    def get_artifact_data_by_ref(
            self,
            folder_id: str,
            artifact_name: str,
            artifact_tag: str = 'latest') -> Dict[str, Any]:
        """Gets Artifact data from server by Ref.

        Args:
            folder_id: ID of folder that Artifact repo is in.
            artifact_name: Name of Artifact Repo.
            artifact_tag: Tag of Artifact.

        Returns:
            Artifact data retrieved.

        Raises:
            requests.HTTPError: Artifact with specified Ref does not exist.
        """
        _logger.debug(
            'Get Artifact data from server by name %s, tag %s and '
            'folder ID %s, ', folder_id, artifact_name, artifact_tag)
        url = '{}/apis/v1/artifacts'.format(self.host)
        params = {
            'folder': folder_id,
            'repo': artifact_name,
            'tag': artifact_tag,
        }
        return self.request(method='GET', url=url, params=params)

    def ls_artifact_object_by_id(self,
                                 artifact_id: str) -> List[Dict[str, Any]]:
        """Lists objects of Artifact from server by ID.

        Args:
            artifact_id: ID of Artifact.

        Returns:
            Object list of Artifact retrieved.

        Raises:
            requests.HTTPError: Artifact with artifact_id does not exist.
        """
        _logger.debug('Get object list of Artifact from server by ID %s',
                      artifact_id)
        url = '{}/apis/v1/artifacts/{}/objects/ls'.format(
            self.host, artifact_id)
        return self.request(method='GET', url=url)['results']

    def get_artifact_repo(self, scope: str = 'own') -> Dict[str, List[Any]]:
        """Gets all Artifact repos from server.

        Args:
            scope:
                The scope in which Artifact repos are listed. If "own", only
                Artifact repos owned by user are listed; if "shared", only
                Artifact repos shared by others are listed; "all" represents
                "own" and "shared".

        Returns:
            Data of Artifact repos retrieved.
        """
        _logger.debug('Get Artifact data from server')
        url = '{}/apis/v1/repos'.format(self.host)
        params = {'scope': scope}
        return self.request(method='GET', url=url, params=params)

    def append_input_output_artifact(self,
                                     trial_id: str,
                                     artifact_id: str,
                                     is_input: bool = True) -> None:
        """Posts an additional input/output Artifact of Trial to server.

        Args:
            trial_id: ID of Trial.
            artifact_id: ID of Artifact as input or output.
            is_input: If True, append as input Artifact, else as output.

        Raises:
            requests.HTTPError: Trial with trial_id does not exist.
        """

        _logger.debug('Append %s artifact %s of Trial %s to server',
                      'input' if is_input else 'output', artifact_id, trial_id)
        url = '{}/apis/v1/trials/{}'.format(self.host, trial_id)
        trial_data = self.request(method='GET', url=url)['doc']

        field = 'inputArtifacts' if is_input else 'outputArtifacts'
        if isinstance(trial_data[field], list):
            trial_data[field].append(artifact_id)
        else:
            trial_data[field] = [artifact_id]

        self.request(method='PUT', url=url, json_data=trial_data)

    def determine_folder_used(self,
                              folder_id: Optional[str] = None,
                              folder_path: Optional[str] = None,
                              make_folder: bool = False) -> Tuple[str, str]:
        """Determines the folder that will be used, return its ID and path.

        folder_id is used to identify folder in which the new Trial will be
        created. If invalid folder_id is provided, then new Trial will be
        created in folder with path `/default`.

        If no folder_id is provided, then folder_path will be used for querying
        folder_id. If invalid folder_path is provided and make_folder is set to
        True, then folder_path will be used and folder and parent folders will
        be made as needed; if make_folder is set to False, then new Trial will
        be created in folder with path `/default`.

        If folder_path is not provided either, then new Trial will also be
        created in folder with path `/default`.
        """
        _logger.debug('Get folder for Trial creation given id %s and path %s',
                      folder_id, folder_path)
        # use folder_id
        if folder_id is not None:
            try:
                folder_path = self.get_folder_path_by_id(folder_id)
            except requests.HTTPError as e:
                resp = e.response
                # invalid folder_id
                if resp.status_code == 500 and resp.text.startswith(
                        '[Get] doc not found'):
                    _logger.info(
                        'Folder with id %s does not exist, default folder %s'
                        ' is used', *cyan(folder_id, '/default'))
                    folder_path = '/default'
                    folder_id = self.make_folder_by_path(folder_path)
                else:
                    raise e
        # use folder_path
        elif folder_path is not None:
            try:
                folder_path = join('/', folder_path)
                folder_id = self.get_folder_id_by_path(folder_path)
            except requests.HTTPError as e:
                resp = e.response
                # invalid folder_path
                if resp.status_code == 500 and resp.text.endswith(
                        'not exists'):
                    # make folders as needed
                    _logger.debug('Folder with path `%s` does not exist',
                                  folder_path)
                    if make_folder:
                        folder_id = self.make_folder_by_path(folder_path)
                    else:
                        _logger.info(
                            'Folder with path %s does not exist, default folder'
                            ' %s is used', *cyan(folder_path, '/default'))
                        _logger.info(
                            '    If you want to make folders as needed, please'
                            ' set arg `make_folder=True`')
                        folder_path = '/default'
                        folder_id = self.make_folder_by_path(folder_path)
                else:
                    raise e
        # use default folder
        else:
            _logger.info(
                'Neither folder_id or folder_path is provided, default folder'
                ' %s is used', cyan('/default'))
            folder_path = '/default'
            folder_id = self.make_folder_by_path(folder_path)

        _logger.debug('Get folder id %s and path %s', folder_id, folder_path)
        return folder_id, folder_path

    def get_folder_id_by_path(self, folder_path: str) -> str:
        """Gets ID of folder with given path from server."""
        _logger.debug('Get folder id by path %s', folder_path)
        url = '{}/apis/v1/folders/id'.format(self.host)
        params = {'path': folder_path}
        id_ = self.request(method='GET', url=url, params=params)
        _logger.debug('Get folder id %s by path %s', id_, folder_path)
        return id_

    def get_folder_path_by_id(self, folder_id: str) -> str:
        """Gets path of folder with given id from server."""
        _logger.debug('Get folder path by id %s', folder_id)
        path = []
        while folder_id != 'root':
            url = '{}/apis/v1/folders/{}'.format(self.host, folder_id)
            params = {'id': folder_id}
            resp = self.request(method='GET', url=url, params=params)
            metadata = resp['doc']['metadata']
            path.append(metadata['name'])
            folder_id = metadata['folder']
        path.reverse()
        path = join('/', *path)
        _logger.debug('Get folder path %s by id %s', path, folder_id)
        return path

    def get_folder_data_by_id(self, folder_id: str) -> Dict[str, Any]:
        """Gets folder data from server by ID.

        Args:
            folder_id: ID of folder.

        Returns:
            Folder data retrieved.

        Raises:
            requests.HTTPError: Folder with folder_id does not exist.
        """
        _logger.debug('Get folder data from server by ID %s', folder_id)
        url = '{}/apis/v1/folders/{}'.format(self.host, folder_id)
        return self.request(method='GET', url=url)['doc']

    def make_folder_by_path(self, folder_path: str) -> str:
        """Makes folders by path in server if not exist."""
        _logger.debug('Make folder with path %s in server if not '
                      'exists', folder_path)
        parent_folder_id = None
        # folder_path like '/a/b'
        if dirname(folder_path) != '/':
            parent_folder_id = self.make_folder_by_path(dirname(folder_path))

        try:
            folder_id = self.get_folder_id_by_path(folder_path)
            _logger.debug(
                'Folder with path `%s` exists and is'
                ' NOT to be made', folder_path)
        except requests.HTTPError as e:
            resp = e.response
            if resp.status_code == 500 and resp.text.endswith('not exists'):
                _logger.debug(
                    'Folder with path `%s` does not exist'
                    ' and is to be made', folder_path)
                base_name = basename(folder_path)
                folder_data = {
                    'kind': 'Folder',
                    'metadata': {
                        'name': base_name
                    },
                    'type': 'normal'
                }
                if parent_folder_id:
                    folder_data['metadata']['folder'] = parent_folder_id

                url = '{}/apis/v1/folders'.format(self.host)
                folder_id = self.request(method='POST',
                                         url=url,
                                         json_data=folder_data)['id']
                _logger.debug('Folder with path `%s` is made', folder_path)
            else:
                raise e
        return folder_id

    def test_connection(self) -> None:
        """Tests connection to server.

        Raises:
            requests.HTTPError: Incorrect URL of server or invalid API key.
        """
        _logger.debug('Test connection to AIMD server with URL %s', self.host)
        url = '{}/apis/v1/folders'.format(self.host)
        try:
            resp = self.request(method='GET', url=url)
            # resp should be like {'folders': [...], 'pointers': [...]}
            assert 'folders' in resp
        except requests.ConnectionError as e:
            _logger.error('Unable to connect to AIMD server, please check '
                          'your network connection or status of server')
            raise e

        url = '{}/oauth2/userinfo'.format(self.host)
        params = {'apikey': self.api_key}
        username = self.request(method='GET', url=url,
                                params=params)['preferred_username']
        _logger.debug('Get username "%s"', username)
        _logger.info('Logged in to AIMD server %s as user %s',
                     magenta(self.host), magenta(username, bold=True))

    def request(self,
                method: str,
                url: str,
                params: Optional[Dict[str, Any]] = None,
                json_data: Optional[Any] = None,
                data: Optional[Any] = None,
                files: Optional[Dict[str, Any]] = None,
                headers: Optional[Dict[str, str]] = None) -> str:
        """Sends request to server.

        Args:
            method: Method of HTTP request.
            url: URL of HTTP request.
            params: Query parameters of HTTP request.
            data: Contents to be sent in the request body.
            headers: Headers of HTTP request.

        Returns:
            A dict parsed from JSON in content of the response, or a string of
            content of the response if the response body does not contain valid
            JSON.

        Raises:
            requests.HTTPError: An HTTP error occurred.
        """
        params = params if params else {}
        params['apikey'] = self.api_key
        headers = headers if headers else self.headers

        _logger.debug('Request info:')
        _logger.debug('  URL: %s', url)
        _logger.debug('  method: %s', method)
        _logger.debug('  params: %s', params)
        if json_data:
            _logger.debug('  json: %s', json_data)
        if data:
            _logger.debug('  data: %s', data)
        if files:
            _logger.debug('  file: %s', files)

        resp = requests.request(method=method,
                                url=url,
                                params=params,
                                json=json_data,
                                data=data,
                                files=files,
                                headers=headers,
                                timeout=self.timeout,
                                allow_redirects=False)
        if not resp.ok:
            http_error_msg = ''
            if resp.status_code == 302:
                _logger.error('API Key not provided')
                raise ValueError('API Key not provided')
            if 400 <= resp.status_code < 500:
                if resp.status_code == 400 and resp.text.startswith(
                        'api key') and resp.text.endswith('not found\n'):
                    raise RuntimeError('Invalid API Key')
                elif resp.status_code == 400 and resp.text.startswith(
                        'query is needed'):
                    _logger.error(
                        'Empty string provided for API Key, please provide '
                        'a valid API Key')
                    raise ValueError('Empty string provided for API Key')
                elif resp.status_code == 404 and not resp.text:
                    raise ValueError('Incorrect URL of AIMD server')
                else:
                    http_error_msg = '%s Client Error: %s for URL %s' % (
                        resp.status_code, resp.reason, resp.url)
                    if resp.text:
                        http_error_msg = http_error_msg + ': ' + resp.text
            elif 500 <= resp.status_code < 600:
                http_error_msg = '%s Server Error: %s for URL %s' % (
                    resp.status_code, resp.reason, resp.url)
                if resp.text:
                    http_error_msg = http_error_msg + ': ' + resp.text
            if http_error_msg:
                raise requests.HTTPError(http_error_msg, response=resp)
        _logger.debug('Request succeeded')

        try:
            return resp.json()
        except simplejson.JSONDecodeError:
            return resp.text


CLIENT = _AIMDClient()


def login(host: Optional[str] = None,
          api_key: Optional[str] = None,
          timeout: Optional[int] = None,
          unable_to_connect_ok: bool = False) -> None:
    """Logs in to AIMD server.

    Sets up the client that corresponds with AIMD server.

    Args:
        host:
            URL of server. Defaults to server URL given by SDK config file if
            one is set.
        api_key:
            API Key for requesting server. Defaults to API Key given by
            SDK config file if one is set.
        timeout:
            How many seconds to wait for server to send data before giving up.
        unable_to_connect_ok:
            If False and client is unable to connect to server, raise
            ConnectionError; if True and unable to connect, this setting up is
            invalid.

    Raises:
        requests.HTTPError:
            Unable to connect to server and `unable_to_connect_ok` is False.
    """
    if host:
        CLIENT.host = host
    elif CONFIG['aimd_host']:
        CLIENT.host = CONFIG['aimd_host']
        host = CONFIG['aimd_host']
    else:
        _logger.error('Host not provided by either argument or config')
        raise ValueError('Host not provided')

    if api_key:
        CLIENT.api_key = api_key
    elif CONFIG['api_key']:
        CLIENT.api_key = CONFIG['api_key']
        api_key = CONFIG['api_key']
    else:
        _logger.error('API Key not provided by either argument or config')
        raise ValueError('API Key not provided')

    check_url(CLIENT.host)
    if not is_uuid(CLIENT.api_key):
        _logger.error('Invalid API Key format: %s', red(CLIENT.api_key))
        raise ValueError('Invalid API Key format: {}'.format(CLIENT.api_key))

    if CLIENT.host.endswith('/'):
        CLIENT.host = CLIENT.host[:-1]
    _logger.debug('Log in to host %s with API Key %s', host, api_key)

    CLIENT.timeout = timeout

    try:
        CLIENT.test_connection()
    except requests.ConnectionError as e:
        if unable_to_connect_ok:
            _logger.info('Unable to connect to AIMD server: %s', magenta(host))
            return
        else:
            _logger.error('Unable to connect to AIMD server: %s', red(host))
            raise e
    except ValueError as e:
        if e.args[0] == 'Invalid API Key':
            _logger.error('Invalid API Key: %s, please check the API Key',
                          red(api_key))
            raise ValueError('Invalid API Key: {}'.format(api_key)) from e
        elif e.args[0] == 'Incorrect URL of AIMD server':
            _logger.error(
                'Incorrect URL of AIMD server: %s, please '
                'check the URL', red(host))
            raise ValueError(
                'Incorrect URL of AIMD server: {}'.format(host)) from e
        else:
            raise e

    CLIENT.online = True


def logout() -> None:
    """Logs out from the current AIMD server.

    The client is unset, it can no longer correspond with AIMD server until
    it is set up again.
    """
    if CLIENT.online:
        _logger.info('Logged out from AIMD server %s', magenta(CLIENT.host))
        CLIENT.online = False
    else:
        _logger.warning(
            'Not log out, for having not logged in to any AIMD server')


class _UploadQueue(collections.deque):
    pass


# TODO: Create a new process to be in charge of correspondence with server.
# TODO: Implement a queue class for sending requests.

# for test
if __name__ == '__main__':
    pass
