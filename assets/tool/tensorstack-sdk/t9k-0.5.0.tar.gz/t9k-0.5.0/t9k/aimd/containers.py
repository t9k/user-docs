"""Container classes of AIMD."""

import collections.abc
import json
import logging
import pprint
from typing import Any, Callable, Dict, List, Tuple, Union

from t9k.utils.module_utils import get_module

_logger = logging.getLogger(__name__)

JSONValue = Union[str, int, float, bool, type(None), List, Tuple, Dict]

Metric = Dict[str, Dict[str, Union[str, int, float]]]
Metrics = Dict[str, List[Metric]]


class Params(collections.abc.MutableMapping):
    """Container class to hold hyperparameters of Trial.

    It is recommended to set all hyperparameters by calling `update` method once
    before building the model. Nevertheless, you are free to operate
    hyperparameters like items of a dict or attributes of an object.

    Examples:

        Recommended method of setting hyperparameters:
        ```
        trial.update({
            'batch_size': 32,
            'epochs': 10,
        })
        ```

        Assign parameter like an item of dict or attribute of object:
        ```
        trial.params['batch_size'] = 32
        trial.params.epochs = 10
        ```

    Args:
        upload:
            Function that is called to upload hyperparameters every time
            hyperparameters are updated.
        init_params:
            Initial hyperparameters.
    """
    def __init__(self,
                 upload: Callable,
                 init_params: Dict[str, JSONValue] = None):
        if isinstance(init_params, dict):
            self._check_json_serializable(init_params)
            object.__setattr__(self, '_items', init_params)
        else:
            object.__setattr__(self, '_items', {})
        object.__setattr__(self, '_upload', upload)

    def __getitem__(self, key: str):
        return self._items[key]

    def __setitem__(self, key: str, value: JSONValue):
        self._check_json_serializable(value)

        if key in self._items:
            _logger.debug('Parameter modified: %s = %s', key, value)
        else:
            _logger.debug('Parameter set: %s = %s', key, value)
        self._items[key] = value
        self._upload()

    def __delitem__(self, key: str):
        del self._items[key]
        _logger.debug('Parameter deleted: %s', key)
        self._upload()

    def __iter__(self):
        return self._items.__iter__()

    def __len__(self):
        return self._items.__len__()

    def __contains__(self, key: str):
        return key in self._items

    def keys(self):
        return self._items.keys()

    def values(self):
        return self._items.values()

    def items(self):
        return self._items.items()

    def as_dict(self):
        return self._items

    def __repr__(self):
        return 'Params({})'.format(str(dict(self)))

    def __str__(self):
        return pprint.pformat(dict(self))

    def update(self, new_params: Dict[str, Any], override: bool = True):
        """Updates with new params.

        Args:
            new_params: New params to be updated with.
            override: Whether to override current params.
        """
        _logger.debug('Update parameters with dict %s', new_params)
        if override:
            for k, v in new_params.items():
                if k in self._items:
                    _logger.debug('Parameter reset: %s = %s', k, repr(v))
                else:
                    _logger.debug('Parameter set: %s = %s', k, repr(v))
                self.__setitem__(k, v)
        else:
            for k, v in new_params.items():
                if k in self._items:
                    _logger.debug('Parameter NOT set: %s = %s', k, repr(v))
                else:
                    _logger.debug('Parameter set: %s = %s', k, repr(v))
                    self.__setitem__(k, v)
        self._upload()
        _logger.debug('Update complete')

    def parse(self,
              dist_tf_strategy=None,
              dist_torch_model=None,
              dist_hvd=None):
        """Parses hyperparameters from various objects of various frameworks.

        Args:
            dist_tf_strategy:
                TensorFlow distribution strategy instance if `tf.distribute` is
                used for distributed training.
            dist_torch_model:
                PyTorch model wrapped with DP or DDP if `torch.distributed` is
                used for distributed training.
            dist_hvd:
                Used module such as `horovod.keras` and `horovod.torch` if
                Horovod is used for distributed training.
        """
        distribute = {}
        # Use `tf.distribute` for distributed training
        if dist_tf_strategy is not None:
            try:
                distribute['api'] = 'tf.distribute'
                policy = type(dist_tf_strategy).__name__
                if policy == 'CollectiveAllReduceStrategy':
                    policy = policy + ' (MultiWorkerMirroredStrategy)'
                distribute['policy'] = policy
                if dist_tf_strategy.cluster_resolver is not None:
                    config = {
                        k: len(v)
                        for k, v in dist_tf_strategy.cluster_resolver.
                        cluster_spec().as_dict().items()
                    }
                    distribute['config'] = config
            except Exception as e:
                # TODO: handle exception
                raise e
        # Use `torch.distributed` for distributed training
        elif dist_torch_model is not None:
            try:
                distribute['api'] = 'torch.distributed'
                policy = type(dist_torch_model).__name__
                distribute['policy'] = policy
                distribute['config'] = {}
                worker = dist_torch_model.process_group.size()
                distribute['config']['worker'] = worker
                dist = get_module(name='torch.distributed')
                if dist:
                    backend = dist.get_backend(dist_torch_model.process_group)
                    distribute['config']['backend'] = backend
            except Exception as e:
                # TODO: handle exception
                raise e
        # Use `horovod.*` for distributed training
        elif dist_hvd is not None:
            try:
                distribute['api'] = dist_hvd.__name__
                distribute['config'] = {}
                worker = dist_hvd.size()
                distribute['config']['worker'] = worker
            except Exception as e:
                # TODO: handle exception
                raise e

        self.update(distribute)

    def _check_json_serializable(self, object_: Any):
        """Checks that the object is JSON serializable."""
        try:
            json.dumps(object_)
        except TypeError as e:
            object_of_type = e.args[0][:-25]
            raise TypeError(
                '{} is not accepted as value of hyperparameters of Trial'.
                format(object_of_type)) from e
