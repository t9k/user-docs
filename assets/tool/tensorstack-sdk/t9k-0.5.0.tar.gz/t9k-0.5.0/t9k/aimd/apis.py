"""Main APIs."""

import logging
import os
from typing import Any, Dict, Optional, Sequence, Union

from t9k.aimd.client import CLIENT
from t9k.aimd.trial import Trial, _new_trial, _get_trial_path_by_name
from t9k.aimd.artifact import (ARTIFACT_PATH, Artifact, _new_artifact,
                               _get_artifact_path_by_id)
from t9k.utils.file_utils import (abspath, dirname, isfile, isdir, join,
                                  read_yaml_file)
from t9k.utils.print_utils import black, blue, cyan, red
from t9k.utils.random_utils import is_random_name
from t9k.utils.uuid_utils import is_uuid

_logger = logging.getLogger(__name__)


def create_trial(trial_path: Optional[str] = None,
                 trial_name: Optional[str] = None,
                 trial_params: Optional[dict] = None,
                 folder_id: Optional[str] = None,
                 folder_path: Optional[str] = None,
                 make_folder: Optional[bool] = None,
                 conflict_strategy: Optional[str] = None) -> Trial:
    """Creates and initializes a new Trial.

    Examples:
        Basic usage:
        ```
        from t9k import aimd

        trial = aimd.create_trial(trial_name='cnn_keras',
                                  folder_path='image_classification/mnist')
        ```

        Provide initial parameters of Trial:
        ```
        params = {
            'batch_size': 32,
            'epochs': 1,
            'learning_rate': 0.001,
            'conv_channels1': 32,
            'conv_channels2': 64,
            'conv_channels3': 64,
            'conv_kernel_size': 3,
            'maxpool_size': 2,
            'linear_features1': 64,
        }

        trial = aimd.create_trial(trial_name='cnn_keras',
                                  trial_params=params,
                                  folder_path='image_classification/mnist')
        ```

        Provide Trial config file:
        ```
        trial = aimd.create_trial(trial_path='./trial.yaml')
        ```
        where the config file `trial.yaml` is like:
        ```
        trial_name: cnn_keras
        folder_path: image_classification/mnist
        trial_params:
          batch_size: 32
          epochs: 1
          learning_rate: 0.001
          conv_channels1: 32
          conv_channels2: 64
          conv_channels3: 64
          conv_kernel_size: 3
          maxpool_size: 2
          linear_features1: 64
        ```

    Args:
        trial_path:
            Local path of the Trial to load. If this arg is provided, all of
            the following args will be loaded from config file if they are
            not provided.
        trial_name:
            Name of the Trial.
        trial_params:
            Initial hyperparameters of the Trial.
        folder_id:
            ID of folder to which the Trial will be uploaded.
        folder_path:
            Path of the folder to which the Trial will be uploaded. If
            `folder_id` is provided, `folder_path` will not be used; if neither
            `folder_id` or `folder_path` is provided, the Trial will be
            uploaded to folder with path `/default`.
        make_folder:
            If True and folder with `folder_path` does not exist, make the
            folder and parent folders as needed. Default to False if
            `trial_path` is not provided.
        conflict_strategy:
            Strategy adopted when a Trial with the same name as the Trial
            to be uploaded already exists in the folder, must be `'skip'`,
            `'error'`, `'new'` or `'replace'`. If `'skip'`, skip the upload;
            if `'error'`, error out; if `'new'`, upload with the local name of
            Trial; if `'replace'`, delete the existing Trial and upload.
            Default to 'new' if `trial_path` is not provided.

    Returns:
        A Trial instance created and initialized.
    """
    # TODO: resume a trial
    if trial_path:
        args = locals()

        _logger.info('Loading data under %s to create Trial', cyan(trial_path))

        metadata_file_path = join(trial_path, 'metadata.yaml')
        parameter_file_path = join(trial_path, 'parameters.yaml')

        if not (isfile(metadata_file_path) and isfile(parameter_file_path)):
            _logger.error(
                'Failed to load Trial in path: %s, the directory must contain '
                'file `metadata.yaml`, `parameters.yaml` and `metrics.yaml`',
                red(trial_path))
            raise RuntimeError(
                'Failed to load Trial in path: {}, the directory must contain '
                'file `metadata.yaml`, `parameters.yaml` and `metrics.yaml`'.
                format(trial_path))

        def load_data_file(file_path: str) -> Dict[str, Any]:
            msg = ('Invalid data file of Trial: {}, please read the '
                   'exception message and check the file').format(
                       red(file_path))
            return read_yaml_file(file_path, error_msg=msg)

        trial_data = load_data_file(metadata_file_path)
        parameters = load_data_file(parameter_file_path)

        trial_configs = {
            'trial_name': trial_data['metadata']['name'],
            'trial_params': parameters,
        }
        trial_configs.update(trial_data['_upload'])

        for arg in [
                'trial_name', 'trial_params', 'folder_id', 'folder_path',
                'make_folder', 'conflict_strategy'
        ]:
            trial_configs[arg] = args[arg]

        return create_trial(**trial_configs)

    if folder_id and not is_uuid(folder_id):
        _logger.error('Invalid Folder ID format: %s', red(folder_id))
        raise ValueError('Invalid Folder ID format: {}'.format(folder_id))
    if make_folder is None:
        make_folder = False
    if conflict_strategy is None:
        conflict_strategy = 'new'

    if not trial_name:
        _logger.error('Name of Trial not provided')
        raise RuntimeError('Name of Trial not provided')

    trial = _new_trial(name=trial_name,
                       params=trial_params,
                       folder_id=folder_id,
                       folder_path=folder_path,
                       make_folder=make_folder,
                       conflict_strategy=conflict_strategy)

    return trial


def load_trial(trial_path: Optional[str] = None,
               trial_name: Optional[str] = None) -> Trial:
    """Loads a Trial from local by its name or path.

    Priorities of the arguments: `trial_path` > `trial_name`.

    If `trial_path` is provided, load from this local path.

    If `trial_name` is provided, this function will search `TRIAL_PATH` for
    every sub-directory whose name matches `trial_name`. If 1 matches, load
    this Trial; if 0 or 2 or more match, raise a RuntimeError.

    It is recommended to pass in the path or the alternative name of Trial
    to avoid ambiguity.

    Examples:
        Load by path:
        ```
        aimd.load_trial(trial_path=
            '.aimd/trials/mnist_keras_220823_194728_4e48t2')
        ```

        Load by alternative name:
        ```
        aimd.load_trial(trial_name='mnist_keras_220823_194728_4e48t2')
        ```

        Load by name:
        ```
        aimd.load_trial(trial_name='mnist_keras')  # might match multiple
        ```

    Args:
        trial_path:
            Local path of the Trial to load from.
        trial_name:
            Name of the Trial to load by.

    Returns:
        A Trial instance loaded from local.
    """
    if trial_path:
        return Trial._load_from_local(trial_path)
    elif trial_name:
        return Trial._load_from_local(_get_trial_path_by_name(trial_name))
    else:
        _logger.error('Either `trial_name` or `trial_path` must be provided')
        raise RuntimeError(
            'Either `trial_name` or `trial_path` must be provided')


def upload_trial(trial_path: Union[str, Sequence[str], None] = None,
                 trial_dir: Optional[str] = None,
                 trial_name: Union[str, Sequence[str], None] = None,
                 folder_id: Optional[str] = None,
                 folder_path: Optional[str] = None,
                 make_folder: bool = False,
                 conflict_strategy: Optional[str] = None) -> None:
    """Uploads one or multiple Trials that are saved locally.

    For parameters `folder_id`, `folder_path` and `make_folder`, the values
    of the arguments passed in take precedence over values parsed from
    `_upload` field in Trial data file.

    Examples:
        Upload one Trial by its path:
        ```
        aimd.upload_trial(trial_path=
            '.aimd/trials/mnist_keras_220823_194728_4e48t2')
        # or
        aimd.upload_trial(trial_path=
            '/path/to/workspace/.aimd/trials/mnist_keras_220823_194728_4e48t2')
        ```

        Upload all Trials under a directory:
        ```
        aimd.upload_trial(trial_dir='.aimd/trials')
        ```

        Upload one Trial by its alternative name:
        ```
        aimd.upload_trial(trial_name='mnist_keras_220823_194728_4e48t2')
        ```

        Upload multiple Trials by their alternative names:
        ```
        aimd.upload_trial(trial_name=['mnist_keras_220823_194728_4e48t2',
                                      'mnist_torch_220823_195814_vjo18w'])
        ```

        Provide arguments that are not provided in Trial metadata file:
        ```
        aimd.upload_trial(trial_name='mnist_keras_220823_194728_4e48t2',
                          folder_path='image_classification/mnist')
        ```

    Args:
        trial_path:
            Local path of the Trial to be uploaded, can be a path of one Trial
            or a sequence of paths of multiple Trials.
        trial_dir:
            Local path of the directory that contains one or multiple Trials.
        trial_name:
            Name of the Trial to be uploaded, can be a name of one Trial or
            a sequence of names of multiple Trials. `trial_name` can be name or
            alternative name of Trial, this function will search `TRIAL_PATH`
            for sub-directory whose name matches `trial_name`.
        folder_id:
            ID of the folder to which the Trial is uploaded.
        folder_path:
            Path of the folder to which the Trial is uploaded. If `folder_id`
            is provided, `folder_path` will not be used; if neither `folder_id`
            or `folder_path` is provided, the Trial will be uploaded to folder
            with path `/default`.
        make_folder:
            If True and folder with `folder_path` does not exist, make the
            folder and parent folders as needed.
        conflict_strategy:
            Strategy adopted when a Trial with the same name as the Trial
            to be uploaded already exists in the folder, must be `'skip'`,
            `'error'`, `'new'` or `'replace'`. If `'skip'`, skip the upload;
            if `'error'`, error out; if `'new'`, upload with the local name of
            Trial; if `'replace'`, delete the existing Trial and upload.
    """
    upload_list = []

    if folder_id and not is_uuid(folder_id):
        _logger.error('Invalid Folder ID format: %s', red(folder_id))
        raise ValueError('Invalid Folder ID format: {}'.format(folder_id))

    if trial_path:
        if isinstance(trial_path, str):
            upload_list.append(trial_path)
        elif isinstance(trial_path, Sequence):
            for p in trial_path:
                assert isinstance(p, str)
                upload_list.append(p)
        else:
            _logger.error(
                'str or list instance expected but %s instance received '
                'for arg trial_path',
                type(trial_path).__name__)
            raise TypeError('Invalid type for trial_path')

    if trial_dir:
        for entry in os.listdir(trial_dir):
            if is_random_name(entry) and isdir(join(trial_dir, entry)):
                upload_list.append(join(trial_dir, entry))

    if trial_name:
        if isinstance(trial_name, str):
            upload_list.append(_get_trial_path_by_name(trial_name))
        elif isinstance(trial_name, Sequence):
            for t in trial_name:
                assert isinstance(t, str)
                upload_list.append(_get_trial_path_by_name(t))
        else:
            _logger.error(
                'str or list instance expected but %s instance received '
                'for arg trial_name',
                type(trial_name).__name__)
            raise TypeError('Invalid type for trial_name')

    if len(upload_list) > 1:
        _logger.info('%s Trials are to be uploaded')
    elif len(upload_list) == 1:
        _logger.info('1 Trial is to be uploaded')
    else:
        _logger.error('No Trial is to be uploaded')
        raise RuntimeError('No Trial is to be uploaded')

    for p in upload_list:
        _upload_trial(trial_path=p,
                      folder_id=folder_id,
                      folder_path=folder_path,
                      make_folder=make_folder,
                      conflict_strategy=conflict_strategy)


def _upload_trial(trial_path: str, folder_id: Optional[str],
                  folder_path: Optional[str], make_folder: bool,
                  conflict_strategy: Optional[str]) -> None:
    """Implements uploading one Trial that are saved locally."""
    _logger.info('Uploading the Trial at %s', black(trial_path,
                                                    underline=True))
    trial = Trial._load_from_local(trial_path=trial_path)
    trial.upload(folder_id, folder_path, make_folder, conflict_strategy)


def create_artifact(
        artifact_name: str,
        artifact_type: str,
        description: str = '',
        aliases: Union[str, Sequence[str], None] = None) -> Artifact:
    """Creates and initializes a new artifact.

    Examples:

        ```
        dateset_artifact = aimd.create_artifact(artifact_name='mnist',
                                                artifact_type='dataset')
        ```

    Args:
        artifact_name:
            Name of the Artifact.
        artifact_type:
            Type of the Artifact.
        description:
            Description of the Artifact.
        aliases:
            Aliase(s) of the Artifact. Can be a string or sequence of string or
            `None`.

    Returns:
        An Artifact instance created and initialized.
    """
    if not aliases:
        aliases = None
    elif isinstance(aliases, str):
        aliases = [aliases]
    elif isinstance(aliases, Sequence):
        for a in aliases:
            assert isinstance(a, str)
        aliases = list(aliases)
    else:
        _logger.error(
            'Invalid aliases: %s, must be string or sequence of '
            'string', red(aliases))
        raise ValueError('Invalid aliases: {}'.format(aliases))

    artifact = _new_artifact(name=artifact_name,
                             type_=artifact_type,
                             description=description,
                             aliases=aliases)

    return artifact


def grab_artifact(artifact_path: Optional[str] = None,
                  artifact_id: Optional[str] = None,
                  artifact_ref: Optional[str] = None) -> Artifact:
    """Grabs an Artifact from local path or server.

    Priorities of the arguments: artifact_path > artifact_id > artifact_ref.

    If `artifact_path` is provided, load from this local path.

    If `artifact_id` is provided, this function will search `ARTIFACT_PATH` for
    sub-directory whose name matches `artifact_id`. If 1 match, load this
    Artifact; if no match and CLIENT is online, try to load the Artifact with
    this ID from server; else raise a RuntimeError.

    If `artifact_ref` is provided, this function will send a request to server
    for ID of Artifact corresponding to the reference. The value of
    `artifact_ref` can be in one of the following forms:

    * `<folder-id>/<repo-name>[:<tag>]`
    * `<folder-path>/<repo-name>[:<tag>]`
    * `<repo-id>[:<tag>]`

    If `:<tag>` is not provided, default tag `:latest` will be used.

    Examples:

        ```
        dateset_artifact = aimd.grab_artifact(
            artifact_id='5766682a-6528-4bff-8aae-7d80f3ff76f6')
        dateset_artifact.download()
        trial.mark_input(dateset_artifact)
        ```

    Args:
        artifact_path: Local path of the Artifact.
        artifact_id: ID of the Artifact.
        artifact_ref: Reference of the Artifact.

    Returns:
        An Artifact instance grabbed from local path or server.
    """
    if artifact_path:
        return Artifact._load_from_local(artifact_path)
    elif artifact_id:
        if not is_uuid(artifact_id):
            _logger.error('Invalid Artifact ID format: %s', red(artifact_id))
            raise ValueError(
                'Invalid Artifact ID format: {}'.format(artifact_id))
        use_id = True
    elif artifact_ref:
        # TODO: support <repo_id>:<tag>
        use_id = False
        if not CLIENT.online:
            _logger.error('Must log in to get an Artifact by its reference')
            raise RuntimeError(
                'Must log in to get an Artifact by its reference')
        if ':' in artifact_ref:
            artifact_path, tag = artifact_ref.rsplit(sep=':', maxsplit=1)
        else:
            tag = 'latest'

        folder, repo_name = artifact_path.rsplit(sep='/', maxsplit=1)
        if is_uuid(folder):
            folder_id = folder
        else:
            folder_id = CLIENT.get_folder_id_by_path(folder)
        artifact_id = CLIENT.get_artifact_data_by_ref(
            folder_id=folder_id, artifact_name=repo_name,
            artifact_tag=tag)['metadata']['id']
    else:
        raise RuntimeError('No argument is provided')

    artifact_path = _get_artifact_path_by_id(artifact_id)
    if artifact_path:
        return Artifact._load_from_local(artifact_path)

    if CLIENT.online:
        try:
            return Artifact._load_from_server(artifact_id)
        except RuntimeError:
            if use_id:
                artifact_info = 'ID {}'.format(red(artifact_id))
            else:
                artifact_info = 'reference {} (ID {})'.format(
                    *red(artifact_ref, artifact_id))
            _logger.error(
                'Artifact with %s does not exist in local or server,'
                ' please check the ID', artifact_info)

    else:
        _logger.error(
            'Artifact with ID %s does not exist in local,'
            ' please check the ID', red(artifact_id))
    raise RuntimeError(
        'Artifact with ID {} does not exist'.format(artifact_id))


def upload_artifact(artifact_path: Union[str, Sequence[str], None] = None,
                    artifact_id: Union[str, Sequence[str], None] = None,
                    repo_path: Optional[str] = None,
                    repo_name: Optional[str] = None,
                    folder_id: Optional[str] = None,
                    folder_path: Optional[str] = None,
                    make_folder: bool = False) -> None:
    """Uploads one or multiple Artifacts that are saved locally.

    Examples:
        Upload one Artifact by its path:
        ```
        aimd.upload_artifact(artifact_path='.aimd/artifacts/mnist_keras_model/'
                    '18c77b08-d3f4-4a88-a0e3-9f578c7f6750')
        # or
        aimd.upload_artifact(artifact_path='/path/to/workspace/.aimd/artifacts'
                    '/mnist_keras_model/18c77b08-d3f4-4a88-a0e3-9f578c7f6750')
        ```

        Upload one Artifact by its ID:
        ```
        aimd.upload_artifact(artifact_id='18c77b08-d3f4-4a88-a0e3-9f578c7f6750')
        ```

        Upload multiple Artifacts by their IDs:
        ```
        aimd.upload_artifact(artifact_id=['18c77b08-d3f4-4a88-a0e3-9f578c7f6750',
                                '6feee8d9-03bf-49bb-9812-b47d3cce4e05'])
        ```

        Upload all Artifacts in a repo:
        ```
        aimd.upload_artifact(repo_path='.aimd/artifacts/mnist_keras_model/')
        # or
        aimd.upload_artifact(repo_name='mnist_keras_model')
        ```

    Args:
        artifact_path:
            Local path of the Artifact to be uploaded, can be a path of one
            Artifact or a list of paths of multiple Artifacts.
        artifact_id:
            ID of the Artifact to be uploaded, can be an ID of one Artifact or
            a list of IDs of multiple Artifacts. This function will search
            `ARTIFACT_PATH` for sub-directory whose name matches `artifact_id`.
        repo_path:
            Local path of the Artifact repo in which all Artifacts are to be
            uploaded.
        repo_name:
            Name of the Artifact repo in which all Artifacts are to be
            uploaded. This function will search `ARTIFACT_PATH` for
            sub-directory whose name matches `repo_name`.
        folder_id:
            ID of the folder to which the Artifact is uploaded.
        folder_path:
            Path of the folder to which the Artifact is uploaded. If
            `folder_id` is provided, `folder_path` will not be used; if neither
            `folder_id` or `folder_path` is provided, the Artifact will be
            uploaded to folder with path `/default`.
        make_folder:
            If True and folder with `folder_path` does not exist, make the
            folder and parent folders as needed.
    """
    upload_list = []

    if folder_id and not is_uuid(folder_id):
        _logger.error('Invalid Folder ID format: %s', red(folder_id))
        raise ValueError('Invalid Folder ID format: {}'.format(folder_id))

    if artifact_path:
        if isinstance(artifact_path, str):
            upload_list.append(artifact_path)
        elif isinstance(artifact_path, list):
            for p in artifact_path:
                assert isinstance(p, str)
                upload_list.append(p)
        else:
            _logger.error(
                'str or list instance expected but %s instance received '
                'for arg artifact_path',
                type(artifact_path).__name__)
            raise TypeError('Invalid type for arg artifact_path')

    if artifact_id:
        if isinstance(artifact_id, str):
            upload_list.append(_get_artifact_path_by_id(artifact_id))
        elif isinstance(artifact_id, list):
            for i in artifact_id:
                assert isinstance(i, str)
                upload_list.append(_get_artifact_path_by_id(i))
        else:
            _logger.error(
                'str or list instance expected but %s instance received '
                'for arg artifact_id',
                type(artifact_id).__name__)
            raise TypeError('Invalid type for arg artifact_id')

    if repo_path:
        for entry in os.listdir(repo_path):
            if is_uuid(entry) and isdir(join(repo_path, entry)):
                upload_list.append(join(repo_path, entry))

    if repo_name:
        repo_path_ = join(ARTIFACT_PATH, repo_name)
        for entry in os.listdir(repo_path_):
            if is_uuid(entry) and isdir(join(repo_path_, entry)):
                upload_list.append(join(repo_path_, entry))

    if len(upload_list) > 1:
        _logger.info('%s Artifacts are to be uploaded')
    elif len(upload_list) == 1:
        _logger.info('1 Artifact is to be uploaded')
    else:
        _logger.error('No Artifact is to be uploaded')
        raise RuntimeError('No Artifact is to be uploaded')

    for path_ in upload_list:
        _upload_artifact(path_=path_,
                         folder_id=folder_id,
                         folder_path=folder_path,
                         make_folder=make_folder)


def _upload_artifact(path_: str, folder_id: Optional[str],
                     folder_path: Optional[str], make_folder: bool) -> None:
    """Implements uploading one Artifact that are saved locally."""
    path_ = abspath(path_)
    _logger.info('Uploading the Artifact at %s', blue(path_, underline=True))
    artifact = Artifact._load_from_local(artifact_path=path_)

    artifact._upload_info = {
        'folder_id': folder_id,
        'folder_path': folder_path,
        'make_folder': make_folder,
    }
    artifact_data = artifact._upload()

    artifact_addr = '{}/web/#/folders/{}/?artifactVersion={}'.format(
        dirname(CLIENT.host), artifact_data['metadata']['folder'],
        artifact_data['version'])
    _logger.info('Artifact uploaded, view its data by visiting %s',
                 blue(artifact_addr, underline=True))
