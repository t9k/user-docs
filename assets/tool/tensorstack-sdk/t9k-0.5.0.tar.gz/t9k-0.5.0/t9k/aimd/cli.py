"""Implementation of CLI."""

from datetime import datetime
from glob import glob
import os
import sys
from typing import Any, Dict, Optional, Tuple

import click
import tabulate
import yaml

import t9k
from t9k import CONFIG
from t9k.aimd.apis import upload_trial, upload_artifact
from t9k.aimd.artifact import ARTIFACT_PATH, _get_artifact_path_by_id
from t9k.aimd.client import login
from t9k.aimd.trial import TRIAL_PATH, _get_trial_path_by_name
from t9k.utils.datetime_utils import get_local_now_iso, format_timedelta
from t9k.utils.decorators import no_raise
from t9k.utils.file_utils import (join, isfile, isdir, basename, dirname,
                                  human_readable_size, read_yaml_file)
from t9k.utils.print_utils import red
from t9k.utils.random_utils import is_random_name
from t9k.utils.uuid_utils import is_uuid

CONTEXT_SETTINGS = dict(help_option_names=['-h', '--help'])

tabulate.PRESERVE_WHITESPACE = True


@click.group(context_settings=CONTEXT_SETTINGS)
@click.option('-v', '--verbose', is_flag=True)
@click.version_option(t9k.__version__)
@click.pass_context
def cli(ctx, verbose):
    del ctx, verbose  # Unused
    pass


@click.option('-H',
              '--host',
              type=str,
              metavar='SERVER_URL',
              help='URL of AIMD server.')
@click.option('-k',
              '--api-key',
              type=str,
              metavar='API_KEY',
              help='API Key for requesting AIMD server.')
@cli.command('login', context_settings=CONTEXT_SETTINGS)
@no_raise
def cli_login(host: Optional[str], api_key: Optional[str]):
    """Try to log in to AIMD server and update SDK config file.

    If any of the arguments is not provided, the value of config item with
    the same name in SDK config file will be used.
    """
    if host:
        CONFIG['aimd_host'] = host
    if api_key:
        CONFIG['api_key'] = api_key
    login()
    CONFIG.save()


@click.option('-H',
              '--host',
              is_flag=True,
              default=False,
              help='Remove host value.')
@cli.command('logout', context_settings=CONTEXT_SETTINGS)
def cli_logout(host: bool):
    """Remove API Key and optionally host in SDK config file."""
    CONFIG['api_key'] = ''
    if host:
        CONFIG['aimd_host'] = ''
    CONFIG.save()
    if host:
        click.echo('Removed host and API Key')
    else:
        if CONFIG['aimd_host']:
            click.echo('Removed API Key for host {}'.format(
                CONFIG['aimd_host']))
        else:
            click.echo('Removed API Key')


@click.group(context_settings=CONTEXT_SETTINGS)
def trial():
    """Manage Trials."""
    pass


@click.argument('trial_path', type=click.Path(exists=True), required=False)
@click.option('-d',
              '--detail',
              is_flag=True,
              default=False,
              help='Show detailed information about Trial.')
@trial.command('ls', context_settings=CONTEXT_SETTINGS)
def list_trial(trial_path: Optional[str], detail: bool):
    """List local Trials.

    If TRIAL_PATH is not provided, it defaults to ".".
    """
    if not trial_path:
        trial_path = TRIAL_PATH
    if trial_path.endswith('/'):
        trial_path = trial_path[:-1]
    if not trial_path.endswith(TRIAL_PATH):
        trial_path = join(trial_path, TRIAL_PATH)

    trial_paths = glob('{}/*_*_*_*'.format(trial_path))

    if detail:
        headers = [
            'NAME', 'ALTERNATIVE_NAME', 'ID', 'STATUS', 'STARTED', 'DURATION',
            'EDITOR'
        ]
    else:
        headers = ['NAME', 'STATUS', 'STARTED', 'DURATION']
    table = []
    for p in trial_paths:
        metadata_file_path = join(p, 'metadata.yaml')
        if not isfile(metadata_file_path):
            eprint('Metadata file of Trial does not exist: {}'.format(
                metadata_file_path))

        try:
            trial_data = read_yaml_file(metadata_file_path)
        except yaml.scanner.ScannerError:
            eprint('Invalid YAML document: {}'.format(metadata_file_path))

        name = trial_data['metadata']['name']
        status = trial_data['status']
        started = format_timedelta(
            datetime.fromisoformat(get_local_now_iso()) -
            datetime.fromisoformat(trial_data['startTime']),
            brief=True) + ' ago'
        if status == 'Succeeded':
            duration = format_timedelta(
                datetime.fromisoformat(trial_data['endTime']) -
                datetime.fromisoformat(trial_data['startTime']))
        else:
            duration = ''

        if detail:
            alternative_name = basename(p)
            id_ = trial_data['metadata']['id']
            editor = trial_data['metadata']['editor']
            table.append([
                name, alternative_name, id_, status, started, duration, editor
            ])
        else:
            table.append([name, status, started, duration])

    click.echo(tabulate.tabulate(table, headers, tablefmt='plain'))


@click.option('-p',
              '--path',
              'trial_path',
              type=str,
              metavar='TRIAL_PATH',
              multiple=True,
              help='Local path of the Trial.')
@click.option('-d',
              '--dir',
              'trial_dir',
              type=str,
              metavar='TRIAL_DIR',
              help='Local path of the directory that contains one or multiple '
              'Trials.')
@click.option('-n',
              '--name',
              'trial_name',
              type=str,
              metavar='TRIAL_NAME',
              multiple=True,
              help='Name of the Trial.')
@click.option('-l',
              '--platform',
              'platform_flag',
              is_flag=True,
              default=False,
              help='Show platform info of Trial.')
@click.option('-H',
              '--hparams',
              'hparam_flag',
              is_flag=True,
              default=False,
              help='Show hyperparameters of Trial.')
@click.option('-m',
              '--metrics',
              'metric_flag',
              is_flag=True,
              default=False,
              help='Show metrics of Trial.')
@click.option('-a',
              '--all',
              'all_',
              is_flag=True,
              default=False,
              help='Equivalent to -lHm')
@trial.command('describe', context_settings=CONTEXT_SETTINGS)
def describe_trial(trial_path: Tuple[str], trial_dir: Optional[str],
                   trial_name: Tuple[str], platform_flag: bool,
                   hparam_flag: bool, metric_flag: bool, all_: bool):
    """Describe one or multiple Trials that are saved locally.

    \b
    Examples:
      \b
      # Describe one Trial by its path:
      aimd trial describe -p .aimd/trials/mnist_keras_220823_194728_4e48t2
      # or
      aimd trial describe -p /path/to/workspace/.aimd/trials/mnist_keras_220823_194728_4e48t2
      \b
      # Describe all Trials under a directory:
      aimd trial describe -d .aimd/trials
      \b
      # Describe one Trial by its alternative name:
      aimd trial describe -n mnist_keras_220823_194728_4e48t2
      \b
      # Describe multiple Trials by their alternative names:
      aimd trial describe -n mnist_keras_220823_194728_4e48t2 -n mnist_torch_220823_195814_vjo18w
      \b
      # Show hyperparameters, metrics and platform info of Trial:
      aimd trial describe -n mnist_keras_220823_194728_4e48t2 -a
    """
    if all_:
        platform_flag = True
        hparam_flag = True
        metric_flag = True

    describe_list = []

    if trial_path:
        for p in trial_path:
            describe_list.append(p)

    if trial_dir:
        for entry in os.listdir(trial_dir):
            if is_random_name(entry) and isdir(join(trial_dir, entry)):
                describe_list.append(join(trial_dir, entry))

    if trial_name:
        for t in trial_name:
            describe_list.append(_get_trial_path_by_name(t))

    def load_data_file(file_path: str) -> Dict[str, Any]:
        if not isfile(file_path):
            eprint('File of Trial does not exist: {}'.format(file_path))
        try:
            data = read_yaml_file(file_path)
        except yaml.scanner.ScannerError:
            eprint('Invalid YAML document: {}'.format(file_path))
        return data

    print_delimiter_flag = False
    for p in describe_list:
        if not print_delimiter_flag:
            print_delimiter_flag = True
        else:
            click.echo('---')
        metadata_file_path = join(p, 'metadata.yaml')
        parameter_file_path = join(p, 'parameters.yaml')
        metric_file_path = join(p, 'metrics.yaml')

        trial_data = load_data_file(metadata_file_path)
        metadata = trial_data['metadata']

        table = [
            ['Name:', metadata['name']],
            ['Alternative Name:', basename(p)],
            ['ID:', metadata['id']],
            ['Status:', trial_data['status']],
            ['Start Time:', trial_data['startTime']],
            ['End Time:', trial_data['endTime']],
            ['Editor:', metadata['editor']],
        ]
        if trial_data['inputArtifacts']:
            subtable = tabulate.tabulate(
                [[a] for a in trial_data['inputArtifacts']], tablefmt='plain')
            table.append(['Input Artifacts:', subtable])
        else:
            table.append(['Input Artifacts:', '<none>'])
        if trial_data['outputArtifacts']:
            subtable = tabulate.tabulate(
                [[a] for a in trial_data['outputArtifacts']], tablefmt='plain')
            table.append(['Output Artifacts:', subtable])
        else:
            table.append(['Output Artifacts:', '<none>'])

        if platform_flag:
            platform_info = trial_data['platform']
            table.extend([
                ['Platform:', ''],
                ['  Hostname:', platform_info['hostname']],
                ['  OS:', platform_info['os']],
                ['  Python version:', platform_info['python']],
                ['  Framework:', platform_info['framework']],
                ['  Python packages:', ''],
            ])
            for k, v in platform_info['pypkgs'].items():
                table.append(['    {}:'.format(k), v])

        if hparam_flag:
            parameters = load_data_file(parameter_file_path)
            table.append(['Hyperparameters:', ''])
            for k, v in parameters.items():
                if isinstance(v, dict):
                    table.append(['  {}:'.format(k), ''])
                    for k_, v_ in v.items():
                        table.append(['    {}:'.format(k_), v_])
                else:
                    table.append(['  {}:'.format(k), v])

        if metric_flag:
            metrics = load_data_file(metric_file_path)
            table.append(['Metrics:', ''])
            for class_, metric_list in metrics.items():
                headers = []
                metric_0 = metric_list[0]

                contain_epoch = 'epoch' in metric_0['sequence']
                if contain_epoch:
                    headers.append('sequence/\nepoch')
                headers.extend(['sequence/\nstep', 'sequence/\ntimestamp'])

                for metric_name in metric_0['value']:
                    headers.append('value/\n{}'.format(metric_name))

                subtable = []
                last_timestamp = ''
                for metric in metric_list:
                    row = []

                    if contain_epoch:
                        row.append(metric['sequence']['epoch'])

                    row.append(metric['sequence']['step'])

                    timestamp = metric['sequence']['timestamp']
                    if timestamp[:10] == last_timestamp[:10]:
                        row.append(timestamp[11:19])
                    else:
                        row.append(timestamp[:19])
                    last_timestamp = timestamp

                    row.extend(list(metric['value'].values()))

                    subtable.append(row)

                table.append([
                    '  {}:'.format(class_),
                    tabulate.tabulate(subtable,
                                      headers,
                                      tablefmt='plain',
                                      stralign='right',
                                      floatfmt='.4f')
                ])

        click.echo(tabulate.tabulate(table, tablefmt='plain'))


@click.option('-p',
              '--path',
              'trial_path',
              type=str,
              metavar='TRIAL_PATH',
              multiple=True,
              help='Local path of the Trial to be uploaded.')
@click.option('-d',
              '--dir',
              'trial_dir',
              type=str,
              metavar='TRIAL_DIR',
              help='Local path of the directory that contains one or multiple '
              'Trials.')
@click.option('-n',
              '--name',
              'trial_name',
              type=str,
              metavar='TRIAL_NAME',
              multiple=True,
              help='Name of the Trial to be uploaded.')
@click.option('-I',
              '--folder-id',
              type=str,
              metavar='FOLDER_ID',
              help='ID of the folder in which Trial is created.')
@click.option('-P',
              '--folder-path',
              type=str,
              metavar='FOLDER_PATH',
              help='Path of the folder in which Trial is created.')
@click.option('-m',
              '--make-folder',
              is_flag=True,
              default=False,
              help='Make the folder and parent folders as needed.')
@click.option('-c',
              '--conflict-strategy',
              type=click.Choice(['skip', 'error', 'new', 'replace']),
              help='Make the folder and parent folders as needed.')
@trial.command('upload', context_settings=CONTEXT_SETTINGS)
@no_raise
def upload_trial_(trial_path: Tuple[str], trial_dir: Optional[str],
                  trial_name: Tuple[str], folder_id: Optional[str],
                  folder_path: Optional[str], make_folder: bool,
                  conflict_strategy: Optional[str]):
    """Upload one or multiple Trials that are saved locally.

    For parameters `folder_id`, `folder_path` and `make_folder`, the values
    of the arguments passed in take precedence over values parsed from
    `_upload` field in Trial data file.

    \b
    Examples:
      \b
      # Upload one Trial by its path:
      aimd trial upload -p .aimd/trials/mnist_keras_220823_194728_4e48t2
      # or
      aimd trial upload -p /path/to/workspace/.aimd/trials/mnist_keras_220823_194728_4e48t2
      \b
      # Upload all Trials under a directory:
      aimd trial upload -d .aimd/trials
      \b
      # Upload one Trial by its alternative name:
      aimd trial upload -n mnist_keras_220823_194728_4e48t2
      \b
      # Upload multiple Trials by their alternative names:
      aimd trial upload -n mnist_keras_220823_194728_4e48t2 -n mnist_torch_220823_195814_vjo18w
      \b
      # Provide arguments that are not provided in Trial metadata file:
      aimd trial upload -n mnist_keras_220823_194728_4e48t2 -P image_classification/mnist
    """
    login()
    upload_trial(list(trial_path), trial_dir, list(trial_name), folder_id,
                 folder_path, make_folder, conflict_strategy)


@click.group(context_settings=CONTEXT_SETTINGS)
def artifact():
    """Manage Artifacts."""
    pass


@click.argument('artifact_path', type=click.Path(exists=True), required=False)
@click.option('-d',
              '--detail',
              is_flag=True,
              default=False,
              help='Show detailed information about Artifact.')
@artifact.command('ls', context_settings=CONTEXT_SETTINGS)
def list_artifact(artifact_path: Optional[str], detail: bool):
    """List local Artifacts.

    If ARTIFACT_PATH is not provided, it defaults to ".".
    """
    if not artifact_path:
        artifact_path = ARTIFACT_PATH
    if artifact_path.endswith('/'):
        artifact_path = artifact_path[:-1]

    if ARTIFACT_PATH not in artifact_path:
        artifact_path = join(artifact_path, ARTIFACT_PATH)
    if artifact_path.endswith(ARTIFACT_PATH):
        artifact_paths = glob('{}/*/*-*-*-*-*'.format(artifact_path))
    elif dirname(artifact_path).endswith(ARTIFACT_PATH):
        artifact_paths = glob('{}/*-*-*-*-*'.format(artifact_path))
    else:
        artifact_paths = []

    if detail:
        headers = [
            'NAME', 'TYPE', 'ID', 'ALIASES', 'COMMIT', 'VERSION', 'CREATED',
            'EDITOR'
        ]
    else:
        headers = ['NAME', 'ID', 'COMMIT', 'VERSION', 'CREATED']

    table = []
    repos = {}
    for p in artifact_paths:
        metadata_file_path = join(p, 'metadata.yaml')
        if not isfile(metadata_file_path):
            eprint('Metadata file of Artifact does not exist: {}'.format(
                metadata_file_path))

        name = basename(dirname(p))
        if name not in repos:
            repo_file_path = join(p, '..', 'metadata.yaml')
            if not isfile(repo_file_path):
                eprint(
                    'Metadata file of Artifact repo does not exist: {}'.format(
                        repo_file_path))
            try:
                repo_data = read_yaml_file(repo_file_path)
            except yaml.scanner.ScannerError:
                eprint('Invalid YAML document: {}'.format(repo_file_path))
            repos[repo_data['name']] = repo_data['type']

        try:
            artifact_data = read_yaml_file(metadata_file_path)
        except yaml.scanner.ScannerError:
            eprint('Invalid YAML document: {}'.format(metadata_file_path))

        id_ = artifact_data['metadata']['id']
        commit = artifact_data['commit'][:8]
        version = artifact_data['version']
        created = format_timedelta(
            datetime.fromisoformat(get_local_now_iso()) -
            datetime.fromisoformat(artifact_data['creatingTimestamp']),
            brief=True) + ' ago'

        if detail:
            type_ = repos[name]
            aliases = ', '.join(artifact_data['aliases'])
            editor = artifact_data['metadata']['editor']
            table.append(
                [name, type_, id_, aliases, commit, version, created, editor])
        else:
            table.append([name, id_, commit, version, created])

    click.echo(tabulate.tabulate(table, headers, tablefmt='plain'))


@click.option('-p',
              '--path',
              'artifact_path',
              type=str,
              metavar='ARTIFACT_PATH',
              multiple=True,
              help='Local path of the Artifact.')
@click.option('-i',
              '--id',
              'artifact_id',
              type=str,
              metavar='ARTIFACT_ID',
              multiple=True,
              help='ID of the Artifact.')
@click.option('-r',
              '--repo-path',
              type=str,
              metavar='REPO_PATH',
              help='Local path of the Artifact repo.')
@click.option('-n',
              '--repo-name',
              type=str,
              metavar='REPO_NAME',
              help='Name of the Artifact repo.')
@click.option('-R',
              '--remote',
              'remote_flag',
              is_flag=True,
              default=False,
              help='Show remote locations of Artifact.')
@click.option('-o',
              '--object',
              'object_flag',
              is_flag=True,
              default=False,
              help='Show objects of Artifact.')
@click.option('-a',
              '--all',
              'all_',
              is_flag=True,
              default=False,
              help='Equivalent to -Ro')
@artifact.command('describe', context_settings=CONTEXT_SETTINGS)
def describe_artifact(artifact_path: Tuple[str], artifact_id: Tuple[str],
                      repo_path: Optional[str], repo_name: Optional[str],
                      remote_flag: bool, object_flag: bool, all_: bool):
    """Describe one or multiple Artifacts that are saved locally.
    
    \b
    Examples:
      \b
      # Describe one Artifact by its path:
      aimd artifact describe -p .aimd/artifacts/mnist_keras_model/18c77b08-d3f4-4a88-a0e3-9f578c7f6750
      # or
      aimd artifact describe -p /path/to/workspace/.aimd/artifacts/mnist_keras_model/18c77b08-d3f4-4a88-a0e3-9f578c7f6750
      \b
      # Describe one Artifact by its ID:
      aimd artifact describe -i 18c77b08-d3f4-4a88-a0e3-9f578c7f6750
      \b
      # Describe multiple Artifacts by their IDs:
      aimd artifact describe -i 18c77b08-d3f4-4a88-a0e3-9f578c7f6750 -i 6feee8d9-03bf-49bb-9812-b47d3cce4e05
      \b
      # Describe all Artifacts in a repo:
      aimd artifact describe -r .aimd/artifacts/mnist_keras_model
      # or
      aimd artifact describe -n mnist_keras_model
      \b
      # Show objects and remote locations of Artifact:
      aimd artifact describe -i 18c77b08-d3f4-4a88-a0e3-9f578c7f6750 -a
    """
    if all_:
        remote_flag = True
        object_flag = True

    describe_list = []

    if artifact_path:
        for p in artifact_path:
            describe_list.append(p)

    if artifact_id:
        for i in artifact_id:
            describe_list.append(_get_artifact_path_by_id(i))

    if repo_path:
        for entry in os.listdir(repo_path):
            if is_uuid(entry) and isdir(join(repo_path, entry)):
                describe_list.append(join(repo_path, entry))

    if repo_name:
        repo_path_ = join(ARTIFACT_PATH, repo_name)
        for entry in os.listdir(repo_path_):
            if is_uuid(entry) and isdir(join(repo_path_, entry)):
                describe_list.append(join(repo_path_, entry))

    def load_data_file(file_path: str) -> Dict[str, Any]:
        if not isfile(file_path):
            eprint('File of Artifact does not exist: {}'.format(file_path))
        try:
            data = read_yaml_file(file_path)
        except yaml.scanner.ScannerError:
            eprint('Invalid YAML document: {}'.format(file_path))
        return data

    for p in describe_list:
        metadata_file_path = join(p, 'metadata.yaml')
        repo_file_path = join(p, '..', 'metadata.yaml')
        object_file_path = join(p, 'object_list.yaml')

        artifact_data = load_data_file(metadata_file_path)
        metadata = artifact_data['metadata']
        repo_data = load_data_file(repo_file_path)

        table = [
            ['Name:', repo_data['name']],
            ['Type:', repo_data['type']],
            ['ID:', metadata['id']],
            [
                'Aliases:', ', '.join(artifact_data['aliases'])
                if artifact_data['aliases'] else '<none>'
            ],
            ['Commit:', artifact_data['commit']],
            ['Version:', artifact_data['version']],
            ['Create Time:', artifact_data['creatingTimestamp']],
            ['Editor:', metadata['editor']],
        ]

        if remote_flag:
            remote_info = artifact_data['_remote']
            if not remote_info:
                table.append(['Remote:', '<none>'])
            else:
                headers = ['host', 'path', 'version']
                subtable = []
                for r in remote_info:
                    subtable.append([r['host'], r['path'], r['version']])

                table.append([
                    'Remote:',
                    tabulate.tabulate(subtable, headers, tablefmt='plain')
                ])

        if object_flag:
            objects = load_data_file(object_file_path)
            if not objects:
                table.append(['Objects:', '<none>'])
            else:
                headers = ['key', 'size']
                # headers = ['key', 'size', 'digest']
                subtable = []
                total_size = 0
                for obj in objects:
                    row = []
                    row.append(obj['key'])
                    row.append(human_readable_size(obj['size']))
                    total_size += obj['size']
                    subtable.append(row)

                table.append([
                    'Objects:',
                    tabulate.tabulate(subtable, headers, tablefmt='plain')
                ])
                table.append([
                    '', '{} files, {} in total'.format(
                        len(objects), human_readable_size(total_size))
                ])

        click.echo(tabulate.tabulate(table, tablefmt='plain'))


@click.option('-p',
              '--path',
              'artifact_path',
              type=str,
              metavar='ARTIFACT_PATH',
              multiple=True,
              help='Local path of the Artifact to be uploaded.')
@click.option('-i',
              '--id',
              'artifact_id',
              type=str,
              metavar='ARTIFACT_ID',
              multiple=True,
              help='ID of the Artifact to be uploaded.')
@click.option('-r',
              '--repo-path',
              type=str,
              metavar='REPO_PATH',
              help='Local path of the Artifact repo in which all Artifacts '
              'are to be uploaded.')
@click.option('-n',
              '--repo-name',
              type=str,
              metavar='REPO_NAME',
              help='Name of the Artifact repo in which all Artifacts are to be'
              'uploaded.')
@click.option('-I',
              '--folder-id',
              type=str,
              metavar='FOLDER_ID',
              help='ID of the folder in which Trial is created.')
@click.option('-P',
              '--folder-path',
              type=str,
              metavar='FOLDER_PATH',
              help='Path of the folder in which Trial is created.')
@click.option('-m',
              '--make-folder',
              is_flag=True,
              default=False,
              help='Make the folder and parent folders as needed.')
@artifact.command('upload', context_settings=CONTEXT_SETTINGS)
@no_raise
def upload_artifact_(artifact_path: Tuple[str],
                     artifact_id: Tuple[str],
                     repo_path: Optional[str],
                     repo_name: Optional[str],
                     folder_id: Optional[str],
                     folder_path: Optional[str] = None,
                     make_folder: bool = False):
    """Upload one or multiple Artifacts that are saved locally.

    \b
    Examples:
      \b
      # Upload one Artifact by its path:
      aimd artifact upload -p .aimd/artifacts/mnist_keras_model/18c77b08-d3f4-4a88-a0e3-9f578c7f6750
      # or
      aimd artifact upload -p /path/to/workspace/.aimd/artifacts/mnist_keras_model/18c77b08-d3f4-4a88-a0e3-9f578c7f6750
      \b
      # Upload one Artifact by its ID:
      aimd artifact upload -i 18c77b08-d3f4-4a88-a0e3-9f578c7f6750
      \b
      # Upload multiple Artifacts by their IDs:
      aimd artifact upload -i 18c77b08-d3f4-4a88-a0e3-9f578c7f6750 -i 6feee8d9-03bf-49bb-9812-b47d3cce4e05
      \b
      # Upload all Artifacts in a repo:
      aimd artifact upload -r .aimd/artifacts/mnist_keras_model
      # or
      aimd artifact upload -n mnist_keras_model
    """
    login()
    upload_artifact(list(artifact_path), list(artifact_id), repo_path,
                    repo_name, folder_id, folder_path, make_folder)


cli.add_command(trial)
cli.add_command(artifact)


def eprint(msg, prefix=True):
    """Prints error message and exits."""
    if prefix:
        click.echo(red('error: ', bold=True) + msg, err=True)
    else:
        click.echo(msg, err=True)
    sys.exit(1)
