"""Callback for PyTorch Lightning."""

import pytorch_lightning

from t9k.aimd.trial import Trial


class AIMDCallback(pytorch_lightning.callbacks.Callback):
    """Logs metrics and retrieves hyperparameters.

    Examples:

        ```
        trainer = Trainer(max_epochs=10,
                          callbacks=AIMDCallback(trial))
        ```

    Args:
        trial: Trial that the training and testing process belongs to.
    """
    def __init__(self, trial: Trial):
        super(AIMDCallback, self).__init__()
        self.trial = trial

    def on_train_start(self, trainer, pl_module):
        # Retrieves params from `LightningModule.hparams`
        self.trial.params.update(dict(pl_module.hparams))
        self.trial._update_status('Running')

    def on_validation_epoch_end(self, trainer, pl_module, outputs=None):
        metrics = {k: v.item() for k, v in trainer.callback_metrics.items()}
        # Keys of training metrics have the prefix 'train_' and keys of
        # validation metrics have the prefix of 'val_'.
        if 'train_loss' in metrics:
            train_metrics = {
                k[6:]: v
                for k, v in metrics.items() if k.startswith('train_')
            }
            val_metrics = {
                k[4:]: v
                for k, v in metrics.items() if k.startswith('val_')
            }
            self.trial.log('train',
                           train_metrics,
                           step=trainer.global_step + 1,
                           epoch=trainer.current_epoch + 1,
                           check_status=False)
            self.trial.log('val',
                           val_metrics,
                           step=trainer.global_step + 1,
                           epoch=trainer.current_epoch + 1,
                           check_status=False)

    def on_test_epoch_end(self, trainer, pl_module, outputs=None):
        metrics = {k: v.item() for k, v in trainer.callback_metrics.items()}
        # Keys of testing metrics have the prefix 'test_'.
        test_metrics = {
            k[5:]: v
            for k, v in metrics.items() if k.startswith('test_')
        }
        self.trial.log('test',
                       test_metrics,
                       step=trainer.global_step,
                       check_status=False)
