"""Trial class."""

from glob import glob
import logging
import os
from typing import Any, Dict, List, Optional

from t9k.aimd.client import CLIENT
from t9k.aimd.containers import Params, Metrics
from t9k.aimd.artifact import Artifact
from t9k.utils.decorators import called_once_only_each_instance
from t9k.utils.datetime_utils import get_local_now_iso
from t9k.utils.file_utils import (join, isfile, isdir, abspath, basename,
                                  dirname, read_jsons_file, write_json_file,
                                  write_yaml_file, read_yaml_file)
from t9k.utils.git_utils import get_git_repo_data
from t9k.utils.local_platform_utils import get_platform_data
from t9k.utils.print_utils import black, blue, cyan, red
from t9k.utils.random_utils import new_random_name
from t9k.utils.sys_utils import _add_stdout_logfile, _remove_stdout_logfile
from t9k.utils.uuid_utils import new_uuid

_logger = logging.getLogger(__name__)

TRIAL_PATH = '.aimd/trials'


class Trial(object):
    """Implementation of Trial, a run of a specific model for certain ML task.

    You can save data of Trial to a local YAML file or load Trial from it.

    Args:
        trial_data: Data of Trial to initialize a new Trial.

    Attributes:
        id: ID of the Trial.
        name: Name of the Trial.
        metrics: Metrics produced in the Trial.
        params: Hyperparameters of the Trial.
        input_artifacts: Input Artifacts of the Trial.
        output_artifacts: Output Artifacts of the Trial.
    """

    def __init__(self,
                 trial_data: Dict[str, Any],
                 local_name: Optional[str] = None):
        self.parse_from_dict(trial_data)
        self._local_name = local_name or new_random_name(base_name=self.name)
        self._prepare_local_file()

    @property
    def id(self) -> str:
        return self._metadata['id']

    @property
    def name(self) -> str:
        return self._metadata['name']

    @property
    def metrics(self) -> Metrics:
        return self._metrics

    @property
    def input_artifacts(self) -> List[str]:
        return self._input_artifacts

    @property
    def output_artifacts(self) -> List[str]:
        return self._output_artifacts

    def parse_from_dict(self, trial_data: Dict[str, Any]) -> None:
        """Parses Trial instance from a dict."""
        self._metadata = trial_data['metadata']

        self._platform = trial_data['platform']

        self._start_time = trial_data['startTime']
        self._end_time = trial_data['endTime']
        self._status = trial_data['status']

        params = trial_data['parameters']
        if params == '':
            self.params = Params(self._update_params)
        elif isinstance(params, dict):
            self.params = Params(self._update_params, params)
        else:
            raise ValueError('Invalid parameters')

        metrics = trial_data['metrics']
        if metrics == '':
            self._metrics = {}
        elif isinstance(metrics, dict):
            self._metrics = metrics
        else:
            raise ValueError('Invalid metrics')

        input_artifacts = trial_data['inputArtifacts']
        if input_artifacts is None:
            self._input_artifacts = []
        elif isinstance(input_artifacts, list):
            self._input_artifacts = input_artifacts
        else:
            raise ValueError('Invalid input artifacts')

        output_artifacts = trial_data['outputArtifacts']
        if output_artifacts is None:
            self._output_artifacts = []
        elif isinstance(output_artifacts, list):
            self._output_artifacts = output_artifacts
        else:
            raise ValueError('Invalid output artifacts')

        self._upload_info = trial_data.get('_upload', {})
        self._git = trial_data.get('_git', {})

    def to_dict(self) -> Dict[str, Any]:
        """Converts Trial instance to a dict and returns it."""
        return {
            'kind': 'Trial',
            'metadata': self._metadata,
            'platform': self._platform,
            'startTime': self._start_time,
            'endTime': self._end_time,
            'status': self._status,
            'parameters': self.params.as_dict(),
            'metrics': self._metrics,
            'inputArtifacts': self._input_artifacts,
            'outputArtifacts': self._output_artifacts,
            '_upload': self._upload_info,
            '_git': self._git,
        }

    def _metadata_to_dict(self) -> Dict[str, Any]:
        return {
            'kind': 'Trial',
            'metadata': self._metadata,
            'platform': self._platform,
            'startTime': self._start_time,
            'endTime': self._end_time,
            'status': self._status,
            'inputArtifacts': self._input_artifacts,
            'outputArtifacts': self._output_artifacts,
            '_upload': self._upload_info,
            '_git': self._git,
        }

    def upload(
            self,
            folder_id: Optional[str] = None,
            folder_path: Optional[str] = None,
            make_folder: bool = None,
            conflict_strategy: Optional[str] = None
    ) -> Optional[Dict[str, str]]:
        """Uploads Trial to server."""
        _logger.info('Uploading Trial %s', cyan(self.name))
        # priority: args > Trial data file
        u = self._upload_info
        if folder_id:
            _logger.debug('Args provide folder id: %s', folder_id)
            u['folder_id'] = folder_id
        else:
            _logger.debug('Trial data file provides folder id: %s',
                          u['folder_id'])
        if folder_path:
            _logger.debug('Args provide folder path: %s', folder_path)
            u['folder_path'] = folder_path
        else:
            _logger.debug('Trial data file provides folder path: %s',
                          u['folder_path'])
        if make_folder:
            _logger.debug('Args provide make_folder: %s', make_folder)
            u['make_folder'] = make_folder
        else:
            _logger.debug('Trial data file provides make_folder: %s',
                          u['make_folder'])
        if conflict_strategy:
            _logger.debug('Args provide conflict strategy: %s',
                          conflict_strategy)
            u['conflict_strategy'] = conflict_strategy
        else:
            _logger.debug('Trial data file provides conflict_strategy: %s',
                          u['conflict_strategy'])

        new_metadata = self._upload()

        if new_metadata:
            trial_addr = '{}/web/#/trials/{}/'.format(dirname(CLIENT.host),
                                                      self.id)
            _logger.info('Trial %s uploaded, view its data by visiting %s',
                         cyan(self.name), blue(trial_addr, underline=True))

    @called_once_only_each_instance()
    def _upload(self) -> Optional[Dict[str, str]]:
        """Implements uploading Trial to server.

        This method will post the complete data of Trial to server by calling
        `CLIENT.add_trial()`.

        This method could only be called once. All further updates should be
        posted by other methods.
        """
        _logger.debug('Upload Trial %s to server', self.id)
        new_metadata = CLIENT.add_trial(self)
        if new_metadata:
            _logger.debug(
                'Uploaded Trial %s and got new metadata %s from server',
                self.id, new_metadata)
            self._metadata = new_metadata

        return new_metadata

    def _save(self) -> None:
        """Saves data of Trial to a local YAML file."""
        _logger.debug('Save Trial %s to %s', self.id, self._path)
        write_yaml_file(self._metadata_path, self._metadata_to_dict())
        write_yaml_file(self._params_path, self.params.as_dict())
        write_json_file(self._metrics_path, self.metrics)
        _logger.debug('Save complete')

    @staticmethod
    def _load_from_local(trial_path: str) -> 'Trial':
        """Implements loading Trial from local path."""
        _logger.debug('Load Trial from %s', trial_path)

        metadata_file_path = join(trial_path, 'metadata.yaml')
        parameter_file_path = join(trial_path, 'parameters.yaml')
        metric_file_path = join(trial_path, 'metrics')

        if not (isfile(metadata_file_path) and isfile(parameter_file_path)
                and isfile(metric_file_path)):
            _logger.error(
                'Failed to load Trial in path: %s, the directory must contain '
                'file `metadata.yaml`, `parameters.yaml` and `metrics`',
                red(trial_path))
            raise RuntimeError(
                'Failed to load Trial in path: {}, the directory must contain '
                'file `metadata.yaml`, `parameters.yaml` and `metrics`'.format(
                    trial_path))

        def load_data_file(file_path: str) -> Dict[str, Any]:
            msg = ('Invalid data file of Trial: {}, please read the '
                   'exception message and check the file').format(
                       red(file_path))
            return read_yaml_file(file_path, error_msg=msg)

        trial_data = load_data_file(metadata_file_path)
        trial_data['parameters'] = load_data_file(parameter_file_path)

        trial_data['metrics'] = {}
        all_metrics = read_jsons_file(metric_file_path)
        for metrics in all_metrics:
            for metrics_type, metrics_element in metrics.items():
                if metrics_type in trial_data['metrics']:
                    trial_data['metrics'][metrics_type].append(metrics_element)
                else:
                    trial_data['metrics'][metrics_type] = [metrics_element]

        trial = Trial(trial_data=trial_data, local_name=basename(trial_path))
        trial._upload_info['load_path'] = trial_path
        _logger.debug('Load complete')

        return trial

    def _prepare_local_file(self) -> None:
        """Prepares local directory and file for Trial.

        Create a directory of Trial, under the directory create some YAML files
        to store Trial data.

        If the directory already exists, do nothing. This occurs when loading
        a local Trial.
        """
        self._path = join(TRIAL_PATH, self._local_name)
        self._metadata_path = join(self._path, 'metadata.yaml')
        self._params_path = join(self._path, 'parameters.yaml')
        self._metrics_path = join(self._path, 'metrics')
        if isdir(self._path):
            return

        _logger.debug('Create local directory for Trial %s', self.name)

        os.makedirs(self._path)
        write_yaml_file(self._metadata_path, self._metadata_to_dict())
        write_yaml_file(self._params_path, self.params.as_dict())
        open(self._metrics_path, 'w').close()  # create empty file

        _add_stdout_logfile(join(self._path, 'stdout.log'))

        _logger.debug('Local directory created: %s', abspath(self._path))
        _logger.info('Data of Trial %s saved to %s', cyan(self.name),
                     black(self._path, underline=True))

    def _update_status(self, status: str) -> None:
        """Updates status of Trial."""
        _logger.debug('Update status of Trial %s to "%s"', self.id, status)
        if status in ['Running']:
            self._status = status
            write_yaml_file(self._metadata_path, self._metadata_to_dict())
        elif status in ['Succeeded', 'Failed']:
            self._status = status
            self._end_time = get_local_now_iso()
            write_yaml_file(self._metadata_path, self._metadata_to_dict())
        else:
            raise ValueError('Incorrect status type')
        _logger.debug('Update complete')

    def _update_params(self) -> None:
        """Updates hyperparameters of Trial."""
        write_yaml_file(self._params_path, self.params.as_dict())

    def log(self,
            metrics_type: str,
            metrics: Dict[str, float],
            step: int,
            epoch: Optional[int] = None,
            check_status: bool = True) -> None:
        """Logs metrics of Trial.

        Args:
            metrics_type:
                Type of metrics, 'train' (or 'training'), 'val' (or 'validate',
                'validation'), 'test' (or 'testing', 'eval', 'evaluate',
                'evaluation') for training metrics, validation metrics, testing
                metrics respectively. Besides, you can also use other arbitrary
                string as custom type of metric.
            metrics:
                Additional metrics to be logged.
            step:
                Number of step that metrics belong to.
            epoch:
                Number of epoch that metrics belong to.
            check_status:
                If True and current status of Trial is 'Initializing', update
                it to 'Running'.
        """
        _logger.debug(
            'Log metric of Trial %s: %s of type %s at step %s and epoch %s',
            self.id, metrics, metrics_type, step, epoch)
        if check_status and self._status == 'Initializing':
            _logger.debug('First call `log()`')
            self._update_status('Running')

        metrics = {k: float(v) for k, v in metrics.items()}

        metrics_element = [{
            'value': metrics,
            'sequence': {
                'epoch': epoch,
                'step': step,
                'timestamp': get_local_now_iso(),
            }
        }]
        if metrics_type not in self._metrics:
            self._metrics[metrics_type] = metrics_element
        else:
            self._metrics[metrics_type] += metrics_element

        metrics_written = {metrics_type: metrics_element[0]}
        write_json_file(self._metrics_path, metrics_written, append=True)

    def mark_input(self, artifact: Artifact) -> None:
        """Adds ID of the Artifact to list of input Artifacts.

        The Artifact must have `artifact._is_open == False`.
        """
        _logger.debug('Add Artifact %s to list of input Artifacts of Trial %s',
                      artifact.id, self.id)

        if artifact._is_open:
            _logger.error('Cannot use an Artifact that is not uploaded yet '
                          'and open to changes')
            raise RuntimeError('Cannot use an Artifact that is not uploaded '
                               'yet and open to changes')

        if artifact.id in self._input_artifacts:
            _logger.debug(
                'Artifact already in list of input Artifacts of Trial')
        else:
            self._input_artifacts.append(artifact.id)
            write_yaml_file(self._metadata_path, self._metadata_to_dict())

        _logger.info('Trial %s used Artifact %s',
                     *cyan(self.name, artifact.id))

    def mark_output(self, artifact: Artifact) -> None:
        """Adds ID of the Artifact to list of output Artifacts.

        The Artifact must have `artifact._can_be_logged == True`.
        """
        _logger.debug(
            'Add Artifact %s to list of output Artifacts of Trial %s',
            artifact.id, self.id)

        if not artifact._can_be_logged:
            if artifact.id in self._output_artifacts:
                _logger.debug(
                    'Artifact already in list of output Artifacts of Trial')
            else:
                _logger.error('Cannot log an Artifact that is not newly '
                              'created or is already logged')
                raise RuntimeError('Cannot log an Artifact that is not newly '
                                   'created or is already logged')
        else:
            self._output_artifacts.append(artifact.id)
            write_yaml_file(self._metadata_path, self._metadata_to_dict())
            artifact._can_be_logged = False

            _logger.info('Trial %s produced Artifact %s',
                         *cyan(self.name, artifact.id))

    def _update_platform(self) -> None:
        """Updates platform data of Trial."""
        _logger.debug('Update platform info of Trial %s', self.id)
        self._platform = get_platform_data()
        write_yaml_file(self._metadata_path, self._metadata_to_dict())

    @called_once_only_each_instance()
    def finish(self) -> None:
        """Finishes the Trial and saves data of Trial."""
        _logger.debug('Finish Trial %s', self.id)
        self._update_status('Succeeded')
        self._update_platform()

        # self._save()

        _remove_stdout_logfile(join(self._path, 'stdout.log'))


def _new_trial(name: str,
               params: Dict[str, any] = None,
               folder_id: Optional[str] = None,
               folder_path: Optional[str] = None,
               make_folder: bool = False,
               conflict_strategy: str = 'new') -> Trial:
    """Creates and initializes a new Trial instance.

    Args:
        name:
            Name of Trial.
        params:
            Initial parameters of Trial.
        folder_id:
            ID of folder in which Trial is created.
        folder_path:
            Path of the folder in which Trial is created.
        make_folder:
            If True and folder with folder_path does not exist, make the
            folder and parent folders as needed.
        conflict_strategy:
            Strategy adopted when a Trial with the same name as the Trial
            to be uploaded already exists in the folder, must be `'skip'`,
            `'error'`, `'new'` or `'replace'`. If `'skip'`, skip the upload;
            if `'error'`, error out; if `'new'`, upload with the local name of
            Trial; if `'replace'`, delete the existing Trial and upload.

    Returns:
        A Trial instance created and initialized.
    """
    new_id = new_uuid()
    _logger.info('Creating Trial %s with ID %s', *cyan(name, new_id))

    # Trial data
    trial_data = {
        'kind': 'Trial',
        'metadata': {
            'folder': None,
            'name': name,
            'editor': None,
            'id': new_id,
            'timestamp': None,
        },
        # TODO: rename to startingTimestamp and endingTimestamp
        'startTime': get_local_now_iso(),
        'endTime': None,
        'status': 'Initializing',
        'platform': get_platform_data(),
        'parameters': params or '',
        'metrics': '',
        'inputArtifacts': None,
        'outputArtifacts': None,
    }
    _logger.debug('Trial summary:')
    _logger.debug('  name: %s', name)
    _logger.debug('  ID: %s', trial_data['metadata']['id'])
    _logger.debug('  start time: %s', trial_data['startTime'])
    if params:
        _logger.debug('    initial parameters: %s', params)

    # data for uploading
    trial_data['_upload'] = {
        'folder_id': folder_id,
        'folder_path': folder_path,
        'make_folder': make_folder,
        'conflict_strategy': conflict_strategy,
    }

    # Git repo data
    trial_data['_git'] = get_git_repo_data()

    _logger.debug('Trial stores upload info %s', trial_data['_upload'])

    trial = Trial(trial_data=trial_data)
    _logger.debug('Trial creation and initialization complete')

    return trial


def _get_trial_path_by_name(name: str) -> str:
    """Trys to get local path of Trial by its name.

    Only TRIAL_PATH will be searched.
    """
    trial_paths = glob('{}/*_*_*_*'.format(TRIAL_PATH))
    target = None
    candidates = []
    for p in trial_paths:
        if basename(p) == name:
            target = p
            break
        if basename(p).startswith(name):
            candidates.append(p)

    if not target:
        if not candidates:
            _logger.error(
                'Failed to get Trial path for no local Trial matched the name:'
                ' %s, please check the name or local path', red(name))
            raise FileNotFoundError(
                'Failed to get Trial path for no Trial matched the name:'
                ' {}'.format(name))
        if len(candidates) == 1:
            target = candidates[0]
        else:
            _logger.error(
                'Failed to get Trial path for multiple local Trials matched '
                'the name: %s matched %s, please pass in the alternative name '
                'of the specific Trial', *red(candidates, name))
            raise RuntimeError(
                'Failed to get Trial path for multiple Trials matched the '
                'name: {} matched {}'.format(candidates, name))

    return target
