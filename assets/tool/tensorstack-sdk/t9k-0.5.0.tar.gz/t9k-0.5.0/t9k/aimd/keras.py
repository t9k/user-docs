"""Callbacks for Keras."""

import logging

import numpy as np
from tensorflow import keras

from t9k.aimd.trial import Trial

_logger = logging.getLogger(__name__)


class AIMDFitCallback(keras.callbacks.Callback):
    """Logs training metrics and retrieves hyperparameters.

    Examples:

        ```
        from t9k.aimd.keras import AIMDFitCallback

        model.fit(train_images,
                  train_labels,
                  epochs=10,
                  validation_split=0.2,
                  callbacks=AIMDFitCallback(trial))
        ```

    Args:
        trial: Trial that the training process belongs to.
    """
    def __init__(self, trial: Trial):
        super().__init__()
        self.trial = trial
        # If uses epoch.
        self.epoch_flag = False

    def on_train_begin(self, logs=None):  # pylint: disable=unused-argument
        # Retrieves params from `keras.Model.optimizer` and `keras.Model.loss`.
        optimizer_config = self.model.optimizer.get_config()
        for k, v in optimizer_config.copy().items():
            if isinstance(v, np.float32):
                optimizer_config[k] = float(v)

        new_params = {
            'optimizer': optimizer_config,
        }

        if isinstance(self.model.loss, str):
            new_params['lossType'] = self.model.loss
        elif isinstance(self.model.loss, keras.losses.Loss):
            new_params['lossType'] = self.model.loss.get_config()['name']
            # TODO: Adds `self.model.loss.get_config()['reduction']`
        else:
            raise TypeError('Undefined type for loss of Keras model')

        self.trial.params.update(new_params)
        _logger.debug('Training starts')
        self.trial._update_status('Running')

    def on_epoch_begin(self, epoch, logs=None):  # pylint: disable=unused-argument
        self.epoch_flag = True

    def on_train_batch_end(self, batch, logs=None):  # pylint: disable=unused-argument
        if not self.epoch_flag:
            self.trial.log('train',
                           logs,
                           step=int(self.model.optimizer.iterations.numpy()),
                           check_status=False)

    def on_epoch_end(self, epoch, logs=None):
        # Keys of validation metrics have the prefix 'val_' while keys of
        # training metrics have no prefix.
        train_logs = {k: logs[k] for k in logs if not k.startswith('val_')}
        self.trial.log('train',
                       train_logs,
                       step=int(self.model.optimizer.iterations.numpy()),
                       epoch=int(epoch) + 1,
                       check_status=False)

        if 'val_loss' in logs:
            val_logs = {k[4:]: logs[k] for k in logs if k.startswith('val_')}
            self.trial.log('val',
                           val_logs,
                           step=int(self.model.optimizer.iterations.numpy()),
                           epoch=int(epoch) + 1,
                           check_status=False)

    def on_train_end(self, logs=None):  # pylint: disable=unused-argument
        metrics_names = self.model.metrics_names
        metrics_names.remove('loss')
        new_params = {
            'metricTypes': metrics_names,
        }
        self.trial.params.update(new_params)


class AIMDEvalCallback(keras.callbacks.Callback):
    """Logs testing metrics.

    Examples:

        ```
        from t9k.aimd.keras import AIMDEvalCallback

        model.evaluate(test_images,
                       test_labels,
                       callbacks=AIMDEvalCallback(trial))
        ```

    Args:
        trial: Trial that the testing process belongs to.
    """
    def __init__(self, trial: Trial):
        super().__init__()
        self.trial = trial

    def on_test_end(self, logs=None):
        self.trial.log('test',
                       logs,
                       step=int(self.model.optimizer.iterations.numpy()),
                       check_status=False)
