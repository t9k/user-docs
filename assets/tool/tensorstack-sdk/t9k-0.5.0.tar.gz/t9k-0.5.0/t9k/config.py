"""Initialization of SDK config."""

import logging
import os
from pathlib import Path
import pprint
from typing import Any, Callable, Dict, ItemsView, Optional, Sequence, Union

from t9k.utils.file_utils import (join, isfile, isdir, dirname,
                                       write_yaml_file, read_yaml_file)
from t9k.utils.object_utils import assert_type
from t9k.utils.print_utils import red
from t9k.utils.url_utils import check_url
from t9k.utils.uuid_utils import is_uuid

_logger = logging.getLogger(__name__)

CONFIG_FILE_PATH = join(str(Path.home()), '.t9k', 't9k-sdk-config.yaml')
CONFIG_ITEMS = {'api_key': str, 'aimd_host': str, 'asset_hub_host': str}


class ConfigItem():
    """SDK config item.

    Attributes:
        name: Name of config item.
        value: Value of config item.
    """

    def __init__(
        self,
        name: str,
        value: Optional[Any] = None,
        processor: Union[Callable, Sequence[Callable], None] = None,
        validator: Union[Callable, Sequence[Callable], None] = None,
        hook: Union[Callable, Sequence[Callable], None] = None,
    ):
        self._name = name
        self._processor = processor
        self._validator = validator
        self._hook = hook

        self._value = self._validate(self._process(value))

    @property
    def name(self) -> str:
        return self._name

    @property
    def value(self) -> Any:
        value_ = self._value
        if self._hook is not None:
            hook = [self._hook] if callable(self._hook) else self._hook
            for h in hook:
                value_ = h(value_)
        return value_

    def _process(self, value: Any) -> Any:
        if value is not None and self._processor is not None:
            processor = [self._processor] if callable(
                self._processor) else self._processor
            for p in processor:
                value = p(value)
        return value

    def _validate(self, value: Any) -> Any:
        if value is not None:
            assert_type(value=value, type_=CONFIG_ITEMS[self.name])
            if self._validator is not None:
                validator = [self._validator] if callable(
                    self._validator) else self._validator
                for v in validator:
                    if not v(value):
                        # guaranteed error raised for invalid value
                        _logger.error('Invalid value for config item %s: %s',
                                      self.name, red(value))
                        raise ValueError(
                            'Invalid value for config item {}: {}'.format(
                                self.name, value))
        return value

    def _update(self, value: Any) -> None:
        self._value = self._validate(self._process(value))

    def __str__(self) -> str:
        return str(self.value)

    def __repr__(self) -> str:
        return self.value.__repr__()


def _validate_api_key(api_key: str) -> bool:
    # empty string ok
    if not api_key or is_uuid(api_key):
        return True

    _logger.error('Invalid API Key format: %s', red(api_key))
    raise ValueError('Invalid API Key format: {}'.format(api_key))


def _validate_host(host: str) -> bool:
    # empty string ok
    if not host:
        return True
    check_url(host)
    return True


class Config():
    """SDK config."""

    def __init__(self):
        object.__setattr__(self, '_items', {})
        config_items = {
            'api_key': {
                'validator': _validate_api_key,
            },
            'aimd_host': {
                'validator': _validate_host,
            },
            'asset_hub_host': {
                'validator': _validate_host,
            },
        }
        for k, v in config_items.items():
            self._items[k] = ConfigItem(
                name=k,
                processor=v.get('processor', None),
                validator=v.get('validator', None),
                hook=v.get('hook', None),
            )
        self.load()

    def load(self) -> None:
        """Loads from SDK config file.

        If SDK config file does not exist, make a default one.
        """
        if not isfile(CONFIG_FILE_PATH):
            self.make_config_file()

        config = read_yaml_file(CONFIG_FILE_PATH)
        for k in config:
            if k not in CONFIG_ITEMS:
                raise ValueError('Invalid SDK config item: {}'.format(k))
        for k, v in CONFIG_ITEMS.items():
            if k not in config:
                config[k] = v()
        self.update(config)

    def save(self) -> None:
        """Saves to SDK config file."""
        write_yaml_file(CONFIG_FILE_PATH, self.to_dict())

    def __getitem__(self, key: str) -> Any:
        if key not in CONFIG_ITEMS:
            raise ValueError('Invalid SDK config item: {}'.format(key))
        return self._items[key].value

    def __setitem__(self, key: str, value: Any) -> None:
        if key not in CONFIG_ITEMS:
            raise ValueError('Invalid SDK config item: {}'.format(key))
        self._items[key]._update(value)

    def __delitem__(self, key: str) -> None:
        if key not in CONFIG_ITEMS:
            raise ValueError('Invalid SDK config item: {}'.format(key))
        del self._items[key]

    def update(self, new_config: Dict[str, Any]) -> None:
        for k, v in new_config.items():
            self[k] = v

    def get(self, key: str, default: Any = None) -> Any:
        try:
            return self.__getitem__(key)
        except (KeyError, ValueError):
            return default

    def to_dict(self) -> Dict[str, Any]:
        return {k: v.value for k, v in self._items.items()}

    def items(self) -> ItemsView[str, Any]:
        return self.to_dict().items()

    def __str__(self) -> str:
        return pprint.pformat(self._items)

    __repr__ = __str__

    @staticmethod
    def make_config_file():
        """Makes a default SDK config file."""
        initial_config = {k: v() for k, v in CONFIG_ITEMS.items()}
        dir_name = dirname(CONFIG_FILE_PATH)
        if not isdir(dir_name):
            os.makedirs(dir_name)
        write_yaml_file(CONFIG_FILE_PATH, initial_config)


CONFIG = Config()
